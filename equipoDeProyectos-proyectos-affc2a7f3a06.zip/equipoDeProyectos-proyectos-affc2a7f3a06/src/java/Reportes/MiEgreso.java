/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Reportes;

/**
 *
 * @author Ariel
 */
public class MiEgreso {
    private Long nro;
    private String origen;
    private String estado;
    private String localidad;
    private String centroCosto;
    private String centroCostoItem;
    private String fecha_creacion;
    private String fecha_modificacion;
    private String fecha_anulacion;

    public MiEgreso() {
    }

    public String getOrigen() {
        return origen;
    }

    public void setOrigen(String origen) {
        this.origen = origen;
    }
    
    public MiEgreso(Long nro, String estado, String localidad, String centroCosto, String centroCostoItem, String fecha_creacion, String fecha_modificacion, String fecha_anulacion) {
        this.nro = nro;
        this.estado = estado;
        this.localidad = localidad;
        this.centroCosto = centroCosto;
        this.centroCostoItem = centroCostoItem;
        this.fecha_creacion = fecha_creacion;
        this.fecha_modificacion = fecha_modificacion;
        this.fecha_anulacion = fecha_anulacion;
    }

    public Long getNro() {
        return nro;
    }

    public void setNro(Long nro) {
        this.nro = nro;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getLocalidad() {
        return localidad;
    }

    public void setLocalidad(String localidad) {
        this.localidad = localidad;
    }

    public String getCentroCosto() {
        return centroCosto;
    }

    public void setCentroCosto(String centroCosto) {
        this.centroCosto = centroCosto;
    }

    public String getCentroCostoItem() {
        return centroCostoItem;
    }

    public void setCentroCostoItem(String centroCostoItem) {
        this.centroCostoItem = centroCostoItem;
    }

    public String getFecha_creacion() {
        return fecha_creacion;
    }

    public void setFecha_creacion(String fecha_creacion) {
        this.fecha_creacion = fecha_creacion;
    }

    public String getFecha_modificacion() {
        return fecha_modificacion;
    }

    public void setFecha_modificacion(String fecha_modificacion) {
        this.fecha_modificacion = fecha_modificacion;
    }

    public String getFecha_anulacion() {
        return fecha_anulacion;
    }

    public void setFecha_anulacion(String fecha_anulacion) {
        this.fecha_anulacion = fecha_anulacion;
    }
    
}
