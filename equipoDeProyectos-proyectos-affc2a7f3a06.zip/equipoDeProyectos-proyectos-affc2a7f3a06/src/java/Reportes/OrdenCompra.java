/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Reportes;

/**
 *
 * @author Ariel
 */
public class OrdenCompra {
    private Long nroOrden;
    private String creador;
    private String proveedor;
    private String detalle;
    private String fecha;

    public OrdenCompra(Long nroOrden, String creador, String proveedor, String detalle, String fechaCreacion) {
        this.nroOrden = nroOrden;
        this.creador = creador;
        this.proveedor = proveedor;
        this.detalle = detalle;
        this.fecha = fechaCreacion;
    }

    public OrdenCompra() {
    }

    public Long getNroOrden() {
        return nroOrden;
    }

    public void setNroOrden(Long nroOrden) {
        this.nroOrden = nroOrden;
    }

    public String getCreador() {
        return creador;
    }

    public void setCreador(String creador) {
        this.creador = creador;
    }

    public String getProveedor() {
        return proveedor;
    }

    public void setProveedor(String proveedor) {
        this.proveedor = proveedor;
    }

    public String getDetalle() {
        return detalle;
    }

    public void setDetalle(String detalle) {
        this.detalle = detalle;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }
    
    
}
