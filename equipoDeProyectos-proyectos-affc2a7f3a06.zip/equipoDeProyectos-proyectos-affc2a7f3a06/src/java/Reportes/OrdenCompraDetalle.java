/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Reportes;

/**
 *
 * @author Ariel
 */
public class OrdenCompraDetalle {
    private Integer indice;
    private String articulo;
    private Integer cantidad;

    public OrdenCompraDetalle(int indice, String articulo, int cantidad) {
        this.indice = indice;
        this.articulo = articulo;
        this.cantidad = cantidad;
    }

    public Integer getIndice() {
        return indice;
    }

    public void setIndice(int indice) {
        this.indice = indice;
    }

    public String getArticulo() {
        return articulo;
    }

    public void setArticulo(String articulo) {
        this.articulo = articulo;
    }

    public Integer getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }
    
    
}
