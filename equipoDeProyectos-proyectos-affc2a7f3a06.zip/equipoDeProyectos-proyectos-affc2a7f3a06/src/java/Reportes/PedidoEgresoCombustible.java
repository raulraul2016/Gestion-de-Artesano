/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Reportes;

/**
 *
 * @author Ariel
 */
public class PedidoEgresoCombustible {
    private int orden;
    private String combustible;
    private Integer cantidad;

    public PedidoEgresoCombustible(int orden,String combustible, Integer cantidad) {
        this.orden=orden;
        this.combustible = combustible;
        this.cantidad = cantidad;
    }

    public String getCombustible() {
        return combustible;
    }

    public void setCombustible(String combustible) {
        this.combustible = combustible;
    }

    public Integer getCantidad() {
        return cantidad;
    }

    public void setCantidad(Integer cantidad) {
        this.cantidad = cantidad;
    }

    public int getOrden() {
        return orden;
    }

    public void setOrden(int orden) {
        this.orden = orden;
    }
    
    
}
