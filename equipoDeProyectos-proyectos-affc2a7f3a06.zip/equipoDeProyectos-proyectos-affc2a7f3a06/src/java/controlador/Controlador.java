/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import Reportes.PedidoEgresoCombustible;
import dao.AreaDAO;
import dao.SolicitudEgresoCombustibleDAO;
import dao.SolicitudPedidoDetalleDAO;
import dao.UsuarioDAO;
import dto.AreaDTO;
import dto.SolicitudPedidoDetalleDTO;
import dto.UsuarioDTO;
import java.util.ArrayList;
import java.util.Date;

/**
 *
 * @author Ariel
 */
public class Controlador {
    public static void main(String[] args) {
        Date actual= new Date();
        util.Util.dateToSqlDate(actual);
        System.out.println(util.Util.dateToSqlDate(actual));
    }
}
