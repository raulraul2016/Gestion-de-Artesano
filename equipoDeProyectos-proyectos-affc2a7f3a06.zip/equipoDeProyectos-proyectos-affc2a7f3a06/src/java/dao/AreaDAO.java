/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import conexion.Conexion;
import dto.AreaDTO;
import interfaces.Interfaz;
import static java.lang.System.out;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author yesi
 */
public class AreaDAO implements Interfaz<AreaDTO>{
    private static final String  SQL_INSERT="INSERT INTO areas (area,area_sup, descripcion) VALUES (?,?,?)";
    private static final String  SQL_DELETE="DELETE FROM areas WHERE id_area=?";
    private static final String  SQL_UPDATE="UPDATE areas SET area=?,area_sup=?,descripcion=? WHERE id_area=?";
    private static final String  SQL_EXTRAER="SELECT * FROM areas WHERE id_area=?";
    private static final String  SQL_EXTRAERTODOS="SELECT id_area FROM areas order by area";
    private static final String  SQL_VERIFICAREXISTENCIA="SELECT * FROM areas WHERE area=?";
    
    private static final Conexion con = Conexion.saberEstado();
    
    @Override
    public boolean crear(AreaDTO c) {
        PreparedStatement ps;
            try {
            ps=con.getCnn().prepareStatement(SQL_INSERT);
            ps.setString(1, c.getNombre_area());
            if(c.getId_area_superior()==0){
            ps.setNull(2, Types.INTEGER);
            }else{
            ps.setInt(2, c.getId_area_superior());
            }
            if(c.getDescripcion().isEmpty()){
            ps.setNull(3, Types.VARCHAR);
            }else{
            ps.setString(3, c.getDescripcion());}
            
            if(ps.executeUpdate()>0){
                return true;
            }

        } catch (SQLException ex) {
            Logger.getLogger(AreaDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return false;//To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean borrar(Object id) {
        PreparedStatement ps;
        try {ps=con.getCnn().prepareStatement(SQL_DELETE);
            ps.setInt(1, Integer.parseInt(id.toString()));
            
            if(ps.executeUpdate()>0){
                return true;
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(AreaDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return false;  //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean actualizar(AreaDTO c) {
        PreparedStatement ps;
        try {
            ps=con.getCnn().prepareStatement(SQL_UPDATE);
            ps.setString(1, c.getNombre_area());
            
            if(c.getId_area_superior()==0){
            ps.setNull(2, Types.INTEGER);
            }else{
            ps.setInt(2, c.getId_area_superior());}
            
            if(c.getDescripcion().isEmpty()){
            ps.setNull(3, Types.VARCHAR);
            }else{
            ps.setString(3, c.getDescripcion());
            }
            
            ps.setLong(4, c.getId());
            
            if(ps.executeUpdate()>0){
                return true;
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(AreaDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return false; //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public AreaDTO extraer(Object id) {
            PreparedStatement ps;
            ResultSet rs;
            AreaDTO adto=null;
        try {    
            ps = con.getCnn().prepareStatement(SQL_EXTRAER);
            ps.setInt(1, Integer.parseInt(id.toString()));
            
            rs=ps.executeQuery();
            
            while(rs.next()){
                adto= new AreaDTO(rs.getInt(1), rs.getString(2), rs.getInt(3), rs.getString(4));
            }
        } catch (SQLException ex) {
            Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return adto; //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<AreaDTO> extraerTodos() {
        PreparedStatement ps;
        ResultSet rs;
        AreaDTO adto=null;
        ArrayList<AreaDTO> list=new ArrayList<AreaDTO>();
        try {    
            ps = con.getCnn().prepareStatement(SQL_EXTRAERTODOS);
            rs=ps.executeQuery();
            
            while(rs.next()){
                adto= extraer(rs.getInt(1));
                list.add(adto);
            }
        } catch (SQLException ex) {
            Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return list;//To change body of generated methods, choose Tools | Templates.
    }
    
    public boolean verificarexistencia(String area){
    
        PreparedStatement ps;
            ResultSet rs;
            AreaDTO adto=null;
        try {    
            ps = con.getCnn().prepareStatement(SQL_VERIFICAREXISTENCIA);
            ps.setString(1, area);
            
            rs=ps.executeQuery();
            
            while(rs.next()){
                return false;
            }
        } catch (SQLException ex) {
            Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return true;
    }
}
