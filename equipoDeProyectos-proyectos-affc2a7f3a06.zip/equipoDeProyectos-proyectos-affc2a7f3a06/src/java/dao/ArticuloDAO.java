/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import conexion.Conexion;
import dto.ArticuloDTO;
import dto.ProveedorRubroDTO;
import interfaces.Interfaz;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author yesi
 */
public class ArticuloDAO implements Interfaz<ArticuloDTO>{

    private static final String  SQL_INSERT="INSERT INTO articulos (nombre, rubro, unidad_medida, stock_min, stock_max, stock_actual, precio) VALUES (?,?,?,?,?,?,?)";
    private static final String  SQL_DELETE="DELETE FROM articulos WHERE idarticulo=?";
    private static final String  SQL_UPDATE="UPDATE articulos SET nombre=?, rubro=?,unidad_medida=?, stock_min=?, stock_max=?, stock_actual=?, precio=? , activo=? WHERE idarticulo=?";
    private static final String  SQL_EXTRAER="SELECT * FROM articulos WHERE idarticulo=?";
    private static final String  SQL_EXTRAERTODOS="SELECT idarticulo FROM articulos order by nombre asc";
    private static final String  SQL_EXTRAERTODOSDEBAJO="SELECT idarticulo FROM articulos WHERE stock_actual<stock_min order by nombre asc";
    private static final String  SQL_EXTRAERTODOSMINIMO="SELECT idarticulo FROM articulos WHERE stock_actual=stock_min order by nombre asc";
    private static final String  SQL_EXTRAERTODOSNORMAL="SELECT idarticulo FROM articulos WHERE stock_actual>stock_min && stock_actual<stock_max order by nombre asc";
    private static final String  SQL_EXTRAERTODOSENCIMA="SELECT idarticulo FROM articulos WHERE stock_actual>stock_max order by nombre asc";
    private static final String  SQL_EXTRAERTODOSTOCK="SELECT idarticulo FROM articulos WHERE  activo=1 and  stock_actual>stock_min order by nombre asc";
    private static final String  SQL_EXTRAERTODOSRUBROS="SELECT idarticulo FROM articulos WHERE rubro=? and activo=1 order by nombre asc";
    private static final String  SQL_EXTRAERTODOSNOMBRE="SELECT idarticulo FROM articulos WHERE nombre like concat('%',?,'%') and activo=1 order by nombre asc";
    private static final String  SQL_EXTRAERTODOSCOMBUSTIBLE="SELECT idarticulo FROM articulos WHERE rubro=7 and activo=1 order by nombre asc";
    private static final String  SQL_VERIFICAREXISTENCIA="SELECT * FROM articulos WHERE nombre=?";
    
    private static final Conexion CON = Conexion.saberEstado();
    
    @Override
    public boolean crear(ArticuloDTO c) {
        PreparedStatement ps;
            try {
            ps=CON.getCnn().prepareStatement(SQL_INSERT);
            ps.setString(1, c.getNombre());
            ps.setInt(2, c.getRubro());
            ps.setInt(3, c.getUnidad_medida());
            ps.setInt(4, c.getStock_min());
            ps.setInt(5, c.getStock_max());
            ps.setInt(6, c.getStock_actual());
            if(c.getPrecio()==null){
                ps.setNull(7, Types.DECIMAL);
            }else{
                ps.setDouble(7, c.getPrecio());
            }
            
            if(ps.executeUpdate()>0){
                return true;
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(ArticuloDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            CON.cerrarConexion();
        }
        return false;//To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean borrar(Object id) {
        PreparedStatement ps;
        try {ps=CON.getCnn().prepareStatement(SQL_DELETE);
            ps.setInt(1, Integer.parseInt(id.toString()));
            
            if(ps.executeUpdate()>0){
                return true;
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(ArticuloDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            CON.cerrarConexion();
        }
        return false;//To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean actualizar(ArticuloDTO c) {
        PreparedStatement ps;
        try {
            ps=CON.getCnn().prepareStatement(SQL_UPDATE);
            ps.setString(1, c.getNombre());
            ps.setInt(2, c.getRubro());
            ps.setInt(3, c.getUnidad_medida());
            ps.setInt(5, c.getStock_max());
            ps.setInt(4, c.getStock_min());
            ps.setInt(6, c.getStock_actual());
            if(c.getPrecio()==null){
                ps.setNull(7, Types.DECIMAL);
            }else{
                ps.setDouble(7, c.getPrecio());
            }
            ps.setBoolean(8, c.isActivo());
            ps.setLong(9, c.getId_articulo());
            
            
            if(ps.executeUpdate()>0){
                return true;
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(ArticuloDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            CON.cerrarConexion();
        }
        return false;//To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public ArticuloDTO extraer(Object id) {
        PreparedStatement ps;
            ResultSet rs;
            ArticuloDTO adto=null;
        try {    
            ps = CON.getCnn().prepareStatement(SQL_EXTRAER);
            ps.setInt(1, Integer.parseInt(id.toString()));
            
            rs=ps.executeQuery();
            
            while(rs.next()){
                adto= new ArticuloDTO(rs.getLong(1), rs.getString(2), rs.getInt(3),rs.getInt(4), rs.getInt(5), rs.getInt(6), rs.getInt(7), rs.getDouble(8), rs.getBoolean(9));
            }
        } catch (SQLException ex) {
            Logger.getLogger(ArticuloDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            CON.cerrarConexion();
        }
        return adto;//To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<ArticuloDTO> extraerTodos() {
        PreparedStatement ps;
        ResultSet rs;
        ArticuloDTO adto;
        ArrayList<ArticuloDTO> list=new ArrayList<ArticuloDTO>();
        try {    
            ps = CON.getCnn().prepareStatement(SQL_EXTRAERTODOS);
            rs=ps.executeQuery();
            
            while(rs.next()){
                adto= extraer(rs.getInt(1));
                list.add(adto);
            }
        } catch (SQLException ex) {
            Logger.getLogger(ArticuloDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            CON.cerrarConexion();
        }
        return list;//To change body of generated methods, choose Tools | Templates.
    }
    
    public List<ArticuloDTO> extraerTodosDebajo() {
        PreparedStatement ps;
        ResultSet rs;
        ArticuloDTO adto;
        ArrayList<ArticuloDTO> list=new ArrayList<ArticuloDTO>();
        try {    
            ps = CON.getCnn().prepareStatement(SQL_EXTRAERTODOSDEBAJO);
            rs=ps.executeQuery();
            
            while(rs.next()){
                adto= extraer(rs.getInt(1));
                list.add(adto);
            }
        } catch (SQLException ex) {
            Logger.getLogger(ArticuloDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            CON.cerrarConexion();
        }
        return list;//To change body of generated methods, choose Tools | Templates.
    }
    
    public List<ArticuloDTO> extraerTodosCombustible() {
        PreparedStatement ps;
        ResultSet rs;
        ArticuloDTO adto;
        ArrayList<ArticuloDTO> list=new ArrayList<ArticuloDTO>();
        try {    
            ps = CON.getCnn().prepareStatement(SQL_EXTRAERTODOSCOMBUSTIBLE);
            rs=ps.executeQuery();
            
            while(rs.next()){
                adto= extraer(rs.getInt(1));
                list.add(adto);
            }
        } catch (SQLException ex) {
            Logger.getLogger(ArticuloDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            CON.cerrarConexion();
        }
        return list;//To change body of generated methods, choose Tools | Templates.
    }
    
    public List<ArticuloDTO> extraerTodosMinimo() {
        PreparedStatement ps;
        ResultSet rs;
        ArticuloDTO adto;
        ArrayList<ArticuloDTO> list=new ArrayList<ArticuloDTO>();
        try {    
            ps = CON.getCnn().prepareStatement(SQL_EXTRAERTODOSMINIMO);
            rs=ps.executeQuery();
            
            while(rs.next()){
                adto= extraer(rs.getInt(1));
                list.add(adto);
            }
        } catch (SQLException ex) {
            Logger.getLogger(ArticuloDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            CON.cerrarConexion();
        }
        return list;//To change body of generated methods, choose Tools | Templates.
    }
    
    public List<ArticuloDTO> extraerTodosNormal() {
        PreparedStatement ps;
        ResultSet rs;
        ArticuloDTO adto;
        ArrayList<ArticuloDTO> list=new ArrayList<ArticuloDTO>();
        try {    
            ps = CON.getCnn().prepareStatement(SQL_EXTRAERTODOSNORMAL);
            rs=ps.executeQuery();
            
            while(rs.next()){
                adto= extraer(rs.getInt(1));
                list.add(adto);
            }
        } catch (SQLException ex) {
            Logger.getLogger(ArticuloDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            CON.cerrarConexion();
        }
        return list;//To change body of generated methods, choose Tools | Templates.
    }
    
    public List<ArticuloDTO> extraerTodosEncima() {
        PreparedStatement ps;
        ResultSet rs;
        ArticuloDTO adto;
        ArrayList<ArticuloDTO> list=new ArrayList<ArticuloDTO>();
        try {    
            ps = CON.getCnn().prepareStatement(SQL_EXTRAERTODOSENCIMA);
            rs=ps.executeQuery();
            
            while(rs.next()){
                adto= extraer(rs.getInt(1));
                list.add(adto);
            }
        } catch (SQLException ex) {
            Logger.getLogger(ArticuloDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            CON.cerrarConexion();
        }
        return list;//To change body of generated methods, choose Tools | Templates.
    }
    
    public List<ArticuloDTO> extraerTodosRubro(int rubro) {
        PreparedStatement ps;
        ResultSet rs;
        ArticuloDTO adto;
        ArrayList<ArticuloDTO> list=new ArrayList<ArticuloDTO>();
        try {    
            ps = CON.getCnn().prepareStatement(SQL_EXTRAERTODOSRUBROS);
            ps.setInt(1, rubro);
            rs=ps.executeQuery();
            
            while(rs.next()){
                adto= extraer(rs.getInt(1));
                list.add(adto);
            }
        } catch (SQLException ex) {
            Logger.getLogger(ArticuloDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            CON.cerrarConexion();
        }
        return list;//To change body of generated methods, choose Tools | Templates.
    }
    public List<ArticuloDTO> extraerTodosNombre(String nombre) {
        PreparedStatement ps;
        ResultSet rs;
        ArticuloDTO adto;
        ArrayList<ArticuloDTO> list=new ArrayList<ArticuloDTO>();
        try {    
            ps = CON.getCnn().prepareStatement(SQL_EXTRAERTODOSNOMBRE);
            ps.setString(1, nombre);
            rs=ps.executeQuery();
            
            while(rs.next()){
                adto= extraer(rs.getInt(1));
                list.add(adto);
            }
        } catch (SQLException ex) {
            Logger.getLogger(ArticuloDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            CON.cerrarConexion();
        }
        return list;//To change body of generated methods, choose Tools | Templates.
    }
    public List<ArticuloDTO> extraerTodosPro(int proveedor) {
        PreparedStatement ps;
        ResultSet rs;
        ArticuloDTO adto;
        ProveedorRubroDAO prdao= new ProveedorRubroDAO();
        ArrayList<ArticuloDTO> list=new ArrayList<ArticuloDTO>();
        ArrayList<ProveedorRubroDTO> rubros=(ArrayList<ProveedorRubroDTO>) prdao.extraerTodosPRO(proveedor);
        try {    
            for(int i=0;i<rubros.size();i++){
                
            ps = CON.getCnn().prepareStatement(SQL_EXTRAERTODOSRUBROS);
            ps.setInt(1, rubros.get(i).getId_rubro());
            rs=ps.executeQuery();
            
            while(rs.next()){
                adto= extraer(rs.getInt(1));
                list.add(adto);
            }
            }
        } catch (SQLException ex) {
            Logger.getLogger(ArticuloDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            CON.cerrarConexion();
        }
        return list;//To change body of generated methods, choose Tools | Templates.
    }
    
    public List<ArticuloDTO> extraerTodosStock() {
        PreparedStatement ps;
        ResultSet rs;
        ArticuloDTO adto;
        ArrayList<ArticuloDTO> list=new ArrayList<ArticuloDTO>();
        try {    
            ps = CON.getCnn().prepareStatement(SQL_EXTRAERTODOSTOCK);
            rs=ps.executeQuery();
            
            while(rs.next()){
                adto= extraer(rs.getInt(1));
                list.add(adto);
            }
        } catch (SQLException ex) {
            Logger.getLogger(ArticuloDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            CON.cerrarConexion();
        }
        return list;//To change body of generated methods, choose Tools | Templates.
    }
    
    public boolean verificarexistencia(String area){
    
        PreparedStatement ps;
            ResultSet rs;
            ArticuloDTO adto=null;
        try {    
            ps = CON.getCnn().prepareStatement(SQL_VERIFICAREXISTENCIA);
            ps.setString(1, area);
            
            rs=ps.executeQuery();
            
            while(rs.next()){
                return false;
            }
        } catch (SQLException ex) {
            Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            CON.cerrarConexion();
        }
        return true;
    }
    
    public boolean actualizarEgresoStock(Long idArticulo, int cantidad) {
        PreparedStatement ps;
        ArticuloDTO c= extraer(idArticulo);
        c.setStock_actual(c.getStock_actual()-cantidad);
        try {
            ps=CON.getCnn().prepareStatement(SQL_UPDATE);
            ps.setString(1, c.getNombre());
            ps.setInt(2, c.getRubro());
            ps.setInt(3, c.getUnidad_medida());
            ps.setInt(5, c.getStock_max());
            ps.setInt(4, c.getStock_min());
            ps.setInt(6, c.getStock_actual());
            if(c.getPrecio()==null){
                ps.setNull(7, Types.DECIMAL);
            }else{
                ps.setDouble(7, c.getPrecio());
            }
            ps.setBoolean(8, c.isActivo());
            ps.setLong(9, c.getId_articulo());
            
            
            if(ps.executeUpdate()>0){
                return true;
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(ArticuloDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            CON.cerrarConexion();
        }
        return false;//To change body of generated methods, choose Tools | Templates.
    }
    
    public boolean actualizarIngresoStock(Long idArticulo, int cantidad, Double precio) {
        PreparedStatement ps;
        ArticuloDTO c= extraer(idArticulo);
        c.setStock_actual(c.getStock_actual()+cantidad);
        c.setPrecio(precio);
        try {
            ps=CON.getCnn().prepareStatement(SQL_UPDATE);
            ps.setString(1, c.getNombre());
            ps.setInt(2, c.getRubro());
            ps.setInt(3, c.getUnidad_medida());
            ps.setInt(5, c.getStock_max());
            ps.setInt(4, c.getStock_min());
            ps.setInt(6, c.getStock_actual());
            if(c.getPrecio()==null){
                ps.setNull(7, Types.DECIMAL);
            }else{
                ps.setDouble(7, c.getPrecio());
            }
            ps.setBoolean(8, c.isActivo());
            ps.setLong(9, c.getId_articulo());
            
            
            if(ps.executeUpdate()>0){
                return true;
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(ArticuloDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            CON.cerrarConexion();
        }
        return false;//To change body of generated methods, choose Tools | Templates.
    }
}
