/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import conexion.Conexion;
import dto.CentroCostoDTO;
import interfaces.Interfaz;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Ariel
 */
public class CentroCostoDAO implements Interfaz<CentroCostoDTO>{

    private static final String  SQL_INSERT="INSERT INTO centros_costo (id_area, id_subarea, id_localidad, nombre, cod_centro_costo) VALUES (?,?,?,?,?)";
    private static final String  SQL_DELETE="DELETE FROM centros_costo WHERE id_centros_costo=?";
    private static final String  SQL_UPDATE="UPDATE centros_costo SET id_area=?, id_subarea=?, id_localidad=?, nombre=?, cod_centro_costo=? WHERE id_centros_costo=?";
    private static final String  SQL_EXTRAER="SELECT * FROM centros_costo WHERE id_centros_costo=?";
    private static final String  SQL_EXTRAERTODOS="SELECT id_centros_costo FROM centros_costo order by nombre asc";
    private static final String  SQL_EXTRAERTODOSF="SELECT id_centros_costo FROM centros_costo WHERE id_localidad=? order by nombre asc";
    private static final String  SQL_VERIFICAREXISTENCIA="SELECT * FROM centros_costo WHERE cod_centro_costo=?";
    
    private static final Conexion con = Conexion.saberEstado();
    
    @Override
    public boolean crear(CentroCostoDTO c) {
        PreparedStatement ps;
            try {
            ps=con.getCnn().prepareStatement(SQL_INSERT);
            ps.setLong(1, c.getId_area());
            if(c.getId_sub_area()!=0){
            ps.setLong(2, c.getId_sub_area());
            }else{
                ps.setNull(2, Types.INTEGER);
            }
            if(c.getId_localidad()!=0){
            ps.setLong(3, c.getId_localidad());
            }else{
                ps.setNull(3, Types.INTEGER);
            }
            ps.setString(4, c.getNombre());
            ps.setString(5, c.getCodigo());
            
            if(ps.executeUpdate()>0){
                return true;
            }

        } catch (SQLException ex) {
            Logger.getLogger(CentroCostoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return false; //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean borrar(Object id) {
        PreparedStatement ps;
        try {ps=con.getCnn().prepareStatement(SQL_DELETE);
            ps.setLong(1, Long.valueOf(id.toString()));
            
            if(ps.executeUpdate()>0){
                return true;
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(CentroCostoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return false; //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean actualizar(CentroCostoDTO c) {
        PreparedStatement ps;
        try {
            ps=con.getCnn().prepareStatement(SQL_UPDATE);
            ps.setLong(1, c.getId_area());
            if(c.getId_sub_area()!=0){
            ps.setLong(2, c.getId_sub_area());
            }else{
                ps.setNull(2, Types.INTEGER);
            }
            if(c.getId_localidad()!=0){
            ps.setLong(3, c.getId_localidad());
            }else{
                ps.setNull(3, Types.INTEGER);
            }
            ps.setString(4, c.getNombre());
            ps.setString(5, c.getCodigo());
            ps.setLong(6, c.getId_centros_costo());
            
            if(ps.executeUpdate()>0){
                return true;
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(CentroCostoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return false; //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public CentroCostoDTO extraer(Object id) {
        PreparedStatement ps;
            ResultSet rs;
            CentroCostoDTO cdto=null;
        try {    
            ps = con.getCnn().prepareStatement(SQL_EXTRAER);
            ps.setInt(1, Integer.parseInt(id.toString()));
            
            rs=ps.executeQuery();
            
            while(rs.next()){
                cdto= new CentroCostoDTO(rs.getLong(1), rs.getInt(2), rs.getInt(3), rs.getInt(4), rs.getString(5), rs.getString(6));
            }
        } catch (SQLException ex) {
            Logger.getLogger(CentroCostoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return cdto; //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<CentroCostoDTO> extraerTodos() {
        PreparedStatement ps;
        ResultSet rs;
        CentroCostoDTO cdto=null;
        ArrayList<CentroCostoDTO> list=new ArrayList<CentroCostoDTO>();
        try {    
            ps = con.getCnn().prepareStatement(SQL_EXTRAERTODOS);
            rs=ps.executeQuery();
            
            while(rs.next()){
                cdto= extraer(rs.getLong(1));
                list.add(cdto);
            }
        } catch (SQLException ex) {
            Logger.getLogger(CentroCostoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return list; //To change body of generated methods, choose Tools | Templates.
    }
    
    public boolean verificarexistencia(String area){
    
        PreparedStatement ps;
            ResultSet rs;
            CentroCostoDTO adto=null;
        try {    
            ps = con.getCnn().prepareStatement(SQL_VERIFICAREXISTENCIA);
            ps.setString(1, area);
            
            rs=ps.executeQuery();
            
            while(rs.next()){
                return false;
            }
        } catch (SQLException ex) {
            Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return true;
    }
    
    public List<CentroCostoDTO> extraerTodosF(int localidad) {
        PreparedStatement ps;
        ResultSet rs;
        CentroCostoDTO cdto=null;
        ArrayList<CentroCostoDTO> list=new ArrayList<CentroCostoDTO>();
        try {    
            ps = con.getCnn().prepareStatement(SQL_EXTRAERTODOSF);
            ps.setInt(1, localidad);
            rs=ps.executeQuery();
            
            while(rs.next()){
                cdto= extraer(rs.getLong(1));
                list.add(cdto);
            }
        } catch (SQLException ex) {
            Logger.getLogger(CentroCostoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return list; //To change body of generated methods, choose Tools | Templates.
    }
}
