/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import conexion.Conexion;
import dto.CentroCostoItemDTO;
import interfaces.Interfaz;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Ariel
 */
public class CentroCostoItemDAO implements Interfaz<CentroCostoItemDTO>{

    private static final String  SQL_INSERT="INSERT INTO centro_costo_item (id_centro_costo, nombre, cod_centro_costo_item) VALUES (?,?,?)";
    private static final String  SQL_DELETE="DELETE FROM centro_costo_item WHERE iditem_centro_costo=?";
    private static final String  SQL_UPDATE="UPDATE centro_costo_item SET id_centro_costo=?, nombre=? ,cod_centro_costo_item=? WHERE iditem_centro_costo=?";
    private static final String  SQL_EXTRAER="SELECT * FROM centro_costo_item WHERE iditem_centro_costo=?";
    private static final String  SQL_EXTRAERTODOS="SELECT iditem_centro_costo FROM centro_costo_item order by  nombre asc";
    private static final String  SQL_EXTRAERTODOSF="SELECT iditem_centro_costo FROM centro_costo_item WHERE  id_centro_costo=? order by nombre asc";
    private static final String  SQL_VERIFICAREXISTENCIA="SELECT * FROM centro_costo_item WHERE cod_centro_costo_item=?";
    private static final Conexion con = Conexion.saberEstado();
    
    @Override
    public boolean crear(CentroCostoItemDTO c) {
        PreparedStatement ps;
            try {
            ps=con.getCnn().prepareStatement(SQL_INSERT);
            ps.setLong(1, c.getId_centro_costo());
            ps.setString(2, c.getNombre());
            ps.setString(3, c.getCod_centro_costo_item());
            
            if(ps.executeUpdate()>0){
                return true;
            }

        } catch (SQLException ex) {
            Logger.getLogger(CentroCostoItemDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return false; //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean borrar(Object id) {
        PreparedStatement ps;
        try {ps=con.getCnn().prepareStatement(SQL_DELETE);
            ps.setLong(1, Long.valueOf(id.toString()));
            
            if(ps.executeUpdate()>0){
                return true;
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(CentroCostoItemDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return false; //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean actualizar(CentroCostoItemDTO c) {
        PreparedStatement ps;
        try {
            ps=con.getCnn().prepareStatement(SQL_UPDATE);
            ps.setLong(1, c.getId_centro_costo());
            ps.setString(2, c.getNombre());
            ps.setString(3, c.getCod_centro_costo_item());
            ps.setLong(4, c.getIditem_centro_costo());
            
            if(ps.executeUpdate()>0){
                return true;
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(CentroCostoItemDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return false; //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public CentroCostoItemDTO extraer(Object id) {
        PreparedStatement ps;
            ResultSet rs;
            CentroCostoItemDTO cdto=null;
        try {    
            ps = con.getCnn().prepareStatement(SQL_EXTRAER);
            ps.setInt(1, Integer.parseInt(id.toString()));
            
            rs=ps.executeQuery();
            
            while(rs.next()){
                cdto= new CentroCostoItemDTO(rs.getLong(1), rs.getLong(2), rs.getString(3), rs.getString(4));
            }
        } catch (SQLException ex) {
            Logger.getLogger(CentroCostoItemDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return cdto; //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<CentroCostoItemDTO> extraerTodos() {
        PreparedStatement ps;
        ResultSet rs;
        CentroCostoItemDTO cdto=null;
        ArrayList<CentroCostoItemDTO> list=new ArrayList<CentroCostoItemDTO>();
        try {    
            ps = con.getCnn().prepareStatement(SQL_EXTRAERTODOS);
            rs=ps.executeQuery();
            
            while(rs.next()){
                cdto= extraer(rs.getLong(1));
                list.add(cdto);
            }
        } catch (SQLException ex) {
            Logger.getLogger(CentroCostoItemDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return list; //To change body of generated methods, choose Tools | Templates.
    }
    
    public boolean verificarexistencia(String area){
    
        PreparedStatement ps;
            ResultSet rs;
            CentroCostoItemDTO adto=null;
        try {    
            ps = con.getCnn().prepareStatement(SQL_VERIFICAREXISTENCIA);
            ps.setString(1, area);
            
            rs=ps.executeQuery();
            
            while(rs.next()){
                return false;
            }
        } catch (SQLException ex) {
            Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return true;
    }
    
    public List<CentroCostoItemDTO> extraerTodosF(Object id) {
        PreparedStatement ps;
        ResultSet rs;
        CentroCostoItemDTO cdto=null;
        ArrayList<CentroCostoItemDTO> list=new ArrayList<CentroCostoItemDTO>();
        try {    
            ps = con.getCnn().prepareStatement(SQL_EXTRAERTODOSF);
            ps.setLong(1, Long.valueOf(id.toString()));
            rs=ps.executeQuery();
            
            while(rs.next()){
                cdto= extraer(rs.getLong(1));
                list.add(cdto);
            }
        } catch (SQLException ex) {
            Logger.getLogger(CentroCostoItemDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return list; //To change body of generated methods, choose Tools | Templates.
    }
}
