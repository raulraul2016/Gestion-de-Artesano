/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import conexion.Conexion;
import dto.CombustibleDTO;
import interfaces.Interfaz;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Ariel
 */
public class CombustibleDAO implements Interfaz<CombustibleDTO>{

    
    private static final String  SQL_EXTRAER="SELECT * FROM combustibles WHERE idcombustibles=?";
    private static final String  SQL_EXTRAERTODOS="SELECT idcombustibles FROM combustibles order by nombre";
    
    private static final Conexion con = Conexion.saberEstado();
    
    @Override
    public boolean crear(CombustibleDTO c) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean borrar(Object id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean actualizar(CombustibleDTO c) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public CombustibleDTO extraer(Object id) {
        PreparedStatement ps;
            ResultSet rs;
            CombustibleDTO adto=null;
        try {    
            ps = con.getCnn().prepareStatement(SQL_EXTRAER);
            ps.setInt(1, Integer.parseInt(id.toString()));
            
            rs=ps.executeQuery();
            
            while(rs.next()){
                adto= new CombustibleDTO(rs.getInt(1), rs.getString(2));
            }
        } catch (SQLException ex) {
            Logger.getLogger(CombustibleDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return adto; //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<CombustibleDTO> extraerTodos() {
        PreparedStatement ps;
        ResultSet rs;
        CombustibleDTO adto=null;
        ArrayList<CombustibleDTO> list=new ArrayList<CombustibleDTO>();
        try {    
            ps = con.getCnn().prepareStatement(SQL_EXTRAERTODOS);
            rs=ps.executeQuery();
            
            while(rs.next()){
                adto= extraer(rs.getInt(1));
                list.add(adto);
            }
        } catch (SQLException ex) {
            Logger.getLogger(CombustibleDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return list;//To change body of generated methods, choose Tools | Templates.
    }
    
}
