/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import conexion.Conexion;
import dto.FormaCargaCombustibleDTO;
import interfaces.Interfaz;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Ariel
 */
public class FormaCargaCombustibleDAO implements Interfaz<FormaCargaCombustibleDTO>{

    private static final String  SQL_INSERT="INSERT INTO formas_carga (id_solicitud_egreso_combustible, id_tipo_carga) VALUES (?,?)";
    private static final String  SQL_UPDATE="UPDATE formas_carga SET id_solicitud_egreso_combustible=?, id_tipo_carga=? WHERE idformas_carga=?";
    private static final String  SQL_DELETE="DELETE FROM formas_carga WHERE idformas_carga=?";
    private static final String  SQL_EXTRAER="SELECT * FROM formas_carga WHERE idformas_carga=?";
    private static final String  SQL_EXTRAERTODOSPEDIDO="SELECT idformas_carga FROM formas_carga WHERE id_solicitud_egreso_combustible=? ";
    
    
    private static final Conexion con = Conexion.saberEstado();
    
    @Override
    public boolean crear(FormaCargaCombustibleDTO c) {
        PreparedStatement ps;
            try {
            con.getCnn().setAutoCommit(false);
            ps=con.getCnn().prepareStatement(SQL_INSERT);
            ps.setLong(1, c.getIdSolicitudEgresoCombustible());
            ps.setInt(2, c.getIdTipoCarga());
            
            if(ps.executeUpdate()>0){
                //con.getCnn().commit();
                return true;
            }

        } catch (SQLException ex) {
            Logger.getLogger(FormaCargaCombustibleDAO.class.getName()).log(Level.SEVERE, null, ex);
            try {
                con.getCnn().rollback();
            } catch (SQLException ex1) {
                Logger.getLogger(FormaCargaCombustibleDAO.class.getName()).log(Level.SEVERE, null, ex1);
            }
        }finally{
            con.cerrarConexion();
        }
        return false;//To change body of generated methods, choose Tools | Templates.
    }
    public boolean crear2(FormaCargaCombustibleDTO c, Connection con) {
        PreparedStatement ps;
            try {
            ps=con.prepareStatement(SQL_INSERT);
            ps.setLong(1, c.getIdSolicitudEgresoCombustible());
            ps.setInt(2, c.getIdTipoCarga());
            
            if(ps.executeUpdate()>0){
                return true;
            }

        } catch (SQLException ex) {
            Logger.getLogger(FormaCargaCombustibleDAO.class.getName()).log(Level.SEVERE, null, ex);
            
        }
        return false;//To change body of generated methods, choose Tools | Templates.
    }
    
    @Override
    public boolean borrar(Object id) {
        PreparedStatement ps;
        try {
            con.getCnn().setAutoCommit(false);
            ps=con.getCnn().prepareStatement(SQL_DELETE);
            ps.setLong(1, Long.valueOf(id.toString()));
            
            if(ps.executeUpdate()>0){
                con.getCnn().commit();
                return true;
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(FormaCargaCombustibleDAO.class.getName()).log(Level.SEVERE, null, ex);
            try {
                con.getCnn().rollback();
            } catch (SQLException ex1) {
                Logger.getLogger(FormaCargaCombustibleDAO.class.getName()).log(Level.SEVERE, null, ex1);
            }
        }finally{
            con.cerrarConexion();
        }
        return false;  //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean actualizar(FormaCargaCombustibleDTO c) {
        PreparedStatement ps;
        try {
            con.getCnn().setAutoCommit(false);
            ps=con.getCnn().prepareStatement(SQL_UPDATE);
            ps.setLong(1, c.getIdSolicitudEgresoCombustible());
            ps.setInt(2, c.getIdTipoCarga());
            ps.setLong(3, c.getIdFormaCargaCombustible());
            
            if(ps.executeUpdate()>0){
                con.getCnn().commit();
                return true;
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(FormaCargaCombustibleDAO.class.getName()).log(Level.SEVERE, null, ex);
            try {
                con.getCnn().rollback();
            } catch (SQLException ex1) {
                Logger.getLogger(FormaCargaCombustibleDAO.class.getName()).log(Level.SEVERE, null, ex1);
            }
        }finally{
            con.cerrarConexion();
        }
        return false;  //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public FormaCargaCombustibleDTO extraer(Object id) {
        PreparedStatement ps;
            ResultSet rs;
            FormaCargaCombustibleDTO adto=null;
        try { 
            con.getCnn().setAutoCommit(false);
            ps = con.getCnn().prepareStatement(SQL_EXTRAER);
            ps.setLong(1, Long.valueOf(id.toString()));
            
            rs=ps.executeQuery();
            con.getCnn().commit();
            
            while(rs.next()){
                adto= new FormaCargaCombustibleDTO(rs.getLong(1), rs.getLong(2), rs.getInt(3));
            }
        } catch (SQLException ex) {
            Logger.getLogger(FormaCargaCombustibleDAO.class.getName()).log(Level.SEVERE, null, ex);
            try {
                con.getCnn().rollback();
            } catch (SQLException ex1) {
                Logger.getLogger(FormaCargaCombustibleDAO.class.getName()).log(Level.SEVERE, null, ex1);
            }
        }finally{
            con.cerrarConexion();
        }
        return adto; //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<FormaCargaCombustibleDTO> extraerTodos() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    public List<FormaCargaCombustibleDTO> extraerTodosPedido(Long id_pedido) {
        PreparedStatement ps;
        ResultSet rs;
        FormaCargaCombustibleDTO adto=null;
        ArrayList<FormaCargaCombustibleDTO> list=new ArrayList<FormaCargaCombustibleDTO>();
        try {    
            con.getCnn().setAutoCommit(false);
            ps = con.getCnn().prepareStatement(SQL_EXTRAERTODOSPEDIDO);
            ps.setLong(1, id_pedido);
            rs=ps.executeQuery();
            con.getCnn().commit();
            while(rs.next()){
                adto= extraer(rs.getLong(1));
                list.add(adto);
            }
        } catch (SQLException ex) {
            Logger.getLogger(FormaCargaCombustibleDAO.class.getName()).log(Level.SEVERE, null, ex);
            try {
                con.getCnn().rollback();
            } catch (SQLException ex1) {
                Logger.getLogger(FormaCargaCombustibleDAO.class.getName()).log(Level.SEVERE, null, ex1);
            }
        }finally{
            con.cerrarConexion();
        }
        return list; //To change body of generated methods, choose Tools | Templates.
    }
    public boolean insertarDetalles(List<FormaCargaCombustibleDTO> formas){
        PreparedStatement ps;
       //try {
         //se deshabilita el modo de confirmación automática
             //con.getCnn().setAutoCommit(false);            
             for(int i=0;i<formas.size();i++){
                 crear(formas.get(i));
             }
            //se indica que se deben aplicar los cambios en la base de datos
            //con.getCnn().commit();
            
        //} catch (SQLException ex) {
             //    Logger.getLogger(FormaCargaCombustibleDAO.class.getName()).log(Level.SEVERE, null, ex);
           //try {
               //con.getCnn().rollback();
               //return false;
           //} catch (SQLException ex1) {
           //    Logger.getLogger(FormaCargaCombustibleDAO.class.getName()).log(Level.SEVERE, null, ex1);
           //}
           // }finally{
           //  con.cerrarConexion();
          //   }
          
    return true;
    }
    
    public boolean insertarDetalles2(List<FormaCargaCombustibleDTO> formas, Connection con){
        PreparedStatement ps;
       //try {
         //se deshabilita el modo de confirmación automática
             //con.getCnn().setAutoCommit(false);            
             for(int i=0;i<formas.size();i++){
                 crear2(formas.get(i), con);
             }
            //se indica que se deben aplicar los cambios en la base de datos
            //con.getCnn().commit();
            
        //} catch (SQLException ex) {
             //    Logger.getLogger(FormaCargaCombustibleDAO.class.getName()).log(Level.SEVERE, null, ex);
           //try {
               //con.getCnn().rollback();
               //return false;
           //} catch (SQLException ex1) {
           //    Logger.getLogger(FormaCargaCombustibleDAO.class.getName()).log(Level.SEVERE, null, ex1);
           //}
           // }finally{
           //  con.cerrarConexion();
          //   }
    return true;
    }
}
