/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import conexion.Conexion;
import dto.MedidaDTO;
import interfaces.Interfaz;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author yesi
 */
public class MedidaDAO implements Interfaz<MedidaDTO>{

    private static final String  SQL_INSERT="INSERT INTO medidas (nombre, abreviatura) VALUES (?,?)";
    private static final String  SQL_DELETE="DELETE FROM medidas WHERE id_medida=?";
    private static final String  SQL_UPDATE="UPDATE medidas SET nombre=?, abreviatura=? WHERE id_medida=?";
    private static final String  SQL_EXTRAER="SELECT * FROM medidas WHERE id_medida=?";
    private static final String  SQL_EXTRAERTODOS="SELECT id_medida FROM medidas ";
    private static final String  SQL_VERIFICAREXISTENCIA="SELECT * FROM medidas WHERE nombre=?";
    
    private static final Conexion con = Conexion.saberEstado();
    @Override
    public boolean crear(MedidaDTO c) {
        PreparedStatement ps;
            try {
            ps=con.getCnn().prepareStatement(SQL_INSERT);
            ps.setString(1, c.getNombre());
            ps.setString(2, c.getAbreviatura());
            
            if(ps.executeUpdate()>0){
                return true;
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(MedidaDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return false;//To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean borrar(Object id) {
        PreparedStatement ps;
        try {ps=con.getCnn().prepareStatement(SQL_DELETE);
            ps.setInt(1, Integer.parseInt(id.toString()));
            
            if(ps.executeUpdate()>0){
                return true;
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(MedidaDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return false; //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean actualizar(MedidaDTO c) {
        PreparedStatement ps;
        try {
            ps=con.getCnn().prepareStatement(SQL_UPDATE);
            ps.setString(1, c.getNombre());
            ps.setString(2, c.getAbreviatura());
            ps.setLong(3, c.getId_medida());
            
            if(ps.executeUpdate()>0){
                return true;
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(MedidaDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return false;//To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public MedidaDTO extraer(Object id) {
        PreparedStatement ps;
            ResultSet rs;
            MedidaDTO mdto=null;
        try {    
            ps = con.getCnn().prepareStatement(SQL_EXTRAER);
            ps.setInt(1, Integer.parseInt(id.toString()));
            
            rs=ps.executeQuery();
            
            while(rs.next()){
                mdto= new MedidaDTO(rs.getInt(1), rs.getString(2), rs.getString(3));
            }
        } catch (SQLException ex) {
            Logger.getLogger(MedidaDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return mdto;//To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<MedidaDTO> extraerTodos() {
        PreparedStatement ps;
        ResultSet rs;
        MedidaDTO rdto=null;
        ArrayList<MedidaDTO> list=new ArrayList<MedidaDTO>();
        try {    
            ps = con.getCnn().prepareStatement(SQL_EXTRAERTODOS);
            rs=ps.executeQuery();
            
            while(rs.next()){
                rdto= extraer(rs.getInt(1));
                list.add(rdto);
            }
        } catch (SQLException ex) {
            Logger.getLogger(MedidaDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return list;//To change body of generated methods, choose Tools | Templates.
    }
    public boolean verificarexistencia(String area){
    
        PreparedStatement ps;
            ResultSet rs;
            MedidaDTO adto=null;
        try {    
            ps = con.getCnn().prepareStatement(SQL_VERIFICAREXISTENCIA);
            ps.setString(1, area);
            
            rs=ps.executeQuery();
            
            while(rs.next()){
                return false;
            }
        } catch (SQLException ex) {
            Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return true;
    }
}
