/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import conexion.Conexion;
import dto.MovimientoArticuloDTO;
import interfaces.Interfaz;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Ariel
 */
public class MovimientoArticuloDAO implements Interfaz<MovimientoArticuloDTO>{

    private static final String  SQL_INSERT="INSERT INTO movimientos_articulos (tipo_movimiento, nro_documento,id_usuario, fecha) VALUES (?,?,?,now())";
    private static final String  SQL_DELETE="DELETE FROM movimientos_articulos WHERE idmovimientos_articulos=?";
    private static final String  SQL_UPDATE="UPDATE movimientos_articulos SET fecha=?,tipo_movimiento=?, nro_documento=?,id_usuario=? WHERE idmovimientos_articulos=?";
    private static final String  SQL_EXTRAER="SELECT * FROM movimientos_articulos WHERE idmovimientos_articulos=?";
    private static final String  SQL_EXTRAERTODOS="SELECT idmovimientos_articulos FROM movimientos_articulos";
    private static final String  SQL_EXTRAERTODOSINGRESO="SELECT idmovimientos_articulos FROM movimientos_articulos WHERE tipo_movimiento=1";
    private static final String  SQL_EXTRAERTODOSEGRESO="SELECT idmovimientos_articulos FROM movimientos_articulos WHERE tipo_movimiento=2";
    private static final String  SQL_EXTRAERTODOSDOCUMENTO="SELECT idmovimientos_articulos FROM movimientos_articulos WHERE nro_documento=?";
    private static final String  SQL_EXTRAERTODOSUSUARIO="SELECT idmovimientos_articulos FROM movimientos_articulos WHERE id_usuario=?";
    private static final String  SQL_IDPEDIDO="SELECT MAX(idmovimientos_articulos) FROM movimientos_articulos WHERE id_usuario=?";
    
    private static final Conexion con = Conexion.saberEstado();
    
    @Override
    public boolean crear(MovimientoArticuloDTO c) {
        PreparedStatement ps;
            try {
            ps=con.getCnn().prepareStatement(SQL_INSERT);
            ps.setInt(1, c.getTipo_movimiento());
            ps.setString(2, c.getNro_documento());
            ps.setInt(3, c.getId_usuario());
            if(ps.executeUpdate()>0){
                return true;
            }

        } catch (SQLException ex) {
            Logger.getLogger(MovimientoArticuloDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return false; //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean borrar(Object id) {
        PreparedStatement ps;
        try {ps=con.getCnn().prepareStatement(SQL_DELETE);
            ps.setLong(1, Long.valueOf(id.toString()));
            
            if(ps.executeUpdate()>0){
                return true;
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(MovimientoArticuloDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return false; //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean actualizar(MovimientoArticuloDTO c) {
        PreparedStatement ps;
        try {
            ps=con.getCnn().prepareStatement(SQL_UPDATE);
            ps.setDate(1, (Date) c.getFecha());
            ps.setInt(2, c.getTipo_movimiento());
            ps.setString(3, c.getNro_documento());
            ps.setInt(4, c.getId_usuario());
            ps.setLong(5, c.getIdmovimientos_articulos());
            
            if(ps.executeUpdate()>0){
                return true;
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(MovimientoArticuloDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return false; //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public MovimientoArticuloDTO extraer(Object id) {
        PreparedStatement ps;
            ResultSet rs;
            MovimientoArticuloDTO adto=null;
        try {    
            ps = con.getCnn().prepareStatement(SQL_EXTRAER);
            ps.setLong(1, Long.valueOf(id.toString()));
            
            rs=ps.executeQuery();
            
            while(rs.next()){
                adto= new MovimientoArticuloDTO(rs.getLong(1), rs.getDate(2), rs.getInt(3), rs.getString(4), rs.getInt(5));
            }
        } catch (SQLException ex) {
            Logger.getLogger(MovimientoArticuloDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return adto; //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<MovimientoArticuloDTO> extraerTodos() {
        PreparedStatement ps;
        ResultSet rs;
        MovimientoArticuloDTO adto=null;
        ArrayList<MovimientoArticuloDTO> list=new ArrayList<MovimientoArticuloDTO>();
        try {    
            ps = con.getCnn().prepareStatement(SQL_EXTRAERTODOS);
            rs=ps.executeQuery();
            
            while(rs.next()){
                adto= extraer(rs.getLong(1));
                list.add(adto);
            }
        } catch (SQLException ex) {
            Logger.getLogger(MovimientoArticuloDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return list; //To change body of generated methods, choose Tools | Templates.
    }
    
    public List<MovimientoArticuloDTO> extraerTodosIngreso() {
        PreparedStatement ps;
        ResultSet rs;
        MovimientoArticuloDTO adto=null;
        ArrayList<MovimientoArticuloDTO> list=new ArrayList<MovimientoArticuloDTO>();
        try {    
            ps = con.getCnn().prepareStatement(SQL_EXTRAERTODOSINGRESO);
            rs=ps.executeQuery();
            
            while(rs.next()){
                adto= extraer(rs.getLong(1));
                list.add(adto);
            }
        } catch (SQLException ex) {
            Logger.getLogger(MovimientoArticuloDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return list; //To change body of generated methods, choose Tools | Templates.
    }
    
    public List<MovimientoArticuloDTO> extraerTodosEgreso() {
        PreparedStatement ps;
        ResultSet rs;
        MovimientoArticuloDTO adto=null;
        ArrayList<MovimientoArticuloDTO> list=new ArrayList<MovimientoArticuloDTO>();
        try {    
            ps = con.getCnn().prepareStatement(SQL_EXTRAERTODOSEGRESO);
            rs=ps.executeQuery();
            
            while(rs.next()){
                adto= extraer(rs.getLong(1));
                list.add(adto);
            }
        } catch (SQLException ex) {
            Logger.getLogger(MovimientoArticuloDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return list; //To change body of generated methods, choose Tools | Templates.
    }
    
    public List<MovimientoArticuloDTO> extraerTodosDocumento(String documento) {
        PreparedStatement ps;
        ResultSet rs;
        MovimientoArticuloDTO adto=null;
        ArrayList<MovimientoArticuloDTO> list=new ArrayList<MovimientoArticuloDTO>();
        try {    
            ps = con.getCnn().prepareStatement(SQL_EXTRAERTODOSDOCUMENTO);
            ps.setString(1, documento);
            rs=ps.executeQuery();
            
            while(rs.next()){
                adto= extraer(rs.getLong(1));
                list.add(adto);
            }
        } catch (SQLException ex) {
            Logger.getLogger(MovimientoArticuloDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return list; //To change body of generated methods, choose Tools | Templates.
    }
    
    public List<MovimientoArticuloDTO> extraerTodosUsuario(int usuario) {
        PreparedStatement ps;
        ResultSet rs;
        MovimientoArticuloDTO adto=null;
        ArrayList<MovimientoArticuloDTO> list=new ArrayList<MovimientoArticuloDTO>();
        try {    
            ps = con.getCnn().prepareStatement(SQL_EXTRAERTODOSUSUARIO);
            ps.setInt(1, usuario);
            rs=ps.executeQuery();
            
            while(rs.next()){
                adto= extraer(rs.getLong(1));
                list.add(adto);
            }
        } catch (SQLException ex) {
            Logger.getLogger(MovimientoArticuloDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return list; //To change body of generated methods, choose Tools | Templates.
    }
    
    public Long lastIdPedido(Object id_usuario){
        PreparedStatement ps;
            ResultSet rs;
            Long lastIdPedido=null;
        try {    
            ps = con.getCnn().prepareStatement(SQL_IDPEDIDO);
            ps.setInt(1, Integer.valueOf(id_usuario.toString()));
            
            rs=ps.executeQuery();
            
            while(rs.next()){
                lastIdPedido=  rs.getLong(1);
            }
        } catch (SQLException ex) {
            Logger.getLogger(SolicitudPedidoDetalleDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return lastIdPedido;
    
    }
}
