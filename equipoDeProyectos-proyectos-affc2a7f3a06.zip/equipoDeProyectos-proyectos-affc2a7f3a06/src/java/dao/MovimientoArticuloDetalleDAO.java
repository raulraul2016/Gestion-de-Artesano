/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import conexion.Conexion;
import dto.MovimientoArticuloDetalleDTO;
import interfaces.Interfaz;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Ariel
 */
public class MovimientoArticuloDetalleDAO implements Interfaz<MovimientoArticuloDetalleDTO>{

    private static final String  SQL_INSERT="INSERT INTO detalle_movimiento (id_movimiento_articulo, id_articulo, cantidad, precio) VALUES (?,?,?,?)";
    private static final String  SQL_DELETE="DELETE FROM detalle_movimiento WHERE id_detalle_movimiento=?";
    private static final String  SQL_UPDATE="UPDATE detalle_movimiento SET id_movimiento_articulo=?, id_articulo=?, cantidad=?, precio=? WHERE id_detalle_movimiento=?";
    private static final String  SQL_EXTRAER="SELECT * FROM detalle_movimiento WHERE id_detalle_movimiento=?";
    private static final String  SQL_EXTRAERTODOS="SELECT id_detalle_movimiento FROM detalle_movimiento";
    private static final String  SQL_EXTRAERTODOSF="SELECT id_detalle_movimiento FROM detalle_movimiento WHERE id_movimiento_articulo=?";
    
    private static final Conexion con = Conexion.saberEstado();
    
    @Override
    public boolean crear(MovimientoArticuloDetalleDTO c) {
        PreparedStatement ps;
            try {
            ps=con.getCnn().prepareStatement(SQL_INSERT);
            ps.setLong(1, c.getId_movimiento_articulo());
            ps.setLong(2, c.getId_articulo());
            ps.setInt(3, c.getCantidad());
            if(c.getPrecio()==null){
                ps.setNull(4, Types.DECIMAL);
            }else{
                ps.setDouble(4, c.getPrecio());
            }
            
            if(ps.executeUpdate()>0){
                return true;
            }

        } catch (SQLException ex) {
            Logger.getLogger(SolicitudEgresoDetalleDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return false; //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean borrar(Object id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean actualizar(MovimientoArticuloDetalleDTO c) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public MovimientoArticuloDetalleDTO extraer(Object id) {
        PreparedStatement ps;
            ResultSet rs;
            MovimientoArticuloDetalleDTO adto=null;
        try {    
            ps = con.getCnn().prepareStatement(SQL_EXTRAER);
            ps.setLong(1, Long.parseLong(id.toString()));
            
            rs=ps.executeQuery();
            
            while(rs.next()){
                adto= new MovimientoArticuloDetalleDTO(rs.getLong(1), rs.getLong(2), rs.getLong(3), rs.getInt(4), rs.getDouble(5));
            }
        } catch (SQLException ex) {
            Logger.getLogger(SolicitudEgresoDetalleDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return adto; //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<MovimientoArticuloDetalleDTO> extraerTodos() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    public List<MovimientoArticuloDetalleDTO> extraerTodosF(Long id_pedido) {
        PreparedStatement ps;
        ResultSet rs;
        MovimientoArticuloDetalleDTO adto=null;
        ArrayList<MovimientoArticuloDetalleDTO> list=new ArrayList<MovimientoArticuloDetalleDTO>();
        try {    
            ps = con.getCnn().prepareStatement(SQL_EXTRAERTODOSF);
            ps.setLong(1, id_pedido);
            rs=ps.executeQuery();
            
            while(rs.next()){
                adto= extraer(rs.getLong(1));
                list.add(adto);
            }
        } catch (SQLException ex) {
            Logger.getLogger(SolicitudEgresoDetalleDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return list; //To change body of generated methods, choose Tools | Templates.
    }
}
