/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import conexion.Conexion;
import dto.OrdenCompraDTO;
import interfaces.Interfaz;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Ariel
 */
public class OrdenCompraDAO implements Interfaz<OrdenCompraDTO>{
    
    private static final String  SQL_INSERT="INSERT INTO ordenes_compra (id_usuario,id_proveedor,detalle,fecha_creacion) VALUES (?,?,?,now())";
    private static final String  SQL_DELETE="DELETE FROM ordenes_compra WHERE id_orden_compra=?";
    private static final String  SQL_UPDATE="UPDATE ordenes_compra SET detalle=? WHERE id_orden_compra=?";
    private static final String  SQL_EXTRAER="SELECT * FROM ordenes_compra WHERE id_orden_compra=?";
    private static final String  SQL_EXTRAERTODOS="SELECT id_orden_compra FROM ordenes_compra order by fecha_creacion desc";
    private static final String  SQL_EXTRAERTODOSID="SELECT id_orden_compra FROM ordenes_compra WHERE id_orden_compra like concat('%',?,'%') order by fecha_creacion desc";
    private static final String  SQL_EXTRAERTODOSUSUARIO="SELECT id_orden_compra FROM ordenes_compra, usuarios WHERE ordenes_compra.id_usuario=usuarios.idusuarios && (usuarios.nombre like concat('%',?,'%')|| usuarios.apellido like concat('%',?,'%') )order by fecha_creacion desc";
    private static final String  SQL_EXTRAERTODOSPROVEEDOR="SELECT id_orden_compra FROM ordenes_compra, proveedores WHERE ordenes_compra.id_proveedor=proveedores.id_proveedor && proveedores.nombre_denominacion like concat('%',?,'%') order by fecha_creacion desc";
    private static final String  SQL_IDPEDIDO="SELECT MAX(id_orden_compra) FROM ordenes_compra WHERE id_usuario=?";
    private static final String  SQL_VERIFICAREXISTENCIA="SELECT * FROM ordenes_compra WHERE id_proveedor=?";
    
    private static final Conexion con = Conexion.saberEstado();

    @Override
    public boolean crear(OrdenCompraDTO c) {
        PreparedStatement ps;
            try {
            ps=con.getCnn().prepareStatement(SQL_INSERT);
            ps.setInt(1, c.getId_usuario());
            ps.setInt(2, c.getId_proveedor());
            ps.setString(3, c.getDetalle());
            
            if(ps.executeUpdate()>0){
                return true;
            }

        } catch (SQLException ex) {
            Logger.getLogger(OrdenCompraDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return false;//To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean borrar(Object id) {
        PreparedStatement ps;
        try {ps=con.getCnn().prepareStatement(SQL_DELETE);
            ps.setLong(1, Long.valueOf(id.toString()));
            
            if(ps.executeUpdate()>0){
                return true;
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(OrdenCompraDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return false; //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean actualizar(OrdenCompraDTO c) {
        PreparedStatement ps;
        try {
            ps=con.getCnn().prepareStatement(SQL_UPDATE);
            ps.setString(1, c.getDetalle());
            ps.setLong(2, c.getId_orden_compra());
            
            if(ps.executeUpdate()>0){
                return true;
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(OrdenCompraDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return false;//To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public OrdenCompraDTO extraer(Object id) {
        PreparedStatement ps;
            ResultSet rs;
            OrdenCompraDTO adto=null;
        try {    
            ps = con.getCnn().prepareStatement(SQL_EXTRAER);
            ps.setLong(1, Long.valueOf(id.toString()));
            
            rs=ps.executeQuery();
            
            while(rs.next()){
                adto= new OrdenCompraDTO(rs.getLong(1), rs.getInt(2), rs.getInt(3), rs.getString(4), rs.getDate(5));
            }
        } catch (SQLException ex) {
            Logger.getLogger(OrdenCompraDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return adto; //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<OrdenCompraDTO> extraerTodos() {
        PreparedStatement ps;
        ResultSet rs;
        OrdenCompraDTO adto=null;
        ArrayList<OrdenCompraDTO> list=new ArrayList<OrdenCompraDTO>();
        try {    
            ps = con.getCnn().prepareStatement(SQL_EXTRAERTODOS);
            rs=ps.executeQuery();
            
            while(rs.next()){
                adto= extraer(rs.getLong(1));
                list.add(adto);
            }
        } catch (SQLException ex) {
            Logger.getLogger(OrdenCompraDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return list;//To change body of generated methods, choose Tools | Templates.
    }
    
    public List<OrdenCompraDTO> extraerTodosPROVEEDOR(String cadena) {
        PreparedStatement ps;
        ResultSet rs;
        OrdenCompraDTO adto=null;
        ArrayList<OrdenCompraDTO> list=new ArrayList<OrdenCompraDTO>();
        try {    
            ps = con.getCnn().prepareStatement(SQL_EXTRAERTODOSPROVEEDOR);
            ps.setString(1, cadena);
            rs=ps.executeQuery();
            
            while(rs.next()){
                adto= extraer(rs.getLong(1));
                list.add(adto);
            }
        } catch (SQLException ex) {
            Logger.getLogger(OrdenCompraDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return list;//To change body of generated methods, choose Tools | Templates.
    }
    
    public List<OrdenCompraDTO> extraerTodosUSUARIO(String cadena) {
        PreparedStatement ps;
        ResultSet rs;
        OrdenCompraDTO adto=null;
        ArrayList<OrdenCompraDTO> list=new ArrayList<OrdenCompraDTO>();
        try {    
            ps = con.getCnn().prepareStatement(SQL_EXTRAERTODOSUSUARIO);
            ps.setString(1, cadena);
            ps.setString(2, cadena);
            rs=ps.executeQuery();
            
            while(rs.next()){
                adto= extraer(rs.getLong(1));
                list.add(adto);
            }
        } catch (SQLException ex) {
            Logger.getLogger(OrdenCompraDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return list;//To change body of generated methods, choose Tools | Templates.
    }
    
    public List<OrdenCompraDTO> extraerTodosID(Long id) {
        PreparedStatement ps;
        ResultSet rs;
        OrdenCompraDTO adto=null;
        ArrayList<OrdenCompraDTO> list=new ArrayList<OrdenCompraDTO>();
        try {    
            ps = con.getCnn().prepareStatement(SQL_EXTRAERTODOSID);
            ps.setLong(1, id);
            rs=ps.executeQuery();
            
            while(rs.next()){
                adto= extraer(rs.getLong(1));
                list.add(adto);
            }
        } catch (SQLException ex) {
            Logger.getLogger(OrdenCompraDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return list;//To change body of generated methods, choose Tools | Templates.
    }
    
    public Long lastIdPedido(int id_usuario){
        PreparedStatement ps;
            ResultSet rs;
            Long lastIdPedido=null;
        try {    
            ps = con.getCnn().prepareStatement(SQL_IDPEDIDO);
            ps.setInt(1, id_usuario);
            
            rs=ps.executeQuery();
            
            while(rs.next()){
                lastIdPedido=  rs.getLong(1);
            }
        } catch (SQLException ex) {
            Logger.getLogger(SolicitudPedidoDetalleDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return lastIdPedido;
    
    }
    
    public boolean verificarexistencia(int id_proveedor){
    
        PreparedStatement ps;
            ResultSet rs;
        try {    
            ps = con.getCnn().prepareStatement(SQL_VERIFICAREXISTENCIA);
            ps.setInt(1, id_proveedor);
            
            rs=ps.executeQuery();
            
            while(rs.next()){
                return true;
            }
        } catch (SQLException ex) {
            Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return false;
    }
}
