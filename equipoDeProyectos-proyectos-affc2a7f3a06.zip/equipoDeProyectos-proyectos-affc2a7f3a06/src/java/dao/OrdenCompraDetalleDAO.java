/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import conexion.Conexion;
import dto.OrdenCompraDetalleDTO;
import dto.SolicitudPedidoDTO;
import interfaces.Interfaz;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Ariel
 */
public class OrdenCompraDetalleDAO implements Interfaz<OrdenCompraDetalleDTO>{

    private static final String  SQL_INSERT="INSERT INTO orden_compra_detalle (id_orden_compra, id_articulo, cantidad) VALUES (?,?,?)";
    private static final String  SQL_DELETE="DELETE FROM orden_compra_detalle WHERE id_orden_compra_detalle=?"; 
    private static final String  SQL_UPDATE="UPDATE orden_compra_detalle SET cantidad_recibida=? WHERE id_orden_compra_detalle=?";
    private static final String  SQL_EXTRAER="SELECT * FROM orden_compra_detalle WHERE id_orden_compra_detalle=?";
    private static final String  SQL_EXTRAERTODOS="SELECT id_orden_compra_detalle FROM orden_compra_detalle WHERE id_orden_compra=? ";
    
    private static final Conexion con = Conexion.saberEstado();
    
    @Override
    public boolean crear(OrdenCompraDetalleDTO c) {
        PreparedStatement ps;
            try {
            ps=con.getCnn().prepareStatement(SQL_INSERT);
            ps.setLong(1, c.getId_orden_compra());
            ps.setLong(2, c.getId_articulo());
            ps.setInt(3, c.getCantidad());
            
            if(ps.executeUpdate()>0){
                return true;
            }

        } catch (SQLException ex) {
            Logger.getLogger(OrdenCompraDetalleDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return false; //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean borrar(Object id) {
        PreparedStatement ps;
        try {ps=con.getCnn().prepareStatement(SQL_DELETE);
            ps.setLong(1, Long.valueOf(id.toString()));
            
            if(ps.executeUpdate()>0){
                return true;
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(OrdenCompraDetalleDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return false; //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean actualizar(OrdenCompraDetalleDTO c) {
        PreparedStatement ps;
        try {
            ps=con.getCnn().prepareStatement(SQL_UPDATE);
            ps.setInt(1, c.getCantidad_recibida());
            ps.setLong(2, c.getId_orden_compra_detalle());
            
            if(ps.executeUpdate()>0){
                return true;
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(OrdenCompraDetalleDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return false; //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public OrdenCompraDetalleDTO extraer(Object id) {
        PreparedStatement ps;
            ResultSet rs;
            OrdenCompraDetalleDTO adto=null;
        try {    
            ps = con.getCnn().prepareStatement(SQL_EXTRAER);
            ps.setInt(1, Integer.parseInt(id.toString()));
            
            rs=ps.executeQuery();
            
            while(rs.next()){
                adto= new OrdenCompraDetalleDTO(rs.getLong(1), rs.getLong(2), rs.getLong(3), rs.getInt(4), rs.getInt(5));
            }
        } catch (SQLException ex) {
            Logger.getLogger(OrdenCompraDetalleDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return adto; //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<OrdenCompraDetalleDTO> extraerTodos() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    public List<OrdenCompraDetalleDTO> extraerTodosF(Long id_orden_compra) {
        PreparedStatement ps;
        ResultSet rs;
        OrdenCompraDetalleDTO adto=null;
        ArrayList<OrdenCompraDetalleDTO> list=new ArrayList<OrdenCompraDetalleDTO>();
        try {    
            ps = con.getCnn().prepareStatement(SQL_EXTRAERTODOS);
            ps.setLong(1, id_orden_compra);
            rs=ps.executeQuery();
            
            while(rs.next()){
                adto= extraer(rs.getLong(1));
                list.add(adto);
            }
        } catch (SQLException ex) {
            Logger.getLogger(OrdenCompraDetalleDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return list;//To change body of generated methods, choose Tools | Templates.
    }
    
    public boolean insertarDetalles(List<OrdenCompraDetalleDTO> detalles, List<Long>pedidosusados){
       PreparedStatement ps;
        try {
         //se deshabilita el modo de confirmación automática
             con.getCnn().setAutoCommit(false);            
             for(int i=0;i<detalles.size();i++){
                ps = con.getCnn().prepareStatement(SQL_INSERT);
                ps.setLong(1, detalles.get(i).getId_orden_compra());
                ps.setLong(2, detalles.get(i).getId_articulo());
                ps.setInt(3, detalles.get(i).getCantidad());
                ps.executeUpdate();
             }
             SolicitudPedidoDAO spdao=new SolicitudPedidoDAO();
             
             for(int i=0;i<pedidosusados.size();i++){
                 SolicitudPedidoDTO spdto= spdao.extraer(pedidosusados.get(i));
                 spdto.setEstado(4);
                 if(!spdao.actualizar(spdto)){
                   return false;  
                 }
             }
            //se indica que se deben aplicar los cambios en la base de datos
            con.getCnn().commit();
            
        } catch (SQLException ex) {
                 Logger.getLogger(OrdenCompraDetalleDAO.class.getName()).log(Level.SEVERE, null, ex);
           try {
               con.getCnn().rollback();
           } catch (SQLException ex1) {
               Logger.getLogger(OrdenCompraDetalleDAO.class.getName()).log(Level.SEVERE, null, ex1);
           }
            }finally{
             con.cerrarConexion();
             }
    return true;
    }
}
