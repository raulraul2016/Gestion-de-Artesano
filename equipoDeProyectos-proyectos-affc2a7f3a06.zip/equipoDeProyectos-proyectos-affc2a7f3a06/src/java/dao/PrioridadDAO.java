/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import conexion.Conexion;
import dto.PrioridadDTO;
import interfaces.Interfaz;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Ariel
 */
public class PrioridadDAO implements Interfaz<PrioridadDTO> {

    private static final String  SQL_EXTRAER="SELECT * FROM prioridades WHERE idprioridades=?";
    private static final String  SQL_EXTRAERTODOS="SELECT idprioridades FROM prioridades ";
    
    private static final Conexion con = Conexion.saberEstado();
    
    @Override
    public boolean crear(PrioridadDTO c) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean borrar(Object id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean actualizar(PrioridadDTO c) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public PrioridadDTO extraer(Object id) {
        PreparedStatement ps;
            ResultSet rs;
            PrioridadDTO rto=null;
        try {    
            ps = con.getCnn().prepareStatement(SQL_EXTRAER);
            ps.setLong(1, Long.parseLong(id.toString()));
            
            rs=ps.executeQuery();
            
            while(rs.next()){
                rto= new PrioridadDTO(rs.getInt(1), rs.getString(2));
            }
        } catch (SQLException ex) {
            Logger.getLogger(PrioridadDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return rto; //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<PrioridadDTO> extraerTodos() {
        PreparedStatement ps;
        ResultSet rs;
        PrioridadDTO rto=null;
        ArrayList<PrioridadDTO> list=new ArrayList<PrioridadDTO>();
        try {    
            ps = con.getCnn().prepareStatement(SQL_EXTRAERTODOS);
            rs=ps.executeQuery();
            
            while(rs.next()){
                rto= extraer(rs.getString(1));
                list.add(rto);
            }
        } catch (SQLException ex) {
            Logger.getLogger(PrioridadDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return list; //To change body of generated methods, choose Tools | Templates.
    }
    
}
