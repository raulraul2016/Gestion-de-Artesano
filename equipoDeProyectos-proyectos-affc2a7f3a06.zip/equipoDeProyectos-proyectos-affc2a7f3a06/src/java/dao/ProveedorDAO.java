/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import conexion.Conexion;
import dto.ProveedorDTO;
import interfaces.Interfaz;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author yesi
 */
public class ProveedorDAO implements Interfaz<ProveedorDTO>{

    private static final String  SQL_INSERT="INSERT INTO proveedores (nombre_denominacion, direccion, cuit, telefono, mail, descripcion) VALUES (?,?,?,?,?,?)";
    private static final String  SQL_DELETE="DELETE FROM proveedores WHERE id_proveedor=?";
    private static final String  SQL_UPDATE="UPDATE proveedores SET nombre_denominacion=?, direccion=?, cuit=?, telefono=?, mail=?, descripcion=? , activo=? WHERE id_proveedor=?";
    private static final String  SQL_EXTRAER="SELECT * FROM proveedores WHERE id_proveedor=?";
    private static final String  SQL_EXTRAERTODOS="SELECT id_proveedor FROM proveedores ";
    private static final String  SQL_EXTRAERTODOSCombustible="SELECT proveedores.id_proveedor FROM proveedores, rubros , proveedores_rubro WHERE proveedores.id_proveedor=proveedores_rubro.id_proveedor AND proveedores_rubro.id_rubro=rubros.id_rubro AND rubros.nombre='Combustible'";
    private static final String  SQL_VERIFICAREXISTENCIA="SELECT * FROM proveedores WHERE nombre_denominacion=?";
    private static final String  SQL_IDPEDIDO="SELECT MAX(id_proveedor) FROM proveedores";
    
    private static final Conexion con = Conexion.saberEstado();
    
    @Override
    public boolean crear(ProveedorDTO c) {
        PreparedStatement ps;
            try {
            ps=con.getCnn().prepareStatement(SQL_INSERT);
            ps.setString(1, c.getNombre_denominacion());
            ps.setString(2, c.getDireccion());
            ps.setString(3, c.getCuit());
            ps.setString(4, c.getTelefono());
            ps.setString(5, c.getMail());
            ps.setString(6, c.getDescripcion());
            
            if(ps.executeUpdate()>0){
                return true;
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(ProveedorDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return false; //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean borrar(Object id) {
        PreparedStatement ps;
        try {ps=con.getCnn().prepareStatement(SQL_DELETE);
            ps.setInt(1, Integer.parseInt(id.toString()));
            
            if(ps.executeUpdate()>0){
                return true;
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(ProveedorDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return false;//To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean actualizar(ProveedorDTO c) {
        PreparedStatement ps;
        try {
            ps=con.getCnn().prepareStatement(SQL_UPDATE);
            ps.setString(1, c.getNombre_denominacion());
            ps.setString(2, c.getDireccion());
            ps.setString(3, c.getCuit());
            ps.setString(4, c.getTelefono());
            ps.setString(5, c.getMail());
            ps.setString(6, c.getDescripcion());
            ps.setBoolean(7, c.isActivo());
            ps.setLong(8, c.getId_proveedor());
            
            
            if(ps.executeUpdate()>0){
                return true;
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(ProveedorDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return false;//To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public ProveedorDTO extraer(Object id) {
        PreparedStatement ps;
            ResultSet rs;
            ProveedorDTO pdto=null;
        try {    
            ps = con.getCnn().prepareStatement(SQL_EXTRAER);
            ps.setInt(1, Integer.parseInt(id.toString()));
            
            rs=ps.executeQuery();
            
            while(rs.next()){
                pdto= new ProveedorDTO(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getBoolean(8));
            }
        } catch (SQLException ex) {
            Logger.getLogger(ProveedorDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return pdto;//To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<ProveedorDTO> extraerTodos() {
        PreparedStatement ps;
        ResultSet rs;
        ProveedorDTO pdto=null;
        ArrayList<ProveedorDTO> list=new ArrayList<ProveedorDTO>();
        try {    
            ps = con.getCnn().prepareStatement(SQL_EXTRAERTODOS);
            rs=ps.executeQuery();
            
            while(rs.next()){
                pdto= extraer(rs.getInt(1));
                list.add(pdto);
            }
        } catch (SQLException ex) {
            Logger.getLogger(ProveedorDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return list;//To change body of generated methods, choose Tools | Templates.
    }
    
    public List<ProveedorDTO> extraerTodosCombustible() {
        PreparedStatement ps;
        ResultSet rs;
        ProveedorDTO pdto=null;
        ArrayList<ProveedorDTO> list=new ArrayList<ProveedorDTO>();
        try {    
            ps = con.getCnn().prepareStatement(SQL_EXTRAERTODOSCombustible);
            rs=ps.executeQuery();
            
            while(rs.next()){
                pdto= extraer(rs.getInt(1));
                list.add(pdto);
            }
        } catch (SQLException ex) {
            Logger.getLogger(ProveedorDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return list;//To change body of generated methods, choose Tools | Templates.
    }
    
    public boolean verificarexistencia(String area){
    
        PreparedStatement ps;
            ResultSet rs;
            ProveedorDTO adto=null;
        try {    
            ps = con.getCnn().prepareStatement(SQL_VERIFICAREXISTENCIA);
            ps.setString(1, area);
            
            rs=ps.executeQuery();
            
            while(rs.next()){
                return false;
            }
        } catch (SQLException ex) {
            Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return true;
    }
    
    public int lastIdPedido(){
        PreparedStatement ps;
            ResultSet rs;
            int lastIdPedido=0;
        try {    
            
            ps = con.getCnn().prepareStatement(SQL_IDPEDIDO);            
            rs=ps.executeQuery();
            
            while(rs.next()){
                lastIdPedido=  rs.getInt(1);
            }
        } catch (SQLException ex) {
            Logger.getLogger(SolicitudPedidoDetalleDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return lastIdPedido;
    
    }
}
