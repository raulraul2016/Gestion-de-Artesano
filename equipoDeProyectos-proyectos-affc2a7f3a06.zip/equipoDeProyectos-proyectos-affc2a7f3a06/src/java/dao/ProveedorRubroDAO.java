/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import conexion.Conexion;
import dto.ProveedorRubroDTO;
import interfaces.Interfaz;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Ariel
 */
public class ProveedorRubroDAO implements Interfaz<ProveedorRubroDTO>{

    private static final String  SQL_INSERT="INSERT INTO proveedores_rubro (id_proveedor, id_rubro) VALUES (?,?)";
    private static final String  SQL_DELETE="DELETE FROM proveedores_rubro WHERE idproveedor_rubro=?";
    private static final String  SQL_UPDATE="UPDATE proveedores_rubro SET id_proveedor=?,id_rubro=? WHERE idproveedor_rubro=?";
    private static final String  SQL_EXTRAER="SELECT * FROM proveedores_rubro WHERE idproveedor_rubro=?";
    private static final String  SQL_EXTRAERTODOS="SELECT idproveedor_rubro FROM proveedores_rubro ";
    private static final String  SQL_EXTRAERTODOSPRO="SELECT idproveedor_rubro FROM proveedores_rubro WHERE id_proveedor=? ";
    private static final String  SQL_VERIFICAREXISTENCIA="SELECT * FROM proveedores_rubro WHERE id_proveedor=? && id_rubro=?";
    
    private static final Conexion con = Conexion.saberEstado();
    
    @Override
    public boolean crear(ProveedorRubroDTO c) {
        PreparedStatement ps;
            try {
            con.getCnn().setAutoCommit(false);
            ps=con.getCnn().prepareStatement(SQL_INSERT);
            ps.setInt(1, c.getId_proveedor());
            ps.setInt(2, c.getId_rubro());
            
            if(ps.executeUpdate()>0){
                con.getCnn().commit();
                return true;
            }

        } catch (SQLException ex) {
            Logger.getLogger(ProveedorRubroDAO.class.getName()).log(Level.SEVERE, null, ex);
            try {
                con.getCnn().rollback();
            } catch (SQLException ex1) {
                Logger.getLogger(ProveedorRubroDAO.class.getName()).log(Level.SEVERE, null, ex1);
            }
        }finally{
            con.cerrarConexion();
        }
        return false; //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean borrar(Object id) {
        PreparedStatement ps;
        try {
            con.getCnn().setAutoCommit(false);
            ps=con.getCnn().prepareStatement(SQL_DELETE);
            ps.setInt(1, Integer.parseInt(id.toString()));
            
            if(ps.executeUpdate()>0){
                con.getCnn().commit();
                return true;
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(ProveedorRubroDAO.class.getName()).log(Level.SEVERE, null, ex);
            try {
                con.getCnn().rollback();
            } catch (SQLException ex1) {
                Logger.getLogger(ProveedorRubroDAO.class.getName()).log(Level.SEVERE, null, ex1);
            }
        }finally{
            con.cerrarConexion();
        }
        return false; //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean actualizar(ProveedorRubroDTO c) {
        PreparedStatement ps;
        try {
            con.getCnn().setAutoCommit(false);
            ps=con.getCnn().prepareStatement(SQL_UPDATE);
            ps.setInt(1, c.getId_proveedor());
            ps.setInt(2, c.getId_rubro());
            ps.setInt(3, c.getIdproveedor_rubro());
            
            if(ps.executeUpdate()>0){
                con.getCnn().commit();
                return true;
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(ProveedorRubroDAO.class.getName()).log(Level.SEVERE, null, ex);
            try {
                con.getCnn().rollback();
            } catch (SQLException ex1) {
                Logger.getLogger(ProveedorRubroDAO.class.getName()).log(Level.SEVERE, null, ex1);
            }
        }finally{
            con.cerrarConexion();
        }
        return false; //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public ProveedorRubroDTO extraer(Object id) {
            PreparedStatement ps;
            ResultSet rs;
            ProveedorRubroDTO adto=null;
        try { 
            con.getCnn().setAutoCommit(false);
            ps = con.getCnn().prepareStatement(SQL_EXTRAER);
            ps.setInt(1, Integer.parseInt(id.toString()));
            
            rs=ps.executeQuery();
            con.getCnn().commit();
            
            while(rs.next()){
                adto= new ProveedorRubroDTO(rs.getInt(1), rs.getInt(2), rs.getInt(3));
            }
        } catch (SQLException ex) {
            Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE, null, ex);
            try {
                con.getCnn().rollback();
            } catch (SQLException ex1) {
                Logger.getLogger(ProveedorRubroDAO.class.getName()).log(Level.SEVERE, null, ex1);
            }
        }finally{
            con.cerrarConexion();
        }
        return adto; //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<ProveedorRubroDTO> extraerTodos() {
        PreparedStatement ps;
        ResultSet rs;
        ProveedorRubroDTO adto=null;
        ArrayList<ProveedorRubroDTO> list=new ArrayList<ProveedorRubroDTO>();
        try {    
            con.getCnn().setAutoCommit(false);
            ps = con.getCnn().prepareStatement(SQL_EXTRAERTODOS);
            rs=ps.executeQuery();
            con.getCnn().commit();
            while(rs.next()){
                adto= extraer(rs.getInt(1));
                list.add(adto);
            }
        } catch (SQLException ex) {
            Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE, null, ex);
            try {
                con.getCnn().rollback();
            } catch (SQLException ex1) {
                Logger.getLogger(ProveedorRubroDAO.class.getName()).log(Level.SEVERE, null, ex1);
            }
        }finally{
            con.cerrarConexion();
        }
        return list; //To change body of generated methods, choose Tools | Templates.
    }
    
    public List<ProveedorRubroDTO> extraerTodosPRO(int id_proveedor) {
        PreparedStatement ps;
        ResultSet rs;
        ProveedorRubroDTO adto=null;
        ArrayList<ProveedorRubroDTO> list=new ArrayList<ProveedorRubroDTO>();
        try {    
            con.getCnn().setAutoCommit(false);
            ps = con.getCnn().prepareStatement(SQL_EXTRAERTODOSPRO);
            ps.setInt(1, id_proveedor);
            rs=ps.executeQuery();
            con.getCnn().commit();
            while(rs.next()){
                adto= extraer(rs.getInt(1));
                list.add(adto);
            }
        } catch (SQLException ex) {
            Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE, null, ex);
            try {
                con.getCnn().rollback();
            } catch (SQLException ex1) {
                Logger.getLogger(ProveedorRubroDAO.class.getName()).log(Level.SEVERE, null, ex1);
            }
        }finally{
            con.cerrarConexion();
        }
        return list; //To change body of generated methods, choose Tools | Templates.
    }
    
    public boolean verificarexistencia(ProveedorRubroDTO adto){
    
        PreparedStatement ps;
            ResultSet rs;
        try { 
            con.getCnn().setAutoCommit(false);
            ps = con.getCnn().prepareStatement(SQL_VERIFICAREXISTENCIA);
            ps.setInt(1, adto.getId_proveedor());
            ps.setInt(2, adto.getId_rubro());
            rs=ps.executeQuery();
            con.getCnn().commit();
            while(rs.next()){
                return false;
            }
        } catch (SQLException ex) {
            Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE, null, ex);
            try {
                con.getCnn().rollback();
            } catch (SQLException ex1) {
                Logger.getLogger(ProveedorRubroDAO.class.getName()).log(Level.SEVERE, null, ex1);
            }
        }finally{
            con.cerrarConexion();
        }
        return true;
    }
}
