/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import conexion.Conexion;
import dto.RemitoDTO;
import interfaces.Interfaz;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Ariel
 */
public class RemitoDAO implements Interfaz<RemitoDTO>{

    private static final String  SQL_INSERT="INSERT INTO remitos (id_proveedor,id_orden_compra_asociada,id_usuario,nro_remito,fecha_ingreso) VALUES (?,?,?,?,now())";
    private static final String  SQL_DELETE="DELETE FROM remitos WHERE id_remitos=?";
    private static final String  SQL_UPDATE="UPDATE remitos SET id_proveedor=?,id_orden_compra_asociada=?,id_usuario=?,nro_remito=? WHERE id_remitos=?";
    private static final String  SQL_EXTRAER="SELECT * FROM remitos WHERE id_remitos=?";
    private static final String  SQL_EXTRAERTODOS="SELECT id_remitos FROM remitos order by fecha_ingreso desc";
    private static final String  SQL_EXTRAERTODOSRemito="SELECT id_remitos FROM remitos WHERE nro_remito like concat('%',?,'%')order by fecha_ingreso desc";
    private static final String  SQL_IDPEDIDO="SELECT MAX(id_remitos) FROM remitos WHERE id_usuario=?";
    
    private static final Conexion con = Conexion.saberEstado();
    
    @Override
    public boolean crear(RemitoDTO c) {
        PreparedStatement ps;
            try {
            ps=con.getCnn().prepareStatement(SQL_INSERT);
            ps.setInt(1, c.getId_proveedor());
            ps.setLong(2, c.getId_orden_compra_asociada());
            ps.setInt(3, c.getId_usuario());
            ps.setString(4, c.getNro_remito());
            
            if(ps.executeUpdate()>0){
                return true;
            }

        } catch (SQLException ex) {
            Logger.getLogger(RemitoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return false; //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean borrar(Object id) {
        PreparedStatement ps;
        try {ps=con.getCnn().prepareStatement(SQL_DELETE);
            ps.setLong(1, Long.valueOf(id.toString()));
            
            if(ps.executeUpdate()>0){
                return true;
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(RemitoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return false; //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean actualizar(RemitoDTO c) {
        PreparedStatement ps;
        try {
            ps=con.getCnn().prepareStatement(SQL_UPDATE);
            ps.setInt(1, c.getId_proveedor());
            ps.setLong(2, c.getId_orden_compra_asociada());
            ps.setInt(3, c.getId_usuario());
            ps.setString(4, c.getNro_remito());
            ps.setLong(5, c.getId_remito());
            
            if(ps.executeUpdate()>0){
                return true;
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(RemitoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return false; //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public RemitoDTO extraer(Object id) {
        PreparedStatement ps;
            ResultSet rs;
            RemitoDTO adto=null;
        try {    
            ps = con.getCnn().prepareStatement(SQL_EXTRAER);
            ps.setLong(1, Long.valueOf(id.toString()));
            
            rs=ps.executeQuery();
            
            while(rs.next()){
                adto= new RemitoDTO(rs.getLong(1), rs.getInt(2), rs.getLong(3), rs.getInt(4), rs.getString(5), rs.getDate(6));
            }
        } catch (SQLException ex) {
            Logger.getLogger(RemitoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return adto;//To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<RemitoDTO> extraerTodos() {
        PreparedStatement ps;
        ResultSet rs;
        RemitoDTO adto=null;
        ArrayList<RemitoDTO> list=new ArrayList<RemitoDTO>();
        try {    
            ps = con.getCnn().prepareStatement(SQL_EXTRAERTODOS);
            rs=ps.executeQuery();
            
            while(rs.next()){
                adto= extraer(rs.getLong(1));
                list.add(adto);
            }
        } catch (SQLException ex) {
            Logger.getLogger(RemitoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return list; //To change body of generated methods, choose Tools | Templates.
    }
    public List<RemitoDTO> extraerTodosNROremito(String nro_remito) {
        PreparedStatement ps;
        ResultSet rs;
        RemitoDTO adto=null;
        ArrayList<RemitoDTO> list=new ArrayList<RemitoDTO>();
        try {    
            ps = con.getCnn().prepareStatement(SQL_EXTRAERTODOSRemito);
            ps.setString(1, nro_remito);
            rs=ps.executeQuery();
            
            while(rs.next()){
                adto= extraer(rs.getLong(1));
                list.add(adto);
            }
        } catch (SQLException ex) {
            Logger.getLogger(RemitoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return list; //To change body of generated methods, choose Tools | Templates.
    }
    public Long lastId(int id_usuario){
        PreparedStatement ps;
            ResultSet rs;
            Long lastIdPedido=null;
        try {    
            ps = con.getCnn().prepareStatement(SQL_IDPEDIDO);
            ps.setInt(1, id_usuario);
            
            rs=ps.executeQuery();
            
            while(rs.next()){
                lastIdPedido=  rs.getLong(1);
            }
        } catch (SQLException ex) {
            Logger.getLogger(SolicitudPedidoDetalleDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return lastIdPedido;
    
    }
}
