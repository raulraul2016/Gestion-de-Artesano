/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import conexion.Conexion;
import dto.RemitoDetalleDTO;
import interfaces.Interfaz;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Ariel
 */
public class RemitoDetalleDAO implements Interfaz<RemitoDetalleDTO> {

    private static final String  SQL_INSERT="INSERT INTO detalles_remito (id_remito, id_articulo, cantidad, precio) VALUES (?,?,?,?)";
    private static final String  SQL_DELETE="DELETE FROM detalles_remito WHERE id_detalles_remito=?"; 
    private static final String  SQL_UPDATE="UPDATE detalles_remito SET id_remito=?, id_articulo=?, cantidad=?, precio=? WHERE id_detalles_remito=?";
    private static final String  SQL_EXTRAER="SELECT * FROM detalles_remito WHERE id_detalles_remito=?";
    private static final String  SQL_EXTRAERTODOS="SELECT id_detalles_remito FROM detalles_remito WHERE id_remito=? ";
    
    private static final Conexion con = Conexion.saberEstado();

    @Override
    public boolean crear(RemitoDetalleDTO c) {
        PreparedStatement ps;
            try {
            ps=con.getCnn().prepareStatement(SQL_INSERT);
            ps.setLong(1, c.getId_remito());
            ps.setLong(2, c.getId_articulo());
            ps.setInt(3, c.getCantidad());
            if(c.getPrecio()==null){
            ps.setNull(4, Types.DOUBLE);
            }else{
            ps.setDouble(4, c.getPrecio());}
            
            if(ps.executeUpdate()>0){
                return true;
            }

        } catch (SQLException ex) {
            Logger.getLogger(RemitoDetalleDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return false; //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean borrar(Object id) {
        PreparedStatement ps;
        try {ps=con.getCnn().prepareStatement(SQL_DELETE);
            ps.setLong(1, Long.valueOf(id.toString()));
            
            if(ps.executeUpdate()>0){
                return true;
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(RemitoDetalleDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return false; //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean actualizar(RemitoDetalleDTO c) {
        PreparedStatement ps;
        try {
            ps=con.getCnn().prepareStatement(SQL_UPDATE);
            ps.setLong(1, c.getId_remito());
            ps.setLong(2, c.getId_articulo());
            ps.setInt(3, c.getCantidad());
            ps.setDouble(4, c.getPrecio());
            ps.setLong(5, c.getId_detalle_remito());
            
            if(ps.executeUpdate()>0){
                return true;
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(RemitoDetalleDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return false; //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public RemitoDetalleDTO extraer(Object id) {
        PreparedStatement ps;
            ResultSet rs;
            RemitoDetalleDTO adto=null;
        try {    
            ps = con.getCnn().prepareStatement(SQL_EXTRAER);
            ps.setInt(1, Integer.parseInt(id.toString()));
            
            rs=ps.executeQuery();
            
            while(rs.next()){
                adto= new RemitoDetalleDTO(rs.getLong(1), rs.getLong(2), rs.getLong(3), rs.getInt(4), rs.getDouble(5));
            }
        } catch (SQLException ex) {
            Logger.getLogger(RemitoDetalleDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return adto; //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<RemitoDetalleDTO> extraerTodos() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    public List<RemitoDetalleDTO> extraerTodosF(Long id_orden_compra) {
        PreparedStatement ps;
        ResultSet rs;
        RemitoDetalleDTO adto=null;
        ArrayList<RemitoDetalleDTO> list=new ArrayList<RemitoDetalleDTO>();
        try {    
            ps = con.getCnn().prepareStatement(SQL_EXTRAERTODOS);
            ps.setLong(1, id_orden_compra);
            rs=ps.executeQuery();
            
            while(rs.next()){
                adto= extraer(rs.getLong(1));
                list.add(adto);
            }
        } catch (SQLException ex) {
            Logger.getLogger(RemitoDetalleDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return list;//To change body of generated methods, choose Tools | Templates.
    }
}
