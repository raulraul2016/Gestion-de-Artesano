/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import conexion.Conexion;
import dto.RubroDTO;
import interfaces.Interfaz;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author yesi
 */
public class RubroDAO implements Interfaz<RubroDTO>{

    private static final String  SQL_INSERT="INSERT INTO rubros (nombre) VALUES (?)";
    private static final String  SQL_DELETE="DELETE FROM rubros WHERE id_rubro=?";
    private static final String  SQL_UPDATE="UPDATE rubros SET nombre=? WHERE id_rubro=?";
    private static final String  SQL_EXTRAER="SELECT * FROM rubros WHERE id_rubro=?";
    private static final String  SQL_EXTRAERTODOS="SELECT id_rubro FROM rubros ";
    private static final String  SQL_VERIFICAREXISTENCIA="SELECT * FROM rubros WHERE nombre=?";
    
    
    private static final Conexion con = Conexion.saberEstado();
    @Override
    public boolean crear(RubroDTO c) {
        PreparedStatement ps;
            try {
            ps=con.getCnn().prepareStatement(SQL_INSERT);
            ps.setString(1, c.getNombre());
            
            if(ps.executeUpdate()>0){
                return true;
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(RubroDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return false;//To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean borrar(Object id) {
        PreparedStatement ps;
        try {ps=con.getCnn().prepareStatement(SQL_DELETE);
            ps.setInt(1, Integer.parseInt(id.toString()));
            
            if(ps.executeUpdate()>0){
                return true;
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(RubroDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return false; //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean actualizar(RubroDTO c) {
        PreparedStatement ps;
        try {
            ps=con.getCnn().prepareStatement(SQL_UPDATE);
            ps.setString(1, c.getNombre());
            ps.setLong(2, c.getId_rubro());
            
            if(ps.executeUpdate()>0){
                return true;
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(ProveedorDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return false;//To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public RubroDTO extraer(Object id) {
        PreparedStatement ps;
            ResultSet rs;
            RubroDTO rdto=null;
        try {    
            ps = con.getCnn().prepareStatement(SQL_EXTRAER);
            ps.setInt(1, Integer.parseInt(id.toString()));
            
            rs=ps.executeQuery();
            
            while(rs.next()){
                rdto= new RubroDTO(rs.getInt(1), rs.getString(2));
            }
        } catch (SQLException ex) {
            Logger.getLogger(RubroDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return rdto;//To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<RubroDTO> extraerTodos() {
        PreparedStatement ps;
        ResultSet rs;
        RubroDTO rdto=null;
        ArrayList<RubroDTO> list=new ArrayList<RubroDTO>();
        try {    
            ps = con.getCnn().prepareStatement(SQL_EXTRAERTODOS);
            rs=ps.executeQuery();
            
            while(rs.next()){
                rdto= extraer(rs.getInt(1));
                list.add(rdto);
            }
        } catch (SQLException ex) {
            Logger.getLogger(RubroDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return list;//To change body of generated methods, choose Tools | Templates.
    }
    public boolean verificarexistencia(String area){
    
        PreparedStatement ps;
            ResultSet rs;
            RubroDTO adto=null;
        try {    
            ps = con.getCnn().prepareStatement(SQL_VERIFICAREXISTENCIA);
            ps.setString(1, area);
            
            rs=ps.executeQuery();
            
            while(rs.next()){
                return false;
            }
        } catch (SQLException ex) {
            Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return true;
    }
}
