/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import conexion.Conexion;
import dto.SolicitudEgresoCombustibleDTO;
import interfaces.Interfaz;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import static util.Util.dateToSqlDate;

/**
 *
 * @author Ariel
 */
public class SolicitudEgresoCombustibleDAO implements Interfaz<SolicitudEgresoCombustibleDTO>{

    private static final String  SQL_INSERT="INSERT INTO solicitud_egreso_combustible (id_usuario, id_area_origen, estado, expendedor, chofer, destino, motivo, km_salida, km_llegada, fecha) VALUES (?,?,?,?,?,?,?,?,?,now())";
    private static final String  SQL_DELETE="DELETE FROM solicitud_egreso_combustible WHERE idsolicitud_egreso_combustible=?";
    private static final String  SQL_UPDATE="UPDATE solicitud_egreso_combustible SET estado=? WHERE idsolicitud_egreso_combustible=?";
    private static final String  SQL_EXTRAER="SELECT * FROM solicitud_egreso_combustible WHERE idsolicitud_egreso_combustible=?";
    private static final String  SQL_EXTRAERTODOS="SELECT idsolicitud_egreso_combustible FROM pedidos_ipalar.solicitud_egreso_combustible order by fecha desc";
    private static final String  SQL_EXTRAERTODOSPENDIENTES="SELECT idsolicitud_egreso_combustible FROM solicitud_egreso_combustible WHERE estado=1 order by fecha desc";
    private static final String  SQL_EXTRAERTODOSAREA="SELECT idsolicitud_egreso_combustible FROM solicitud_egreso_combustible WHERE id_area_origen=? order by fecha desc";
    private static final String  SQL_EXTRAERTODOSAREAESTADO="SELECT idsolicitud_egreso_combustible FROM solicitud_egreso_combustible WHERE id_area_origen=? and estado=? order by fecha desc";
    private static final String  SQL_IDPEDIDO="SELECT MAX(idsolicitud_egreso_combustible) FROM solicitud_egreso_combustible WHERE id_usuario=?";
    private static final String  SQL_ANULAR="UPDATE solicitud_egreso_combustible SET estado=? WHERE idsolicitud_egreso_combustible=?";
    private static final String  SQL_RECIBIR="UPDATE solicitud_egreso_combustible SET estado=? WHERE idsolicitud_egreso_combustible=?";
    private static final Conexion con = Conexion.saberEstado();
    
    @Override
    public boolean crear(SolicitudEgresoCombustibleDTO c) {
        PreparedStatement ps;
            try {
            ps=con.getCnn().prepareStatement(SQL_INSERT);
            ps.setInt(1, c.getId_usuario());
            ps.setInt(2, c.getId_area_origen());
            ps.setInt(3, c.getEstado());
            ps.setString(4, c.getExpendedor());
            ps.setString(5, c.getChofer());
            ps.setString(6, c.getDestino());
            ps.setString(7, c.getMotivo());
            ps.setInt(8, c.getKm_salida());
            ps.setInt(9, c.getKm_llegada());
            if(ps.executeUpdate()>0){
                return true;
            }

        } catch (SQLException ex) {
            Logger.getLogger(SolicitudEgresoCombustibleDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return false; //To change body of generated methods, choose Tools | Templates.
    }

    public boolean crear2(SolicitudEgresoCombustibleDTO c, Connection con) {
        PreparedStatement ps;
            try {
            ps=con.prepareStatement(SQL_INSERT);
            ps.setInt(1, c.getId_usuario());
            ps.setInt(2, c.getId_area_origen());
            ps.setInt(3, c.getEstado());
            ps.setString(4, c.getExpendedor());
            ps.setString(5, c.getChofer());
            ps.setString(6, c.getDestino());
            ps.setString(7, c.getMotivo());
            ps.setInt(8, c.getKm_salida());
            ps.setInt(9, c.getKm_llegada());
            if(ps.executeUpdate()>0){
                return true;
            }

        } catch (SQLException ex) {
            Logger.getLogger(SolicitudEgresoCombustibleDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false; //To change body of generated methods, choose Tools | Templates.
    }
    
    @Override
    public boolean borrar(Object id) {
        PreparedStatement ps;
        try {ps=con.getCnn().prepareStatement(SQL_DELETE);
            ps.setLong(1, Long.valueOf(id.toString()));
            
            if(ps.executeUpdate()>0){
                return true;
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(SolicitudEgresoCombustibleDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return false; //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean actualizar(SolicitudEgresoCombustibleDTO c) {
        PreparedStatement ps;
        try {
            ps=con.getCnn().prepareStatement(SQL_UPDATE);
            ps.setInt(1, c.getEstado());
            ps.setLong(2, c.getIdsolicitud_egreso_combustible());
            
            if(ps.executeUpdate()>0){
                return true;
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(SolicitudEgresoCombustibleDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return false; //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public SolicitudEgresoCombustibleDTO extraer(Object id) {
            PreparedStatement ps;
            ResultSet rs;
            SolicitudEgresoCombustibleDTO adto=null;
        try {    
            ps = con.getCnn().prepareStatement(SQL_EXTRAER);
            ps.setLong(1, Long.parseLong(id.toString()));
            
            rs=ps.executeQuery();
            
            while(rs.next()){
                adto= new SolicitudEgresoCombustibleDTO(rs.getLong(1), rs.getInt(2), rs.getInt(3), rs.getInt(4), rs.getString(5), rs.getDate(6), rs.getString(7), rs.getString(8),rs.getString(9), rs.getInt(10),rs.getInt(11));
            }
        } catch (SQLException ex) {
            Logger.getLogger(SolicitudEgresoCombustibleDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return adto; //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<SolicitudEgresoCombustibleDTO> extraerTodos() {
        PreparedStatement ps;
        ResultSet rs;
        SolicitudEgresoCombustibleDTO adto=null;
        ArrayList<SolicitudEgresoCombustibleDTO> list=new ArrayList<SolicitudEgresoCombustibleDTO>();
        try {    
            ps = con.getCnn().prepareStatement(SQL_EXTRAERTODOS);
            rs=ps.executeQuery();
            
            while(rs.next()){
                adto= extraer(rs.getLong(1));
                list.add(adto);
            }
        } catch (SQLException ex) {
            Logger.getLogger(SolicitudEgresoCombustibleDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return list; //To change body of generated methods, choose Tools | Templates.
    }
    
    public List<SolicitudEgresoCombustibleDTO> extraerTodosPendientes() {
        PreparedStatement ps;
        ResultSet rs;
        SolicitudEgresoCombustibleDTO adto=null;
        ArrayList<SolicitudEgresoCombustibleDTO> list=new ArrayList<SolicitudEgresoCombustibleDTO>();
        try {    
            ps = con.getCnn().prepareStatement(SQL_EXTRAERTODOSPENDIENTES);
            rs=ps.executeQuery();
            
            while(rs.next()){
                adto= extraer(rs.getLong(1));
                list.add(adto);
            }
        } catch (SQLException ex) {
            Logger.getLogger(SolicitudEgresoCombustibleDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return list; //To change body of generated methods, choose Tools | Templates.
    }
    
    public List<SolicitudEgresoCombustibleDTO> extraerTodosArea(int area) {
        PreparedStatement ps;
        ResultSet rs;
        SolicitudEgresoCombustibleDTO adto=null;
        ArrayList<SolicitudEgresoCombustibleDTO> list=new ArrayList<SolicitudEgresoCombustibleDTO>();
        try {    
            ps = con.getCnn().prepareStatement(SQL_EXTRAERTODOSAREA);
            ps.setInt(1, area);
            rs=ps.executeQuery();
            
            while(rs.next()){
                adto= extraer(rs.getLong(1));
                list.add(adto);
            }
        } catch (SQLException ex) {
            Logger.getLogger(SolicitudEgresoCombustibleDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return list; //To change body of generated methods, choose Tools | Templates.
    }
    
    public List<SolicitudEgresoCombustibleDTO> extraerTodosAreaEstado(int area, int estado) {
        PreparedStatement ps;
        ResultSet rs;
        SolicitudEgresoCombustibleDTO adto=null;
        ArrayList<SolicitudEgresoCombustibleDTO> list=new ArrayList<SolicitudEgresoCombustibleDTO>();
        try {    
            ps = con.getCnn().prepareStatement(SQL_EXTRAERTODOSAREAESTADO);
            ps.setInt(1, area);
            ps.setInt(2, estado);
            rs=ps.executeQuery();
            
            while(rs.next()){
                adto= extraer(rs.getLong(1));
                list.add(adto);
            }
        } catch (SQLException ex) {
            Logger.getLogger(SolicitudEgresoCombustibleDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return list; //To change body of generated methods, choose Tools | Templates.
    }
    
    public List<SolicitudEgresoCombustibleDTO> extraerTodosFILTRO(String where) {
        PreparedStatement ps;
        ResultSet rs;
        SolicitudEgresoCombustibleDTO adto=null;
        ArrayList<SolicitudEgresoCombustibleDTO> list=new ArrayList<SolicitudEgresoCombustibleDTO>();
        try {    
            String sql="SELECT idsolicitud_egreso_combustible FROM solicitud_egreso_combustible"+where;
            ps = con.getCnn().prepareStatement(sql);
            rs=ps.executeQuery();
            
            while(rs.next()){
                adto= extraer(rs.getLong(1));
                list.add(adto);
            }
        } catch (SQLException ex) {
            Logger.getLogger(SolicitudEgresoCombustibleDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return list; //To change body of generated methods, choose Tools | Templates.
    }
    
    public Long lastIdPedido(int id_usuario){
        PreparedStatement ps;
            ResultSet rs;
            Long lastIdPedido=null;
        try {    
            ps = con.getCnn().prepareStatement(SQL_IDPEDIDO);
            ps.setInt(1, id_usuario);
            
            rs=ps.executeQuery();
            
            while(rs.next()){
                lastIdPedido=  rs.getLong(1);
            }
        } catch (SQLException ex) {
            Logger.getLogger(SolicitudPedidoDetalleDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return lastIdPedido;
    
    }
    public boolean anular(SolicitudEgresoCombustibleDTO c) {
        PreparedStatement ps;
        try {
            ps=con.getCnn().prepareStatement(SQL_ANULAR);
            ps.setInt(1, c.getEstado());
            ps.setLong(2, c.getIdsolicitud_egreso_combustible());
            
            if(ps.executeUpdate()>0){
                return true;
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(SolicitudEgresoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return false; //To change body of generated methods, choose Tools | Templates.
    }
    public boolean recibir(SolicitudEgresoCombustibleDTO c) {
        PreparedStatement ps;
        try {
            ps=con.getCnn().prepareStatement(SQL_RECIBIR);
            ps.setInt(1, c.getEstado());
            ps.setLong(2, c.getIdsolicitud_egreso_combustible());
            
            if(ps.executeUpdate()>0){
                return true;
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(SolicitudEgresoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return false; //To change body of generated methods, choose Tools | Templates.
    }
}
