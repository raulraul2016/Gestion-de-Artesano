/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import conexion.Conexion;
import dto.MovimientoArticuloDTO;
import dto.SolicitudEgresoDTO;
import interfaces.Interfaz;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import static util.Util.dateToSqlDate;

/**
 *
 * @author Ariel
 */
public class SolicitudEgresoDAO implements Interfaz<SolicitudEgresoDTO>{

    private static final String  SQL_INSERT="INSERT INTO solicitud_egreso (id_usuario, estado, id_area_origen, id_centro_costo_destino, id_item_centro_costo_destino,fecha_creacion) VALUES (?,?,?,?,?,now())";
    private static final String  SQL_DELETE="DELETE FROM solicitud_egreso WHERE id_solicitud_egreso=?";
    private static final String  SQL_UPDATE="UPDATE solicitud_egreso SET estado=?, fecha_modificacion=now() WHERE id_solicitud_egreso=?";
    private static final String  SQL_RECIBIR="UPDATE solicitud_egreso SET estado=?, fecha_modificacion=now() WHERE id_solicitud_egreso=?";
    private static final String  SQL_ENTREGAR="UPDATE solicitud_egreso SET estado=?, fecha_modificacion=now(), retira=? WHERE id_solicitud_egreso=?";
    private static final String  SQL_ANULAR="UPDATE solicitud_egreso SET estado=?, fecha_anulacion=now() WHERE id_solicitud_egreso=?";
    private static final String  SQL_EXTRAER="SELECT * FROM solicitud_egreso WHERE id_solicitud_egreso=?";
    private static final String  SQL_EXTRAERTODOS="SELECT id_solicitud_egreso FROM solicitud_egreso";
    private static final String  SQL_EXTRAERTODOSI="SELECT id_solicitud_egreso FROM solicitud_egreso WHERE estado=1 and id_solicitud_egreso like concat('%',?,'%')";
    private static final String  SQL_EXTRAERTODOSITODOS="SELECT id_solicitud_egreso FROM solicitud_egreso WHERE id_solicitud_egreso like concat('%',?,'%')";
    private static final String  SQL_EXTRAERTODOSF="SELECT id_solicitud_egreso FROM solicitud_egreso, usuarios WHERE solicitud_egreso.id_usuario=usuarios.idusuarios and usuarios.area=?";
    private static final String  SQL_EXTRAERTODOSID="SELECT id_solicitud_egreso FROM solicitud_egreso, usuarios WHERE solicitud_egreso.id_usuario=usuarios.idusuarios and usuarios.area=? and id_solicitud_egreso like concat('%',?,'%')";
    private static final String  SQL_EXTRAERTODOSESTADO="SELECT id_solicitud_egreso FROM solicitud_egreso, usuarios WHERE solicitud_egreso.id_usuario=usuarios.idusuarios and usuarios.area=? and estado=?";
    private static final String  SQL_EXTRAERTODOSESTADOTODOS="SELECT id_solicitud_egreso FROM solicitud_egreso WHERE estado=?";
    private static final String  SQL_EXTRAERTODOSCENTROCOSTO="SELECT id_solicitud_egreso FROM solicitud_egreso, usuarios WHERE solicitud_egreso.id_usuario=usuarios.idusuarios and usuarios.area=? and id_centro_costo_destino=?";
    private static final String  SQL_EXTRAERTODOSCENTROCOSTOP="SELECT id_solicitud_egreso FROM solicitud_egreso WHERE  id_centro_costo_destino=? and estado=1";
    private static final String  SQL_EXTRAERTODOSCENTROCOSTOTODOS="SELECT id_solicitud_egreso FROM solicitud_egreso WHERE  id_centro_costo_destino=?";
    private static final String  SQL_EXTRAERTODOSCENTROCOSTOITEMTODOS="SELECT id_solicitud_egreso FROM solicitud_egreso WHERE  id_item_centro_costo_destino=?";
    private static final String  SQL_EXTRAERTODOSCENTROCOSTOAPRO="SELECT id_solicitud_egreso FROM solicitud_egreso WHERE  id_centro_costo_destino=? and estado=3";
    private static final String  SQL_EXTRAERTODOSCENTROCOSTOITEMAPRO="SELECT id_solicitud_egreso FROM solicitud_egreso WHERE  id_item_centro_costo_destino=? and estado=3";
    private static final String  SQL_EXTRAERTODOSCENTROCOSTOITEMP="SELECT id_solicitud_egreso FROM solicitud_egreso WHERE  id_item_centro_costo_destino=? and estado=1";
    private static final String  SQL_EXTRAERTODOSCENTROCOSTOITEM="SELECT id_solicitud_egreso FROM solicitud_egreso, usuarios WHERE solicitud_egreso.id_usuario=usuarios.idusuarios and usuarios.area=? and id_item_centro_costo_destino=?";
    private static final String  SQL_EXTRAERTODOSLOCALIDAD="SELECT id_solicitud_egreso FROM solicitud_egreso, usuarios , centros_costo WHERE solicitud_egreso.id_centro_costo_destino=centros_costo.id_centros_costo and solicitud_egreso.id_usuario=usuarios.idusuarios and usuarios.area=? and centros_costo.id_localidad=?";
    private static final String  SQL_EXTRAERTODOSLOCALIDADs="SELECT id_solicitud_egreso FROM solicitud_egreso, centros_costo WHERE solicitud_egreso.id_centro_costo_destino=centros_costo.id_centros_costo and centros_costo.id_localidad=? and estado=1";
    private static final String  SQL_EXTRAERTODOSLOCALIDADTODOS="SELECT id_solicitud_egreso FROM solicitud_egreso, centros_costo WHERE solicitud_egreso.id_centro_costo_destino=centros_costo.id_centros_costo and centros_costo.id_localidad=?";
    private static final String  SQL_EXTRAERTODOSLOCALIDADAPRO="SELECT id_solicitud_egreso FROM solicitud_egreso, centros_costo WHERE solicitud_egreso.id_centro_costo_destino=centros_costo.id_centros_costo and centros_costo.id_localidad=? and estado=3";
    private static final String  SQL_EXTRAERTODOSP="SELECT id_solicitud_egreso FROM solicitud_egreso WHERE estado=1";
    private static final String  SQL_EXTRAERTODOSA="SELECT id_solicitud_egreso FROM solicitud_egreso WHERE estado=3";
    private static final String  SQL_EXTRAERTODOSAPRO="SELECT id_solicitud_egreso FROM solicitud_egreso WHERE estado=3 and id_solicitud_egreso like concat('%',?,'%')";
    private static final String  SQL_EXTRAERTODOSAREA="SELECT id_solicitud_egreso FROM solicitud_egreso WHERE id_area_origen=? and estado=1";
    private static final String  SQL_EXTRAERTODOSAREATODOS="SELECT id_solicitud_egreso FROM solicitud_egreso WHERE id_area_origen=?";
    private static final String  SQL_EXTRAERTODOSAREAAPRO="SELECT id_solicitud_egreso FROM solicitud_egreso WHERE id_area_origen=? and estado=3";
    private static final String  SQL_IDPEDIDO="SELECT MAX(id_solicitud_egreso) FROM solicitud_egreso WHERE id_usuario=?";
    private static final Conexion con = Conexion.saberEstado();
    
    @Override
    public boolean crear(SolicitudEgresoDTO c) {
        PreparedStatement ps;
            try {
            ps=con.getCnn().prepareStatement(SQL_INSERT);
            ps.setInt(1, c.getId_usuario());
            ps.setInt(2, c.getEstado());
            ps.setInt(3, c.getId_area_origen());
            if(c.getId_centro_costo_destino()==0){
            ps.setNull(4, Types.BIGINT);    
            }else{
            ps.setLong(4, c.getId_centro_costo_destino());}
            if(c.getId_item_centro_costo_destino()==0){
            ps.setNull(5, Types.BIGINT);    
            }else{
            ps.setLong(5, c.getId_item_centro_costo_destino());}
            
            
            if(ps.executeUpdate()>0){
                return true;
            }

        } catch (SQLException ex) {
            Logger.getLogger(SolicitudEgresoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return false; //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean borrar(Object id) {
        PreparedStatement ps;
        try {ps=con.getCnn().prepareStatement(SQL_DELETE);
            ps.setLong(1, Long.valueOf(id.toString()));
            
            if(ps.executeUpdate()>0){
                return true;
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(SolicitudEgresoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return false; //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean actualizar(SolicitudEgresoDTO c) {
        PreparedStatement ps;
        try {
            ps=con.getCnn().prepareStatement(SQL_UPDATE);
            ps.setInt(1, c.getEstado());
            ps.setLong(2, c.getId_solicitud_egreso());
            
            if(ps.executeUpdate()>0){
                return true;
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(SolicitudEgresoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return false; //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public SolicitudEgresoDTO extraer(Object id) {
        PreparedStatement ps;
            ResultSet rs;
            SolicitudEgresoDTO adto=null;
        try {    
            ps = con.getCnn().prepareStatement(SQL_EXTRAER);
            ps.setLong(1, Long.parseLong(id.toString()));
            
            rs=ps.executeQuery();
            
            while(rs.next()){
                adto= new SolicitudEgresoDTO(rs.getLong(1), rs.getInt(2), rs.getInt(3), rs.getInt(4), rs.getLong(5), rs.getLong(6),dateToSqlDate(rs.getDate(7)), dateToSqlDate(rs.getDate(8)), dateToSqlDate(rs.getDate(9)), rs.getString(10));
            }
        } catch (SQLException ex) {
            Logger.getLogger(SolicitudEgresoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return adto; //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<SolicitudEgresoDTO> extraerTodos() {
        PreparedStatement ps;
        ResultSet rs;
        SolicitudEgresoDTO adto=null;
        ArrayList<SolicitudEgresoDTO> list=new ArrayList<SolicitudEgresoDTO>();
        try {    
            ps = con.getCnn().prepareStatement(SQL_EXTRAERTODOS);
            rs=ps.executeQuery();
            
            while(rs.next()){
                adto= extraer(rs.getLong(1));
                list.add(adto);
            }
        } catch (SQLException ex) {
            Logger.getLogger(SolicitudEgresoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return list;//To change body of generated methods, choose Tools | Templates.
    }
    
    public List<SolicitudEgresoDTO> extraerTodosCentroCostoTodos(Long id) {
        PreparedStatement ps;
        ResultSet rs;
        SolicitudEgresoDTO adto=null;
        ArrayList<SolicitudEgresoDTO> list=new ArrayList<SolicitudEgresoDTO>();
        try {    
            ps = con.getCnn().prepareStatement(SQL_EXTRAERTODOSCENTROCOSTOTODOS);
            ps.setLong(1, id);
            rs=ps.executeQuery();
            
            while(rs.next()){
                adto= extraer(rs.getLong(1));
                list.add(adto);
            }
        } catch (SQLException ex) {
            Logger.getLogger(SolicitudEgresoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return list;//To change body of generated methods, choose Tools | Templates.
    }
    
    public List<SolicitudEgresoDTO> extraerTodosCentroCostoItemTodos(Long id) {
        PreparedStatement ps;
        ResultSet rs;
        SolicitudEgresoDTO adto=null;
        ArrayList<SolicitudEgresoDTO> list=new ArrayList<SolicitudEgresoDTO>();
        try {    
            ps = con.getCnn().prepareStatement(SQL_EXTRAERTODOSCENTROCOSTOITEMTODOS);
            ps.setLong(1, id);
            rs=ps.executeQuery();
            
            while(rs.next()){
                adto= extraer(rs.getLong(1));
                list.add(adto);
            }
        } catch (SQLException ex) {
            Logger.getLogger(SolicitudEgresoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return list;//To change body of generated methods, choose Tools | Templates.
    }
    
    public List<SolicitudEgresoDTO> extraerTodosLocalidadTodos(Long id) {
        PreparedStatement ps;
        ResultSet rs;
        SolicitudEgresoDTO adto=null;
        ArrayList<SolicitudEgresoDTO> list=new ArrayList<SolicitudEgresoDTO>();
        try {    
            ps = con.getCnn().prepareStatement(SQL_EXTRAERTODOSLOCALIDADTODOS);
            ps.setLong(1, id);
            rs=ps.executeQuery();
            
            while(rs.next()){
                adto= extraer(rs.getLong(1));
                list.add(adto);
            }
        } catch (SQLException ex) {
            Logger.getLogger(SolicitudEgresoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return list;//To change body of generated methods, choose Tools | Templates.
    }
    
    public List<SolicitudEgresoDTO> extraerTodos(Long id) {
        PreparedStatement ps;
        ResultSet rs;
        SolicitudEgresoDTO adto=null;
        ArrayList<SolicitudEgresoDTO> list=new ArrayList<SolicitudEgresoDTO>();
        try {    
            ps = con.getCnn().prepareStatement(SQL_EXTRAERTODOSITODOS);
            ps.setLong(1, id);
            rs=ps.executeQuery();
            
            while(rs.next()){
                adto= extraer(rs.getLong(1));
                list.add(adto);
            }
        } catch (SQLException ex) {
            Logger.getLogger(SolicitudEgresoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return list;//To change body of generated methods, choose Tools | Templates.
    }
    
    public List<SolicitudEgresoDTO> extraerTodosEstado(int id) {
        PreparedStatement ps;
        ResultSet rs;
        SolicitudEgresoDTO adto=null;
        ArrayList<SolicitudEgresoDTO> list=new ArrayList<SolicitudEgresoDTO>();
        try {    
            ps = con.getCnn().prepareStatement(SQL_EXTRAERTODOSESTADOTODOS);
            ps.setInt(1, id);
            rs=ps.executeQuery();
            
            while(rs.next()){
                adto= extraer(rs.getLong(1));
                list.add(adto);
            }
        } catch (SQLException ex) {
            Logger.getLogger(SolicitudEgresoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return list;//To change body of generated methods, choose Tools | Templates.
    }
    
    public List<SolicitudEgresoDTO> extraerTodosAreaTodos(int id) {
        PreparedStatement ps;
        ResultSet rs;
        SolicitudEgresoDTO adto=null;
        ArrayList<SolicitudEgresoDTO> list=new ArrayList<SolicitudEgresoDTO>();
        try {    
            ps = con.getCnn().prepareStatement(SQL_EXTRAERTODOSAREATODOS);
            ps.setInt(1, id);
            rs=ps.executeQuery();
            
            while(rs.next()){
                adto= extraer(rs.getLong(1));
                list.add(adto);
            }
        } catch (SQLException ex) {
            Logger.getLogger(SolicitudEgresoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return list;//To change body of generated methods, choose Tools | Templates.
    }
    
    public List<SolicitudEgresoDTO> extraerTodosAreas(int id) {
        PreparedStatement ps;
        ResultSet rs;
        SolicitudEgresoDTO adto=null;
        ArrayList<SolicitudEgresoDTO> list=new ArrayList<SolicitudEgresoDTO>();
        try {    
            ps = con.getCnn().prepareStatement(SQL_EXTRAERTODOSAREA);
            ps.setInt(1, id);
            rs=ps.executeQuery();
            
            while(rs.next()){
                adto= extraer(rs.getLong(1));
                list.add(adto);
            }
        } catch (SQLException ex) {
            Logger.getLogger(SolicitudEgresoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return list;//To change body of generated methods, choose Tools | Templates.
    }
    
    public List<SolicitudEgresoDTO> extraerTodosCCostoPen(Long id) {
        PreparedStatement ps;
        ResultSet rs;
        SolicitudEgresoDTO adto=null;
        ArrayList<SolicitudEgresoDTO> list=new ArrayList<SolicitudEgresoDTO>();
        try {    
            ps = con.getCnn().prepareStatement(SQL_EXTRAERTODOSCENTROCOSTOP);
            ps.setLong(1, id);
            rs=ps.executeQuery();
            
            while(rs.next()){
                adto= extraer(rs.getLong(1));
                list.add(adto);
            }
        } catch (SQLException ex) {
            Logger.getLogger(SolicitudEgresoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return list;//To change body of generated methods, choose Tools | Templates.
    }
    
    public List<SolicitudEgresoDTO> extraerTodosCCostoItemPen(Long id) {
        PreparedStatement ps;
        ResultSet rs;
        SolicitudEgresoDTO adto=null;
        ArrayList<SolicitudEgresoDTO> list=new ArrayList<SolicitudEgresoDTO>();
        try {    
            ps = con.getCnn().prepareStatement(SQL_EXTRAERTODOSCENTROCOSTOITEMP);
            ps.setLong(1, id);
            rs=ps.executeQuery();
            
            while(rs.next()){
                adto= extraer(rs.getLong(1));
                list.add(adto);
            }
        } catch (SQLException ex) {
            Logger.getLogger(SolicitudEgresoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return list;//To change body of generated methods, choose Tools | Templates.
    }
    
    public List<SolicitudEgresoDTO> extraerTodosI(Long id) {
        PreparedStatement ps;
        ResultSet rs;
        SolicitudEgresoDTO adto=null;
        ArrayList<SolicitudEgresoDTO> list=new ArrayList<SolicitudEgresoDTO>();
        try {    
            ps = con.getCnn().prepareStatement(SQL_EXTRAERTODOSI);
            ps.setLong(1, id);
            rs=ps.executeQuery();
            
            while(rs.next()){
                adto= extraer(rs.getLong(1));
                list.add(adto);
            }
        } catch (SQLException ex) {
            Logger.getLogger(SolicitudEgresoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return list;//To change body of generated methods, choose Tools | Templates.
    }
    
    public List<SolicitudEgresoDTO> extraerTodosID(int area, Long id) {
        PreparedStatement ps;
        ResultSet rs;
        SolicitudEgresoDTO adto=null;
        ArrayList<SolicitudEgresoDTO> list=new ArrayList<SolicitudEgresoDTO>();
        try {    
            ps = con.getCnn().prepareStatement(SQL_EXTRAERTODOSID);
            ps.setInt(1, area);
            ps.setLong(2, id);
            rs=ps.executeQuery();
            
            while(rs.next()){
                adto= extraer(rs.getLong(1));
                list.add(adto);
            }
        } catch (SQLException ex) {
            Logger.getLogger(SolicitudEgresoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return list;//To change body of generated methods, choose Tools | Templates.
    }
    
    public List<SolicitudEgresoDTO> extraerTodosCentroCosto(int area, Long id) {
        PreparedStatement ps;
        ResultSet rs;
        SolicitudEgresoDTO adto=null;
        ArrayList<SolicitudEgresoDTO> list=new ArrayList<SolicitudEgresoDTO>();
        try {    
            ps = con.getCnn().prepareStatement(SQL_EXTRAERTODOSCENTROCOSTO);
            ps.setInt(1, area);
            ps.setLong(2, id);
            rs=ps.executeQuery();
            
            while(rs.next()){
                adto= extraer(rs.getLong(1));
                list.add(adto);
            }
        } catch (SQLException ex) {
            Logger.getLogger(SolicitudEgresoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return list;//To change body of generated methods, choose Tools | Templates.
    }
    
    public List<SolicitudEgresoDTO> extraerTodosCentroCostoItem(int area, Long id) {
        PreparedStatement ps;
        ResultSet rs;
        SolicitudEgresoDTO adto=null;
        ArrayList<SolicitudEgresoDTO> list=new ArrayList<SolicitudEgresoDTO>();
        try {    
            ps = con.getCnn().prepareStatement(SQL_EXTRAERTODOSCENTROCOSTOITEM);
            ps.setInt(1, area);
            ps.setLong(2, id);
            rs=ps.executeQuery();
            
            while(rs.next()){
                adto= extraer(rs.getLong(1));
                list.add(adto);
            }
        } catch (SQLException ex) {
            Logger.getLogger(SolicitudEgresoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return list;//To change body of generated methods, choose Tools | Templates.
    }
    
    public List<SolicitudEgresoDTO> extraerTodosLocalidad(int area, int id) {
        PreparedStatement ps;
        ResultSet rs;
        SolicitudEgresoDTO adto=null;
        ArrayList<SolicitudEgresoDTO> list=new ArrayList<SolicitudEgresoDTO>();
        try {    
            ps = con.getCnn().prepareStatement(SQL_EXTRAERTODOSLOCALIDAD);
            ps.setInt(1, area);
            ps.setInt(2, id);
            rs=ps.executeQuery();
            
            while(rs.next()){
                adto= extraer(rs.getLong(1));
                list.add(adto);
            }
        } catch (SQLException ex) {
            Logger.getLogger(SolicitudEgresoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return list;//To change body of generated methods, choose Tools | Templates.
    }
    
    public List<SolicitudEgresoDTO> extraerTodosLocalidads(int id) {
        PreparedStatement ps;
        ResultSet rs;
        SolicitudEgresoDTO adto=null;
        ArrayList<SolicitudEgresoDTO> list=new ArrayList<SolicitudEgresoDTO>();
        try {    
            ps = con.getCnn().prepareStatement(SQL_EXTRAERTODOSLOCALIDADs);
            ps.setInt(1, id);
            rs=ps.executeQuery();
            
            while(rs.next()){
                adto= extraer(rs.getLong(1));
                list.add(adto);
            }
        } catch (SQLException ex) {
            Logger.getLogger(SolicitudEgresoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return list;//To change body of generated methods, choose Tools | Templates.
    }
    
    public List<SolicitudEgresoDTO> extraerTodosEstado(int area, int estado) {
        PreparedStatement ps;
        ResultSet rs;
        SolicitudEgresoDTO adto=null;
        ArrayList<SolicitudEgresoDTO> list=new ArrayList<SolicitudEgresoDTO>();
        try {    
            ps = con.getCnn().prepareStatement(SQL_EXTRAERTODOSESTADO);
            ps.setInt(1, area);
            ps.setLong(2, estado);
            rs=ps.executeQuery();
            
            while(rs.next()){
                adto= extraer(rs.getLong(1));
                list.add(adto);
            }
        } catch (SQLException ex) {
            Logger.getLogger(SolicitudEgresoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return list;//To change body of generated methods, choose Tools | Templates.
    }
    
    public List<SolicitudEgresoDTO> extraerTodosArea(int area) {
        PreparedStatement ps;
        ResultSet rs;
        SolicitudEgresoDTO adto=null;
        ArrayList<SolicitudEgresoDTO> list=new ArrayList<SolicitudEgresoDTO>();
        try {    
            ps = con.getCnn().prepareStatement(SQL_EXTRAERTODOSF);
            ps.setInt(1, area);
            rs=ps.executeQuery();
            
            while(rs.next()){
                adto= extraer(rs.getLong(1));
                list.add(adto);
            }
        } catch (SQLException ex) {
            Logger.getLogger(SolicitudEgresoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return list;//To change body of generated methods, choose Tools | Templates.
    }
    public List<SolicitudEgresoDTO> extraerTodosPendientes() {
        PreparedStatement ps;
        ResultSet rs;
        SolicitudEgresoDTO adto=null;
        ArrayList<SolicitudEgresoDTO> list=new ArrayList<SolicitudEgresoDTO>();
        try {    
            ps = con.getCnn().prepareStatement(SQL_EXTRAERTODOSP);
            rs=ps.executeQuery();
            
            while(rs.next()){
                adto= extraer(rs.getLong(1));
                list.add(adto);
            }
        } catch (SQLException ex) {
            Logger.getLogger(SolicitudEgresoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return list;//To change body of generated methods, choose Tools | Templates.
    }
    
    public List<SolicitudEgresoDTO> extraerTodosAprobados() {
        PreparedStatement ps;
        ResultSet rs;
        SolicitudEgresoDTO adto=null;
        ArrayList<SolicitudEgresoDTO> list=new ArrayList<SolicitudEgresoDTO>();
        try {    
            ps = con.getCnn().prepareStatement(SQL_EXTRAERTODOSA);
            rs=ps.executeQuery();
            
            while(rs.next()){
                adto= extraer(rs.getLong(1));
                list.add(adto);
            }
        } catch (SQLException ex) {
            Logger.getLogger(SolicitudEgresoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return list;//To change body of generated methods, choose Tools | Templates.
    }
    
    public List<SolicitudEgresoDTO> extraerTodosAprobados(Long id) {
        PreparedStatement ps;
        ResultSet rs;
        SolicitudEgresoDTO adto=null;
        ArrayList<SolicitudEgresoDTO> list=new ArrayList<SolicitudEgresoDTO>();
        try {    
            ps = con.getCnn().prepareStatement(SQL_EXTRAERTODOSAPRO);
            ps.setLong(1, id);
            rs=ps.executeQuery();
            
            while(rs.next()){
                adto= extraer(rs.getLong(1));
                list.add(adto);
            }
        } catch (SQLException ex) {
            Logger.getLogger(SolicitudEgresoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return list;//To change body of generated methods, choose Tools | Templates.
    }
    
    public List<SolicitudEgresoDTO> extraerTodosAprobadosArea(int id) {
        PreparedStatement ps;
        ResultSet rs;
        SolicitudEgresoDTO adto=null;
        ArrayList<SolicitudEgresoDTO> list=new ArrayList<SolicitudEgresoDTO>();
        try {    
            ps = con.getCnn().prepareStatement(SQL_EXTRAERTODOSAREAAPRO);
            ps.setInt(1, id);
            rs=ps.executeQuery();
            
            while(rs.next()){
                adto= extraer(rs.getLong(1));
                list.add(adto);
            }
        } catch (SQLException ex) {
            Logger.getLogger(SolicitudEgresoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return list;//To change body of generated methods, choose Tools | Templates.
    }
    
    public List<SolicitudEgresoDTO> extraerTodosAprobadosLocalidad(int id) {
        PreparedStatement ps;
        ResultSet rs;
        SolicitudEgresoDTO adto=null;
        ArrayList<SolicitudEgresoDTO> list=new ArrayList<SolicitudEgresoDTO>();
        try {    
            ps = con.getCnn().prepareStatement(SQL_EXTRAERTODOSLOCALIDADAPRO);
            ps.setInt(1, id);
            rs=ps.executeQuery();
            
            while(rs.next()){
                adto= extraer(rs.getLong(1));
                list.add(adto);
            }
        } catch (SQLException ex) {
            Logger.getLogger(SolicitudEgresoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return list;//To change body of generated methods, choose Tools | Templates.
    }
    
    public List<SolicitudEgresoDTO> extraerTodosAprobadosCentroCosto(Long id) {
        PreparedStatement ps;
        ResultSet rs;
        SolicitudEgresoDTO adto=null;
        ArrayList<SolicitudEgresoDTO> list=new ArrayList<SolicitudEgresoDTO>();
        try {    
            ps = con.getCnn().prepareStatement(SQL_EXTRAERTODOSCENTROCOSTOAPRO);
            ps.setLong(1, id);
            rs=ps.executeQuery();
            
            while(rs.next()){
                adto= extraer(rs.getLong(1));
                list.add(adto);
            }
        } catch (SQLException ex) {
            Logger.getLogger(SolicitudEgresoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return list;//To change body of generated methods, choose Tools | Templates.
    }
    
    public List<SolicitudEgresoDTO> extraerTodosAprobadosCentroCostoItem(Long id) {
        PreparedStatement ps;
        ResultSet rs;
        SolicitudEgresoDTO adto=null;
        ArrayList<SolicitudEgresoDTO> list=new ArrayList<SolicitudEgresoDTO>();
        try {    
            ps = con.getCnn().prepareStatement(SQL_EXTRAERTODOSCENTROCOSTOITEMAPRO);
            ps.setLong(1, id);
            rs=ps.executeQuery();
            
            while(rs.next()){
                adto= extraer(rs.getLong(1));
                list.add(adto);
            }
        } catch (SQLException ex) {
            Logger.getLogger(SolicitudEgresoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return list;//To change body of generated methods, choose Tools | Templates.
    }
    
    public Long lastIdPedido(int id_usuario){
        PreparedStatement ps;
            ResultSet rs;
            Long lastIdPedido=null;
        try {    
            ps = con.getCnn().prepareStatement(SQL_IDPEDIDO);
            ps.setInt(1, id_usuario);
            
            rs=ps.executeQuery();
            
            while(rs.next()){
                lastIdPedido=  rs.getLong(1);
            }
        } catch (SQLException ex) {
            Logger.getLogger(SolicitudPedidoDetalleDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return lastIdPedido;
    
    }
    
    public boolean anular(SolicitudEgresoDTO c) {
        PreparedStatement ps;
        try {
            ps=con.getCnn().prepareStatement(SQL_ANULAR);
            ps.setInt(1, c.getEstado());
            ps.setLong(2, c.getId_solicitud_egreso());
            
            if(ps.executeUpdate()>0){
                return true;
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(SolicitudEgresoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return false; //To change body of generated methods, choose Tools | Templates.
    }
    
    public boolean recibir(SolicitudEgresoDTO c) {
        PreparedStatement ps;
        try {
            ps=con.getCnn().prepareStatement(SQL_RECIBIR);
            ps.setInt(1, c.getEstado());
            ps.setLong(2, c.getId_solicitud_egreso());
            
            if(ps.executeUpdate()>0){
                return true;
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(SolicitudEgresoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return false; //To change body of generated methods, choose Tools | Templates.
    }
    public boolean entregar(SolicitudEgresoDTO c) {
        PreparedStatement ps;
        try {
            ps=con.getCnn().prepareStatement(SQL_ENTREGAR);
            ps.setInt(1, c.getEstado());
            ps.setString(2, c.getRetira());
            ps.setLong(3, c.getId_solicitud_egreso());
            
            if(ps.executeUpdate()>0){
                return true;
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(SolicitudEgresoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return false; //To change body of generated methods, choose Tools | Templates.
    }
}
