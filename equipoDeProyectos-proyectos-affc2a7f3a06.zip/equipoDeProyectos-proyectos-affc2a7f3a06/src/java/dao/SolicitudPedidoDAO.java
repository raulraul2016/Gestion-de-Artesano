/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import conexion.Conexion;
import dto.SolicitudPedidoDTO;
import interfaces.Interfaz;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import servlet.Login;
import static util.Util.dateToSqlDate;

/**
 *
 * @author Ariel
 */
public class SolicitudPedidoDAO implements Interfaz<SolicitudPedidoDTO>{

    private static final String  SQL_INSERT="INSERT INTO solicitudes_pedido (id_usuario, id_prioridad, estado, origen, proveedor,fecha_creacion) VALUES (?,?,?,?,?,now())";
    private static final String  SQL_DELETE="DELETE FROM solicitudes_pedido WHERE id_solicitud=?";
    private static final String  SQL_UPDATE="UPDATE solicitudes_pedido SET id_usuario=?, id_prioridad=?, estado=?, origen=?, proveedor=?, fecha_modificacion=now() WHERE id_solicitud=?";
    private static final String  SQL_ANULAR="UPDATE solicitudes_pedido SET id_usuario=?, id_prioridad=?, estado=?, origen=?, proveedor=?, fecha_anulacion=now() WHERE id_solicitud=?";
    private static final String  SQL_EXTRAER="SELECT * FROM solicitudes_pedido WHERE id_solicitud=?";
    private static final String  SQL_EXTRAERTODOS="SELECT id_solicitud FROM solicitudes_pedido  order by fecha_creacion desc";
    private static final String  SQL_EXTRAERTODOSF="SELECT id_solicitud FROM solicitudes_pedido, usuarios WHERE solicitudes_pedido.id_usuario=usuarios.idusuarios and usuarios.area=? order by fecha_creacion desc";
    private static final String  SQL_EXTRAERTODOSP="SELECT id_solicitud FROM solicitudes_pedido WHERE estado=1 order by fecha_creacion desc";
    private static final String  SQL_EXTRAERTODOSPID="SELECT id_solicitud FROM solicitudes_pedido WHERE estado=1 and id_solicitud like concat('%',?,'%') order by fecha_creacion desc";
    private static final String  SQL_EXTRAERTODOSESTADO="SELECT id_solicitud FROM solicitudes_pedido, usuarios WHERE solicitudes_pedido.id_usuario=usuarios.idusuarios and usuarios.area=? and estado=? order by fecha_creacion desc";
    private static final String  SQL_EXTRAERTODOSPRIORIDAD="SELECT id_solicitud FROM solicitudes_pedido, usuarios WHERE solicitudes_pedido.id_usuario=usuarios.idusuarios and usuarios.area=? and id_prioridad=? order by fecha_creacion desc";
    private static final String  SQL_EXTRAERTODOSPROVEEDOR="SELECT id_solicitud FROM solicitudes_pedido, usuarios WHERE solicitudes_pedido.id_usuario=usuarios.idusuarios and usuarios.area=? and proveedor=? order by fecha_creacion desc";
    private static final String  SQL_EXTRAERTODOSID="SELECT id_solicitud FROM solicitudes_pedido, usuarios WHERE solicitudes_pedido.id_usuario=usuarios.idusuarios and usuarios.area=? and id_solicitud like concat('%',?,'%') order by fecha_creacion desc";
    private static final String  SQL_EXTRAERTODOSI="SELECT id_solicitud FROM solicitudes_pedido WHERE id_solicitud like concat('%',?,'%') order by fecha_creacion desc";
    private static final String  SQL_EXTRAERTODOSPRO="SELECT id_solicitud FROM solicitudes_pedido WHERE proveedor=? and estado=3 order by fecha_creacion desc";
    private static final String  SQL_EXTRAERTODOSPROV="SELECT id_solicitud FROM solicitudes_pedido WHERE proveedor=? and estado=1 order by fecha_creacion desc";
    private static final String  SQL_EXTRAERTODOSAREA="SELECT id_solicitud FROM solicitudes_pedido WHERE origen=? and estado=1 order by fecha_creacion desc";
    private static final String  SQL_EXTRAERTODOSPRIO="SELECT id_solicitud FROM solicitudes_pedido WHERE id_prioridad=? and estado=1 order by fecha_creacion desc";
    private static final String  SQL_EXTRAERTODOSESTA="SELECT id_solicitud FROM solicitudes_pedido WHERE estado=? order by fecha_creacion desc";
    private static final String  SQL_IDPEDIDO="SELECT MAX(id_solicitud) FROM solicitudes_pedido WHERE id_usuario=?";
    private static final Conexion con = Conexion.saberEstado();
    
    @Override
    public boolean crear(SolicitudPedidoDTO c) {
        PreparedStatement ps;
            try {
            ps=con.getCnn().prepareStatement(SQL_INSERT);
            ps.setInt(1, c.getId_usuario());
            ps.setInt(2, c.getId_prioridad());
            ps.setInt(3, c.getEstado());
            ps.setInt(4, c.getOrigen());
            if(c.getProveedor()==0){
                ps.setNull(5, Types.INTEGER);
            }else{
            ps.setInt(5, c.getProveedor());}
            
            if(ps.executeUpdate()>0){
                return true;
            }

        } catch (SQLException ex) {
            Logger.getLogger(SolicitudPedidoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return false; //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean borrar(Object id) {
        PreparedStatement ps;
        try {ps=con.getCnn().prepareStatement(SQL_DELETE);
            ps.setInt(1, Integer.parseInt(id.toString()));
            
            if(ps.executeUpdate()>0){
                return true;
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(SolicitudPedidoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return false;  //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean actualizar(SolicitudPedidoDTO c) {
        PreparedStatement ps;
        try {
            ps=con.getCnn().prepareStatement(SQL_UPDATE);
            ps.setInt(1, c.getId_usuario());
            ps.setInt(2, c.getId_prioridad());
            ps.setInt(3, c.getEstado());
            ps.setInt(4, c.getOrigen());
            if(c.getProveedor()==0){
                ps.setNull(5, Types.INTEGER);
            }else{
            ps.setInt(5, c.getProveedor());}
            ps.setLong(6, c.getId_solicitud());
            
            if(ps.executeUpdate()>0){
                return true;
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(AreaDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return false; //To change body of generated methods, choose Tools | Templates.
    }
    
    public boolean anular(SolicitudPedidoDTO c) {
        PreparedStatement ps;
        try {
            ps=con.getCnn().prepareStatement(SQL_ANULAR);
            ps.setInt(1, c.getId_usuario());
            ps.setInt(2, c.getId_prioridad());
            ps.setInt(3, c.getEstado());
            ps.setInt(4, c.getOrigen());
            if(c.getProveedor()==0){
                ps.setNull(5, Types.INTEGER);
            }else{
            ps.setInt(5, c.getProveedor());}
            ps.setLong(6, c.getId_solicitud());
            
            if(ps.executeUpdate()>0){
                return true;
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(AreaDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return false; //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public SolicitudPedidoDTO extraer(Object id) {
        PreparedStatement ps;
            ResultSet rs;
            SolicitudPedidoDTO adto=null;
        try {    
            ps = con.getCnn().prepareStatement(SQL_EXTRAER);
            ps.setLong(1, Long.parseLong(id.toString()));
            
            rs=ps.executeQuery();
            
            while(rs.next()){
                adto= new SolicitudPedidoDTO(rs.getLong(1), rs.getInt(2), rs.getInt(3), rs.getInt(4), rs.getInt(5), rs.getInt(6), dateToSqlDate(rs.getDate(7)), dateToSqlDate(rs.getDate(8)), dateToSqlDate(rs.getDate(9)));
            }
        } catch (SQLException ex) {
            Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return adto; //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<SolicitudPedidoDTO> extraerTodos() {
        PreparedStatement ps;
        ResultSet rs;
        SolicitudPedidoDTO adto=null;
        ArrayList<SolicitudPedidoDTO> list=new ArrayList<SolicitudPedidoDTO>();
        try {    
            ps = con.getCnn().prepareStatement(SQL_EXTRAERTODOS);
            rs=ps.executeQuery();
            
            while(rs.next()){
                adto= extraer(rs.getLong(1));
                list.add(adto);
            }
        } catch (SQLException ex) {
            Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return list; //To change body of generated methods, choose Tools | Templates.
    }
    
    public List<SolicitudPedidoDTO> extraerTodos(Long id_solicitud) {
        PreparedStatement ps;
        ResultSet rs;
        SolicitudPedidoDTO adto=null;
        ArrayList<SolicitudPedidoDTO> list=new ArrayList<SolicitudPedidoDTO>();
        try {    
            ps = con.getCnn().prepareStatement(SQL_EXTRAERTODOSI);
            ps.setLong(1, id_solicitud);
            rs=ps.executeQuery();
            
            while(rs.next()){
                adto= extraer(rs.getLong(1));
                list.add(adto);
            }
        } catch (SQLException ex) {
            Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return list; //To change body of generated methods, choose Tools | Templates.
    }
    
    public List<SolicitudPedidoDTO> extraerTodos(int proveedor) {
        PreparedStatement ps;
        ResultSet rs;
        SolicitudPedidoDTO adto=null;
        ArrayList<SolicitudPedidoDTO> list=new ArrayList<SolicitudPedidoDTO>();
        try {    
            ps = con.getCnn().prepareStatement(SQL_EXTRAERTODOSPROV);
            ps.setLong(1, proveedor);
            rs=ps.executeQuery();
            
            while(rs.next()){
                adto= extraer(rs.getLong(1));
                list.add(adto);
            }
        } catch (SQLException ex) {
            Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return list; //To change body of generated methods, choose Tools | Templates.
    }
   
    public List<SolicitudPedidoDTO> extraerTodosEstado(int estado) {
        PreparedStatement ps;
        ResultSet rs;
        SolicitudPedidoDTO adto=null;
        ArrayList<SolicitudPedidoDTO> list=new ArrayList<SolicitudPedidoDTO>();
        try {    
            ps = con.getCnn().prepareStatement(SQL_EXTRAERTODOSESTA);
            ps.setLong(1, estado);
            rs=ps.executeQuery();
            
            while(rs.next()){
                adto= extraer(rs.getLong(1));
                list.add(adto);
            }
        } catch (SQLException ex) {
            Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return list; //To change body of generated methods, choose Tools | Templates.
    }
    
    public List<SolicitudPedidoDTO> extraerTodosP() {
        PreparedStatement ps;
        ResultSet rs;
        SolicitudPedidoDTO adto=null;
        ArrayList<SolicitudPedidoDTO> list=new ArrayList<SolicitudPedidoDTO>();
        try {    
            ps = con.getCnn().prepareStatement(SQL_EXTRAERTODOSP);
            rs=ps.executeQuery();
            
            while(rs.next()){
                adto= extraer(rs.getLong(1));
                list.add(adto);
            }
        } catch (SQLException ex) {
            Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return list; //To change body of generated methods, choose Tools | Templates.
    }
    
    public List<SolicitudPedidoDTO> extraerTodosArea(int id) {
        PreparedStatement ps;
        ResultSet rs;
        SolicitudPedidoDTO adto=null;
        ArrayList<SolicitudPedidoDTO> list=new ArrayList<SolicitudPedidoDTO>();
        try {    
            ps = con.getCnn().prepareStatement(SQL_EXTRAERTODOSAREA);
            ps.setInt(1, id);
            rs=ps.executeQuery();
            
            while(rs.next()){
                adto= extraer(rs.getLong(1));
                list.add(adto);
            }
        } catch (SQLException ex) {
            Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return list; //To change body of generated methods, choose Tools | Templates.
    }
    
    public List<SolicitudPedidoDTO> extraerTodosPid(Long id) {
        PreparedStatement ps;
        ResultSet rs;
        SolicitudPedidoDTO adto=null;
        ArrayList<SolicitudPedidoDTO> list=new ArrayList<SolicitudPedidoDTO>();
        try {    
            ps = con.getCnn().prepareStatement(SQL_EXTRAERTODOSPID);
            ps.setLong(1, id);
            rs=ps.executeQuery();
            
            while(rs.next()){
                adto= extraer(rs.getLong(1));
                list.add(adto);
            }
        } catch (SQLException ex) {
            Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return list; //To change body of generated methods, choose Tools | Templates.
    }
    
    public List<SolicitudPedidoDTO> extraerTodosF(int area) {
        PreparedStatement ps;
        ResultSet rs;
        SolicitudPedidoDTO adto=null;
        ArrayList<SolicitudPedidoDTO> list=new ArrayList<SolicitudPedidoDTO>();
        try {    
            ps = con.getCnn().prepareStatement(SQL_EXTRAERTODOSF);
            ps.setInt(1, area);
            rs=ps.executeQuery();
            
            while(rs.next()){
                adto= extraer(rs.getLong(1));
                list.add(adto);
            }
        } catch (SQLException ex) {
            Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return list; //To change body of generated methods, choose Tools | Templates.
    }
    
    public List<SolicitudPedidoDTO> extraerTodosID(int area, Long id) {
        PreparedStatement ps;
        ResultSet rs;
        SolicitudPedidoDTO adto=null;
        ArrayList<SolicitudPedidoDTO> list=new ArrayList<SolicitudPedidoDTO>();
        try {    
            ps = con.getCnn().prepareStatement(SQL_EXTRAERTODOSID);
            ps.setInt(1, area);
            ps.setLong(2, id);
            rs=ps.executeQuery();
            
            while(rs.next()){
                adto= extraer(rs.getLong(1));
                list.add(adto);
            }
        } catch (SQLException ex) {
            Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return list; //To change body of generated methods, choose Tools | Templates.
    }
    
    public List<SolicitudPedidoDTO> extraerTodosESTADO(int area, int estado) {
        PreparedStatement ps;
        ResultSet rs;
        SolicitudPedidoDTO adto=null;
        ArrayList<SolicitudPedidoDTO> list=new ArrayList<SolicitudPedidoDTO>();
        try {    
            ps = con.getCnn().prepareStatement(SQL_EXTRAERTODOSESTADO);
            ps.setInt(1, area);
            ps.setInt(2, estado);
            rs=ps.executeQuery();
            
            while(rs.next()){
                adto= extraer(rs.getLong(1));
                list.add(adto);
            }
        } catch (SQLException ex) {
            Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return list; //To change body of generated methods, choose Tools | Templates.
    }
    
    public List<SolicitudPedidoDTO> extraerTodosPRIORIDAD(int area, int prioridad) {
        PreparedStatement ps;
        ResultSet rs;
        SolicitudPedidoDTO adto=null;
        ArrayList<SolicitudPedidoDTO> list=new ArrayList<SolicitudPedidoDTO>();
        try {    
            ps = con.getCnn().prepareStatement(SQL_EXTRAERTODOSPRIORIDAD);
            ps.setInt(1, area);
            ps.setInt(2, prioridad);
            rs=ps.executeQuery();
            
            while(rs.next()){
                adto= extraer(rs.getLong(1));
                list.add(adto);
            }
        } catch (SQLException ex) {
            Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return list; //To change body of generated methods, choose Tools | Templates.
    }
    
    public List<SolicitudPedidoDTO> extraerTodosPROVEEDOR(int area, int proveedor) {
        PreparedStatement ps;
        ResultSet rs;
        SolicitudPedidoDTO adto=null;
        ArrayList<SolicitudPedidoDTO> list=new ArrayList<SolicitudPedidoDTO>();
        try {    
            ps = con.getCnn().prepareStatement(SQL_EXTRAERTODOSPROVEEDOR);
            ps.setInt(1, area);
            ps.setInt(2, proveedor);
            rs=ps.executeQuery();
            
            while(rs.next()){
                adto= extraer(rs.getLong(1));
                list.add(adto);
            }
        } catch (SQLException ex) {
            Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return list; //To change body of generated methods, choose Tools | Templates.
    }
    
    public List<SolicitudPedidoDTO> extraerTodosPROV(int id_proveedor) {
        PreparedStatement ps;
        ResultSet rs;
        SolicitudPedidoDTO adto=null;
        ArrayList<SolicitudPedidoDTO> list=new ArrayList<SolicitudPedidoDTO>();
        try {    
            ps = con.getCnn().prepareStatement(SQL_EXTRAERTODOSPROV);
            ps.setInt(1, id_proveedor);
            rs=ps.executeQuery();
            
            while(rs.next()){
                adto= extraer(rs.getLong(1));
                list.add(adto);
            }
        } catch (SQLException ex) {
            Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return list; //To change body of generated methods, choose Tools | Templates.
    }
    
    public List<SolicitudPedidoDTO> extraerTodosPRIO(int id_proveedor) {
        PreparedStatement ps;
        ResultSet rs;
        SolicitudPedidoDTO adto=null;
        ArrayList<SolicitudPedidoDTO> list=new ArrayList<SolicitudPedidoDTO>();
        try {    
            ps = con.getCnn().prepareStatement(SQL_EXTRAERTODOSPRIO);
            ps.setInt(1, id_proveedor);
            rs=ps.executeQuery();
            
            while(rs.next()){
                adto= extraer(rs.getLong(1));
                list.add(adto);
            }
        } catch (SQLException ex) {
            Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return list; //To change body of generated methods, choose Tools | Templates.
    }
    
    public List<SolicitudPedidoDTO> extraerTodosPRO(int id_proveedor) {
        PreparedStatement ps;
        ResultSet rs;
        SolicitudPedidoDTO adto=null;
        ArrayList<SolicitudPedidoDTO> list=new ArrayList<SolicitudPedidoDTO>();
        try {    
            ps = con.getCnn().prepareStatement(SQL_EXTRAERTODOSPRO);
            ps.setInt(1, id_proveedor);
            rs=ps.executeQuery();
            
            while(rs.next()){
                adto= extraer(rs.getLong(1));
                list.add(adto);
            }
        } catch (SQLException ex) {
            Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return list; //To change body of generated methods, choose Tools | Templates.
    }
    
    public Long lastIdPedido(int id_usuario){
        PreparedStatement ps;
            ResultSet rs;
            Long lastIdPedido=null;
        try {    
            ps = con.getCnn().prepareStatement(SQL_IDPEDIDO);
            ps.setInt(1, id_usuario);
            
            rs=ps.executeQuery();
            
            while(rs.next()){
                lastIdPedido=  rs.getLong(1);
            }
        } catch (SQLException ex) {
            Logger.getLogger(SolicitudPedidoDetalleDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return lastIdPedido;
    
    }
}
