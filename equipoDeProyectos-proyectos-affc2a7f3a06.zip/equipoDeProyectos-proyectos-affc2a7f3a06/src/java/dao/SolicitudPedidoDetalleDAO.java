/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import conexion.Conexion;
import dto.SolicitudPedidoDetalleDTO;
import interfaces.Interfaz;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import servlet.Login;

/**
 *
 * @author Ariel
 */
public class SolicitudPedidoDetalleDAO implements Interfaz<SolicitudPedidoDetalleDTO>{

    
    private static final String  SQL_INSERT="INSERT INTO detalles_solicitud (id_solicitud, id_articulo, cantidad_pedida) VALUES (?,?,?)";
    private static final String  SQL_DELETE="DELETE FROM detalles_solicitud WHERE iddetalle_solicitud=?";
    private static final String  SQL_UPDATE="UPDATE detalles_solicitud SET id_solicitud=?, id_articulo=?, cantidad_pedida=?, cantidad_aprobada=? WHERE iddetalle_solicitud=?";
    private static final String  SQL_EXTRAER="SELECT * FROM detalles_solicitud WHERE iddetalle_solicitud=?";
    private static final String  SQL_EXTRAERTODOS="SELECT iddetalle_solicitud FROM detalles_solicitud";
    private static final String  SQL_EXTRAERTODOSF="SELECT iddetalle_solicitud FROM detalles_solicitud WHERE id_solicitud=?";
    
    private static final Conexion con = Conexion.saberEstado();
    
    @Override
    public boolean crear(SolicitudPedidoDetalleDTO c) {
        PreparedStatement ps;
            try {
            ps=con.getCnn().prepareStatement(SQL_INSERT);
            ps.setLong(1, c.getId_solicitud());
            ps.setLong(2, c.getId_articulo());
            ps.setInt(3, c.getCantidad_pedida());
            
            if(ps.executeUpdate()>0){
                return true;
            }

        } catch (SQLException ex) {
            Logger.getLogger(SolicitudPedidoDetalleDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return false; //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean borrar(Object id) {
        PreparedStatement ps;
        try {ps=con.getCnn().prepareStatement(SQL_DELETE);
            ps.setLong(1, Long.parseLong(id.toString()));
            
            if(ps.executeUpdate()>0){
                return true;
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(SolicitudPedidoDetalleDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return false; //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean actualizar(SolicitudPedidoDetalleDTO c) {
        PreparedStatement ps;
        try {
            ps=con.getCnn().prepareStatement(SQL_UPDATE);
            ps.setLong(1, c.getId_solicitud());
            ps.setLong(2, c.getId_articulo());
            ps.setInt(3, c.getCantidad_pedida());
            ps.setInt(4, c.getCantidad_aprobada());
            ps.setLong(5, c.getId_detalle_solicitud());
            
            if(ps.executeUpdate()>0){
                return true;
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(SolicitudPedidoDetalleDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return false; //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public SolicitudPedidoDetalleDTO extraer(Object id) {
            PreparedStatement ps;
            ResultSet rs;
            SolicitudPedidoDetalleDTO adto=null;
        try {    
            ps = con.getCnn().prepareStatement(SQL_EXTRAER);
            ps.setLong(1, Long.parseLong(id.toString()));
            
            rs=ps.executeQuery();
            
            while(rs.next()){
                adto= new SolicitudPedidoDetalleDTO(rs.getLong(1), rs.getLong(2), rs.getLong(3), rs.getInt(4), rs.getInt(5));
            }
        } catch (SQLException ex) {
            Logger.getLogger(SolicitudPedidoDetalleDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return adto; //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<SolicitudPedidoDetalleDTO> extraerTodos() {
        PreparedStatement ps;
        ResultSet rs;
        SolicitudPedidoDetalleDTO adto=null;
        ArrayList<SolicitudPedidoDetalleDTO> list=new ArrayList<SolicitudPedidoDetalleDTO>();
        try {    
            ps = con.getCnn().prepareStatement(SQL_EXTRAERTODOS);
            rs=ps.executeQuery();
            
            while(rs.next()){
                adto= extraer(rs.getLong(1));
                list.add(adto);
            }
        } catch (SQLException ex) {
            Logger.getLogger(SolicitudPedidoDetalleDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return list;//To change body of generated methods, choose Tools | Templates.
    }
    
    public List<SolicitudPedidoDetalleDTO> extraerTodosF(Long id_solicitud) {
        PreparedStatement ps;
        ResultSet rs;
        SolicitudPedidoDetalleDTO adto=null;
        ArrayList<SolicitudPedidoDetalleDTO> list=new ArrayList<SolicitudPedidoDetalleDTO>();
        try {    
            ps = con.getCnn().prepareStatement(SQL_EXTRAERTODOSF);
            ps.setLong(1, id_solicitud);
            rs=ps.executeQuery();
            
            while(rs.next()){
                adto= extraer(rs.getLong(1));
                list.add(adto);
            }
        } catch (SQLException ex) {
            Logger.getLogger(SolicitudPedidoDetalleDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return list;//To change body of generated methods, choose Tools | Templates.
    }
     public boolean actualizarDetalles(List<SolicitudPedidoDetalleDTO> detalles){
       try {
         //se deshabilita el modo de confirmación automática
             con.getCnn().setAutoCommit(false);            
             for(int i=0;i<detalles.size();i++){
                 if(!actualizar(detalles.get(i))){
                   return false;  
                 }
             }
            //se indica que se deben aplicar los cambios en la base de datos
            con.getCnn().commit();
            
        } catch (SQLException ex) {
                 System.out.println("no se pudo");
           try {
               con.getCnn().rollback();
           } catch (SQLException ex1) {
               Logger.getLogger(SolicitudPedidoDetalleDAO.class.getName()).log(Level.SEVERE, null, ex1);
           }
            }finally{
             con.cerrarConexion();
             }
    return true;
    }
}
