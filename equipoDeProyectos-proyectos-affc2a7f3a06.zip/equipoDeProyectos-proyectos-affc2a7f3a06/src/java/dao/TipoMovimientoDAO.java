/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import conexion.Conexion;
import dto.TipoMovimientoDTO;
import interfaces.Interfaz;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Ariel
 */
public class TipoMovimientoDAO implements Interfaz<TipoMovimientoDTO>{
    
    private static final String  SQL_EXTRAER="SELECT * FROM tipos_movimiento WHERE idtipos_movimiento=?";
    private static final String  SQL_EXTRAERTODOS="SELECT idtipos_movimiento FROM tipos_movimiento ";
    
    private static final Conexion con = Conexion.saberEstado();

    @Override
    public boolean crear(TipoMovimientoDTO c) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean borrar(Object id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean actualizar(TipoMovimientoDTO c) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public TipoMovimientoDTO extraer(Object id) {
            PreparedStatement ps;
            ResultSet rs;
            TipoMovimientoDTO rto=null;
        try {    
            ps = con.getCnn().prepareStatement(SQL_EXTRAER);
            ps.setLong(1, Long.parseLong(id.toString()));
            
            rs=ps.executeQuery();
            
            while(rs.next()){
                rto= new TipoMovimientoDTO(rs.getInt(1), rs.getString(2));
            }
        } catch (SQLException ex) {
            Logger.getLogger(EstadoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return rto; //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<TipoMovimientoDTO> extraerTodos() {
        PreparedStatement ps;
        ResultSet rs;
        TipoMovimientoDTO rto=null;
        ArrayList<TipoMovimientoDTO> list=new ArrayList<TipoMovimientoDTO>();
        try {    
            ps = con.getCnn().prepareStatement(SQL_EXTRAERTODOS);
            rs=ps.executeQuery();
            
            while(rs.next()){
                rto= extraer(rs.getString(1));
                list.add(rto);
            }
        } catch (SQLException ex) {
            Logger.getLogger(EstadoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return list; //To change body of generated methods, choose Tools | Templates.
    }
    
}
