/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import conexion.Conexion;
import dto.UsuarioDTO;
import interfaces.Interfaz;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Ariel
 */
public class UsuarioDAO implements Interfaz<UsuarioDTO>{
    
    private static final String  SQL_INSERT="INSERT INTO usuarios (usuario,contrase�a,rol,apellido,nombre,dni,telefono,area,cargo,activo) VALUES (?,?,?,?,?,?,?,?,?,?)";
    private static final String  SQL_DELETE="DELETE FROM usuarios WHERE idusuarios=?";
    private static final String  SQL_UPDATE="UPDATE usuarios SET apellido=?,nombre=?,dni=?,telefono=?,area=?,cargo=? WHERE idusuarios=?";
    private static final String  SQL_UPDATEADMIN="UPDATE usuarios SET usuario=?, contrase�a=?, rol=?, apellido=?, nombre=?, dni=?, telefono=?, area=?, cargo=?, activo=? WHERE idusuarios=?";
    private static final String  SQL_UPDATECONTRASE�A="UPDATE usuarios SET contrase�a=? WHERE idusuarios=?";
    private static final String  SQL_EXTRAER="SELECT * FROM usuarios WHERE idusuarios=?";
    private static final String  SQL_EXTRAERTODOS="SELECT idusuarios FROM usuarios  ";
    private static final String  SQL_VALIDAR="SELECT * FROM usuarios WHERE usuario=? and contrase�a=? and activo=true";
    private static final String  SQL_BUSCAR="Select * FROM usuarios  WHERE nombre ilike '?%'";
    
    private static final Conexion con = Conexion.saberEstado();

    @Override
    public boolean crear(UsuarioDTO c) {
        
            PreparedStatement ps;
            try {
            ps=con.getCnn().prepareStatement(SQL_INSERT);
            ps.setString(1, c.getUsuario());
            ps.setString(2, c.getContrase�a());
            ps.setInt(3, c.getRol());
            ps.setString(4, c.getApellido());
            ps.setString(5, c.getNombre());
            ps.setLong(6, c.getDni());
            ps.setString(7, c.getTelefono());
            ps.setInt(8, c.getArea());
            ps.setString(9, c.getCargo());
            ps.setBoolean(10, c.isActivo());
            
            if(ps.executeUpdate()>0){
                return true;
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return false;
    }

    @Override
    public boolean borrar(Object id) {
       try {
            PreparedStatement ps;
            ps=con.getCnn().prepareStatement(SQL_DELETE);
            ps.setInt(1, Integer.parseInt(id.toString()));
            
            if(ps.executeUpdate()>0){
                return true;
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return false; 
    }

    @Override
    public boolean actualizar(UsuarioDTO c) {
        try {
            PreparedStatement ps;
            ps=con.getCnn().prepareStatement(SQL_UPDATE);
            ps.setString(1, c.getApellido());
            ps.setString(2, c.getNombre());
            ps.setLong(3, c.getDni());
            ps.setString(4, c.getTelefono());
            ps.setInt(5, c.getArea());
            ps.setString(6, c.getCargo());
            ps.setInt(7, c.getIdusuarios());
            
            if(ps.executeUpdate()>0){
                return true;
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return false;
    }
    
    public boolean actualizarusuario(UsuarioDTO c) {
        try {
            PreparedStatement ps;
            ps=con.getCnn().prepareStatement(SQL_UPDATEADMIN);
            ps.setString(1, c.getUsuario());
            ps.setString(2, c.getContrase�a());
            ps.setInt(3, c.getRol());
            ps.setString(4, c.getApellido());
            ps.setString(5, c.getNombre());
            ps.setLong(6, c.getDni());
            ps.setString(7, c.getTelefono());
            ps.setInt(8, c.getArea());
            ps.setString(9, c.getCargo());
            ps.setBoolean(10, c.isActivo());
            ps.setInt(11, c.getIdusuarios());
            if(ps.executeUpdate()>0){
                return true;
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return false;
    }
    
    public boolean cambiarContrase�a(int idusuario, String contrase�anueva) {
            PreparedStatement ps;
            
        try {
            
            ps=con.getCnn().prepareStatement(SQL_UPDATECONTRASE�A);
            ps.setString(1, contrase�anueva);
            ps.setInt(2, idusuario);
            
            if(ps.executeUpdate()>0){
                return true;
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
            
        return false;
    }

    @Override
    public UsuarioDTO extraer(Object id) {
        
            PreparedStatement ps;
            ResultSet rs;
            UsuarioDTO udto=null;
        try {    
            ps = con.getCnn().prepareStatement(SQL_EXTRAER);
            ps.setInt(1, Integer.valueOf(id.toString()));
            
            rs=ps.executeQuery();
            
            while(rs.next()){
                udto= new UsuarioDTO(rs.getInt(1), rs.getString(2), rs.getString(3),rs.getInt(4),rs.getString(5),rs.getString(6),rs.getLong(7),rs.getString(8),rs.getInt(9),rs.getString(10),rs.getBoolean(11));
            }
        } catch (SQLException ex) {
            Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return udto;
    }

    @Override
    public List<UsuarioDTO> extraerTodos() {
        PreparedStatement ps;
        ResultSet rs;
        UsuarioDTO udto=null;
        ArrayList<UsuarioDTO> list=new ArrayList<UsuarioDTO>();
        try {    
            ps = con.getCnn().prepareStatement(SQL_EXTRAERTODOS);
            rs=ps.executeQuery();
            
            while(rs.next()){
                udto= extraer(rs.getInt(1));
                list.add(udto);
            }
        } catch (SQLException ex) {
            Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
        return list;
    }
    
    public UsuarioDTO validar (String usuario, String contrase�a){
            UsuarioDTO dTO=null;
            PreparedStatement ps;
            ResultSet rs;
            try {
            ps=con.getCnn().prepareStatement(SQL_VALIDAR);
            ps.setString(1, usuario);
            ps.setString(2, contrase�a);
            rs=ps.executeQuery();
            if(rs.next()){
                dTO= new UsuarioDTO(rs.getInt(1), rs.getString(2), rs.getString(3),rs.getInt(4),rs.getString(5),rs.getString(6),rs.getLong(7),rs.getString(8),rs.getInt(9),rs.getString(10),rs.getBoolean(11));
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            con.cerrarConexion();
        }
    return dTO;
    }

}
