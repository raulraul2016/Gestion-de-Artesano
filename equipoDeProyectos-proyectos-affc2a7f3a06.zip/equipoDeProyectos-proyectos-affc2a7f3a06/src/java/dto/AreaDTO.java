/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dto;

/**
 *
 * @author yesi
 */
public class AreaDTO {
    private int id;
    private String nombre_area;
    private int id_area_superior;
    private String descripcion;

    public AreaDTO() {
    }

    public AreaDTO(int id, String nombre_area, int id_area_superior, String descripcion) {
        this.id = id;
        this.nombre_area = nombre_area;
        this.id_area_superior = id_area_superior;
        this.descripcion = descripcion;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre_area() {
        return nombre_area;
    }

    public void setNombre_area(String nombre_area) {
        this.nombre_area = nombre_area;
    }

    public int getId_area_superior() {
        return id_area_superior;
    }

    public void setId_area_superior(int id_area_superior) {
        this.id_area_superior = id_area_superior;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
    
}
