/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dto;

import java.math.BigDecimal;

/**
 *
 * @author yesi
 */
public class ArticuloDTO {
    private Long id_articulo;
    private String nombre;
    private int rubro;
    private int unidad_medida;
    private int stock_min;
    private int stock_max;
    private int stock_actual;
    private Double precio;
    private boolean activo;

    public ArticuloDTO() {
    }

    public ArticuloDTO(Long id_articulo, String nombre, int rubro, int unidad_medida, int stock_mein, int stock_max, int stock_actual, Double precio, boolean activo) {
        this.id_articulo = id_articulo;
        this.nombre = nombre;
        this.rubro = rubro;
        this.unidad_medida = unidad_medida;
        this.stock_min = stock_mein;
        this.stock_max = stock_max;
        this.stock_actual = stock_actual;
        this.precio = precio;
        this.activo = activo;
    }

    public ArticuloDTO(String nombre, int rubro, int unidad_medida, int stock_mein, int stock_max, int stock_actual, Double precio, boolean activo) {
        this.nombre = nombre;
        this.rubro = rubro;
        this.unidad_medida = unidad_medida;
        this.stock_min = stock_mein;
        this.stock_max = stock_max;
        this.stock_actual = stock_actual;
        this.precio = precio;
        this.activo = activo;
    }

    public Long getId_articulo() {
        return id_articulo;
    }

    public void setId_articulo(Long id_articulo) {
        this.id_articulo = id_articulo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getRubro() {
        return rubro;
    }

    public void setRubro(int rubro) {
        this.rubro = rubro;
    }

    public int getUnidad_medida() {
        return unidad_medida;
    }

    public void setUnidad_medida(int unidad_medida) {
        this.unidad_medida = unidad_medida;
    }

    public int getStock_min() {
        return stock_min;
    }

    public void setStock_min(int stock_min) {
        this.stock_min = stock_min;
    }

    public int getStock_max() {
        return stock_max;
    }

    public void setStock_max(int stock_max) {
        this.stock_max = stock_max;
    }

    public int getStock_actual() {
        return stock_actual;
    }

    public void setStock_actual(int stock_actual) {
        this.stock_actual = stock_actual;
    }

    public Double getPrecio() {
        return precio;
    }

    public void setPrecio(Double precio) {
        this.precio = precio;
    }

    public boolean isActivo() {
        return activo;
    }

    public void setActivo(boolean activo) {
        this.activo = activo;
    }

    
}
