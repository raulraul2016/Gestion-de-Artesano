/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dto;

/**
 *
 * @author Ariel
 */
public class CentroCostoDTO {
    
    private Long id_centros_costo;
    private int id_area;
    private int id_sub_area;
    private int id_localidad;
    private String nombre;
    private String codigo;

    public CentroCostoDTO() {
    }

    public CentroCostoDTO(int id_area, int id_sub_area, int id_localidad, String nombre, String codigo) {
        this.id_area = id_area;
        this.id_sub_area = id_sub_area;
        this.id_localidad = id_localidad;
        this.nombre = nombre;
        this.codigo = codigo;
    }

    public CentroCostoDTO(Long id_centros_costo, int id_area, int id_sub_area, int id_localidad, String nombre, String codigo) {
        this.id_centros_costo = id_centros_costo;
        this.id_area = id_area;
        this.id_sub_area = id_sub_area;
        this.id_localidad = id_localidad;
        this.nombre = nombre;
        this.codigo = codigo;
    }

    public Long getId_centros_costo() {
        return id_centros_costo;
    }

    public void setId_centros_costo(Long id_centros_costo) {
        this.id_centros_costo = id_centros_costo;
    }

    public int getId_area() {
        return id_area;
    }

    public void setId_area(int id_area) {
        this.id_area = id_area;
    }

    public int getId_sub_area() {
        return id_sub_area;
    }

    public void setId_sub_area(int id_sub_area) {
        this.id_sub_area = id_sub_area;
    }

    public int getId_localidad() {
        return id_localidad;
    }

    public void setId_localidad(int id_localidad) {
        this.id_localidad = id_localidad;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }
       
    
    
}
