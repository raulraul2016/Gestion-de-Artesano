/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dto;

/**
 *
 * @author Ariel
 */
public class CentroCostoItemDTO {
    private Long iditem_centro_costo;
    private Long id_centro_costo;
    private String nombre;
    private String cod_centro_costo_item;

    public CentroCostoItemDTO() {
    }

    public CentroCostoItemDTO(Long iditem_centro_costo, Long id_centro_costo, String nombre, String cod_centro_costo_item) {
        this.iditem_centro_costo = iditem_centro_costo;
        this.id_centro_costo = id_centro_costo;
        this.nombre = nombre;
        this.cod_centro_costo_item = cod_centro_costo_item;
    }

    public CentroCostoItemDTO(Long id_centro_costo, String nombre, String cod_centro_costo_item) {
        this.id_centro_costo = id_centro_costo;
        this.nombre = nombre;
        this.cod_centro_costo_item = cod_centro_costo_item;
    }

    public Long getIditem_centro_costo() {
        return iditem_centro_costo;
    }

    public void setIditem_centro_costo(Long iditem_centro_costo) {
        this.iditem_centro_costo = iditem_centro_costo;
    }

    public Long getId_centro_costo() {
        return id_centro_costo;
    }

    public void setId_centro_costo(Long id_centro_costo) {
        this.id_centro_costo = id_centro_costo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCod_centro_costo_item() {
        return cod_centro_costo_item;
    }

    public void setCod_centro_costo_item(String cod_centro_costo_item) {
        this.cod_centro_costo_item = cod_centro_costo_item;
    }
    
    
}
