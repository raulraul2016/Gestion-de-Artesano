/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dto;

/**
 *
 * @author Ariel
 */
public class CombustibleDTO {
    private int idcombustible;
    private String nombre;

    public CombustibleDTO() {
    }

    public CombustibleDTO(int idcombustible, String nombre) {
        this.idcombustible = idcombustible;
        this.nombre = nombre;
    }

    public CombustibleDTO(String nombre) {
        this.nombre = nombre;
    }

    public int getIdcombustible() {
        return idcombustible;
    }

    public void setIdcombustible(int idcombustible) {
        this.idcombustible = idcombustible;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    
    
}
