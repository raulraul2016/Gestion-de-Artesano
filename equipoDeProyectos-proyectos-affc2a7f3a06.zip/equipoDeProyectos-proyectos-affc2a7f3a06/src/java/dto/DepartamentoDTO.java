/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dto;

/**
 *
 * @author Ariel
 */
public class DepartamentoDTO {
    private int id_departamentos;
    private int id_region;
    private String nombre;

    public DepartamentoDTO() {
    }

    public DepartamentoDTO(int id_departamentos, int id_region, String nombre) {
        this.id_departamentos = id_departamentos;
        this.id_region = id_region;
        this.nombre = nombre;
    }

    public DepartamentoDTO(int id_region, String nombre) {
        this.id_region = id_region;
        this.nombre = nombre;
    }

    public int getId_departamentos() {
        return id_departamentos;
    }

    public void setId_departamentos(int id_departamentos) {
        this.id_departamentos = id_departamentos;
    }

    public int getId_region() {
        return id_region;
    }

    public void setId_region(int id_region) {
        this.id_region = id_region;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    
}
