/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dto;

/**
 *
 * @author Ariel
 */
public class EstadoDTO {
    private int idestados;
    private String nombre;

    public EstadoDTO() {
    }

    public EstadoDTO(int idestados, String nombre) {
        this.idestados = idestados;
        this.nombre = nombre;
    }

    public int getIdestados() {
        return idestados;
    }

    public void setIdestados(int idestados) {
        this.idestados = idestados;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    
}
