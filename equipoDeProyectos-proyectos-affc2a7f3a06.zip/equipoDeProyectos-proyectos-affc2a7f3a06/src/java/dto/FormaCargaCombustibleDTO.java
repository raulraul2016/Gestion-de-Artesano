/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dto;

/**
 *
 * @author Ariel
 */
public class FormaCargaCombustibleDTO {
    private Long idFormaCargaCombustible;
    private Long idSolicitudEgresoCombustible;
    private int idTipoCarga;

    public FormaCargaCombustibleDTO() {
    }

    public FormaCargaCombustibleDTO(Long idFormaCargaCombustible, Long idSolicitudEgresoCombustible, int idTipoCarga) {
        this.idFormaCargaCombustible = idFormaCargaCombustible;
        this.idSolicitudEgresoCombustible = idSolicitudEgresoCombustible;
        this.idTipoCarga = idTipoCarga;
    }

    public Long getIdFormaCargaCombustible() {
        return idFormaCargaCombustible;
    }

    public void setIdFormaCargaCombustible(Long idFormaCargaCombustible) {
        this.idFormaCargaCombustible = idFormaCargaCombustible;
    }

    public Long getIdSolicitudEgresoCombustible() {
        return idSolicitudEgresoCombustible;
    }

    public void setIdSolicitudEgresoCombustible(Long idSolicitudEgresoCombustible) {
        this.idSolicitudEgresoCombustible = idSolicitudEgresoCombustible;
    }

    public int getIdTipoCarga() {
        return idTipoCarga;
    }

    public void setIdTipoCarga(int idTipoCarga) {
        this.idTipoCarga = idTipoCarga;
    }
    
    
}
