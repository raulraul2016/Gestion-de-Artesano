/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dto;

/**
 *
 * @author Ariel
 */
public class LocalidadDTO {
    private int id_localidades;
    private int id_departamento;
    private String nombre;

    public LocalidadDTO() {
    }

    public LocalidadDTO(int id_localidades, int id_departamento, String nombre) {
        this.id_localidades = id_localidades;
        this.id_departamento = id_departamento;
        this.nombre = nombre;
    }

    public LocalidadDTO(int id_departamento, String nombre) {
        this.id_departamento = id_departamento;
        this.nombre = nombre;
    }

    public int getId_localidades() {
        return id_localidades;
    }

    public void setId_localidades(int id_localidades) {
        this.id_localidades = id_localidades;
    }

    public int getId_departamento() {
        return id_departamento;
    }

    public void setId_departamento(int id_departamento) {
        this.id_departamento = id_departamento;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    
}
