/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dto;

/**
 *
 * @author yesi
 */
public class MedidaDTO {
    private int id_medida;
    private String nombre;
    private String abreviatura;

    public MedidaDTO() {
    }

    public MedidaDTO(String nombre, String abreviatura) {
        this.nombre = nombre;
        this.abreviatura = abreviatura;
    }

    public MedidaDTO(int id_medida, String nombre, String abreviatura) {
        this.id_medida = id_medida;
        this.nombre = nombre;
        this.abreviatura = abreviatura;
    }

    public int getId_medida() {
        return id_medida;
    }

    public void setId_medida(int id_medida) {
        this.id_medida = id_medida;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getAbreviatura() {
        return abreviatura;
    }

    public void setAbreviatura(String abreviatura) {
        this.abreviatura = abreviatura;
    }
    
    
}
