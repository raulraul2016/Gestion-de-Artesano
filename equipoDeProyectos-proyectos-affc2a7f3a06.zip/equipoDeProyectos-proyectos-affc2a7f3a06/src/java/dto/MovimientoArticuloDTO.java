/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dto;

import java.util.Date;

/**
 *
 * @author Ariel
 */
public class MovimientoArticuloDTO {
    private Long idmovimientos_articulos;
    private Date fecha;
    private int tipo_movimiento;
    private String nro_documento;
    private int id_usuario;

    public MovimientoArticuloDTO() {
    }

    public MovimientoArticuloDTO(Long idmovimientos_articulos, Date fecha, int tipo_movimiento, String nro_documento, int id_usuario) {
        this.idmovimientos_articulos = idmovimientos_articulos;
        this.fecha = fecha;
        this.tipo_movimiento = tipo_movimiento;
        this.nro_documento = nro_documento;
        this.id_usuario = id_usuario;
    }

    public MovimientoArticuloDTO(Date fecha, int tipo_movimiento, String nro_documento, int id_usuario) {
        this.fecha = fecha;
        this.tipo_movimiento = tipo_movimiento;
        this.nro_documento = nro_documento;
        this.id_usuario = id_usuario;
    }

    public Long getIdmovimientos_articulos() {
        return idmovimientos_articulos;
    }

    public void setIdmovimientos_articulos(Long idmovimientos_articulos) {
        this.idmovimientos_articulos = idmovimientos_articulos;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public int getTipo_movimiento() {
        return tipo_movimiento;
    }

    public void setTipo_movimiento(int tipo_movimiento) {
        this.tipo_movimiento = tipo_movimiento;
    }

    public String getNro_documento() {
        return nro_documento;
    }

    public void setNro_documento(String nro_documento) {
        this.nro_documento = nro_documento;
    }

    public int getId_usuario() {
        return id_usuario;
    }

    public void setId_usuario(int id_usuario) {
        this.id_usuario = id_usuario;
    }
    
    
}
