/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dto;

/**
 *
 * @author Ariel
 */
public class MovimientoArticuloDetalleDTO {
    private Long id_detalle_movimiento;
    private Long id_movimiento_articulo;
    private Long id_articulo;
    private int cantidad;
    private Double precio;

    public MovimientoArticuloDetalleDTO() {
    }

    public MovimientoArticuloDetalleDTO(Long id_detalle_movimiento, Long id_movimiento_articulo, Long id_articulo, int cantidad, Double precio) {
        this.id_detalle_movimiento = id_detalle_movimiento;
        this.id_movimiento_articulo = id_movimiento_articulo;
        this.id_articulo = id_articulo;
        this.cantidad = cantidad;
        this.precio = precio;
    }

    public MovimientoArticuloDetalleDTO(Long id_movimiento_articulo, Long id_articulo, int cantidad, Double precio) {
        this.id_movimiento_articulo = id_movimiento_articulo;
        this.id_articulo = id_articulo;
        this.cantidad = cantidad;
        this.precio = precio;
    }

    public Long getId_detalle_movimiento() {
        return id_detalle_movimiento;
    }

    public void setId_detalle_movimiento(Long id_detalle_movimiento) {
        this.id_detalle_movimiento = id_detalle_movimiento;
    }

    public Long getId_movimiento_articulo() {
        return id_movimiento_articulo;
    }

    public void setId_movimiento_articulo(Long id_movimiento_articulo) {
        this.id_movimiento_articulo = id_movimiento_articulo;
    }

    public Long getId_articulo() {
        return id_articulo;
    }

    public void setId_articulo(Long id_articulo) {
        this.id_articulo = id_articulo;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public Double getPrecio() {
        return precio;
    }

    public void setPrecio(Double precio) {
        this.precio = precio;
    }
    
    
}
