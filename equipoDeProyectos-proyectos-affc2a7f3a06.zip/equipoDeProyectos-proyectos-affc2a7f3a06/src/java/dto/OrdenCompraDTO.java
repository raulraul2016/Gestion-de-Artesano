/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dto;

import java.sql.Date;

/**
 *
 * @author Ariel
 */
public class OrdenCompraDTO {
    private Long id_orden_compra;
    private int id_usuario;
    private int id_proveedor;
    private String detalle;
    private Date fecha_creacion;

    public OrdenCompraDTO() {
    }

    public OrdenCompraDTO(int id_usuario, int id_proveedor, String detalle, Date fecha_creacion) {
        this.id_usuario = id_usuario;
        this.id_proveedor = id_proveedor;
        this.detalle = detalle;
        this.fecha_creacion = fecha_creacion;
    }

    public OrdenCompraDTO(Long id_orden_compra, int id_usuario, int id_proveedor, String detalle, Date fecha_creacion) {
        this.id_orden_compra = id_orden_compra;
        this.id_usuario = id_usuario;
        this.id_proveedor = id_proveedor;
        this.detalle = detalle;
        this.fecha_creacion = fecha_creacion;
    }

    public Long getId_orden_compra() {
        return id_orden_compra;
    }

    public void setId_orden_compra(Long id_orden_compra) {
        this.id_orden_compra = id_orden_compra;
    }

    public int getId_usuario() {
        return id_usuario;
    }

    public void setId_usuario(int id_usuario) {
        this.id_usuario = id_usuario;
    }

    public int getId_proveedor() {
        return id_proveedor;
    }

    public void setId_proveedor(int id_proveedor) {
        this.id_proveedor = id_proveedor;
    }

    public String getDetalle() {
        return detalle;
    }

    public void setDetalle(String detalle) {
        this.detalle = detalle;
    }

    public Date getFecha_creacion() {
        return fecha_creacion;
    }

    public void setFecha_creacion(Date fecha_creacion) {
        this.fecha_creacion = fecha_creacion;
    }

}
