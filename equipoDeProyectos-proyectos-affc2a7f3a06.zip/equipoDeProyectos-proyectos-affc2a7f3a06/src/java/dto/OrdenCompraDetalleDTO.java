/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dto;

import java.io.Serializable;

/**
 *
 * @author Ariel
 */
public class OrdenCompraDetalleDTO implements Serializable{
    private Long id_orden_compra_detalle;
    private Long id_orden_compra;
    private Long id_articulo;
    private int cantidad;
    private int cantidad_recibida;
    private Long idpedidoorigen;
    private Long iddetallepedidoorigen;

    public OrdenCompraDetalleDTO() {
    }

    public OrdenCompraDetalleDTO(Long id_orden_compra_detalle, Long id_orden_compra, Long id_articulo, int cantidad, int cantidad_recibida) {
        this.id_orden_compra_detalle = id_orden_compra_detalle;
        this.id_orden_compra = id_orden_compra;
        this.id_articulo = id_articulo;
        this.cantidad = cantidad;
        this.cantidad_recibida = cantidad_recibida;
    }

    public OrdenCompraDetalleDTO(Long id_orden_compra, Long id_articulo, int cantidad, int cantidad_recibida) {
        this.id_orden_compra = id_orden_compra;
        this.id_articulo = id_articulo;
        this.cantidad = cantidad;
        this.cantidad_recibida = cantidad_recibida;
    }

    public Long getId_orden_compra_detalle() {
        return id_orden_compra_detalle;
    }

    public void setId_orden_compra_detalle(Long id_orden_compra_detalle) {
        this.id_orden_compra_detalle = id_orden_compra_detalle;
    }

    public Long getId_orden_compra() {
        return id_orden_compra;
    }

    public void setId_orden_compra(Long id_orden_compra) {
        this.id_orden_compra = id_orden_compra;
    }

    public Long getId_articulo() {
        return id_articulo;
    }

    public void setId_articulo(Long id_articulo) {
        this.id_articulo = id_articulo;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public int getCantidad_recibida() {
        return cantidad_recibida;
    }

    public void setCantidad_recibida(int cantidad_recibida) {
        this.cantidad_recibida = cantidad_recibida;
    }

    public Long getIdpedidoorigen() {
        return idpedidoorigen;
    }

    public void setIdpedidoorigen(Long idpedidoorigen) {
        this.idpedidoorigen = idpedidoorigen;
    }

    public Long getIddetallepedidoorigen() {
        return iddetallepedidoorigen;
    }

    public void setIddetallepedidoorigen(Long iddetallepedidoorigen) {
        this.iddetallepedidoorigen = iddetallepedidoorigen;
    }
    
}
