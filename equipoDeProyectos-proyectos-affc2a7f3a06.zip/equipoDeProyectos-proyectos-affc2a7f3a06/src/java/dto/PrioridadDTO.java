/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dto;

/**
 *
 * @author Ariel
 */
public class PrioridadDTO {
    private int idprioridades;
    private String Nombre;

    public PrioridadDTO() {
    }

    public PrioridadDTO(int idprioridades, String Nombre) {
        this.idprioridades = idprioridades;
        this.Nombre = Nombre;
    }

    public int getIdprioridades() {
        return idprioridades;
    }

    public void setIdprioridades(int idprioridades) {
        this.idprioridades = idprioridades;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }
    
    
}
