/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dto;

/**
 *
 * @author yesi
 */
public class ProveedorDTO {
    private int id_proveedor;
    private String nombre_denominacion;
    private String direccion;
    private String cuit;
    private String telefono;
    private String mail;
    private String descripcion;
    private boolean activo;

    public ProveedorDTO() {
    }

    public ProveedorDTO(int id_proveedor, String nombre_denominacion, String direccion, String cuit, String telefono, String mail, String descripcion, boolean activo) {
        this.id_proveedor = id_proveedor;
        this.nombre_denominacion = nombre_denominacion;
        this.direccion = direccion;
        this.cuit = cuit;
        this.telefono = telefono;
        this.mail = mail;
        this.descripcion = descripcion;
        this.activo = activo;
    }

    public ProveedorDTO(String nombre_denominacion, String direccion, String cuit, String telefono, String mail, String descripcion, boolean activo) {
        this.nombre_denominacion = nombre_denominacion;
        this.direccion = direccion;
        this.cuit = cuit;
        this.telefono = telefono;
        this.mail = mail;
        this.descripcion = descripcion;
        this.activo = activo;
    }

    public int getId_proveedor() {
        return id_proveedor;
    }

    public void setId_proveedor(int id_proveedor) {
        this.id_proveedor = id_proveedor;
    }

    public String getNombre_denominacion() {
        return nombre_denominacion;
    }

    public void setNombre_denominacion(String nombre_denominacion) {
        this.nombre_denominacion = nombre_denominacion;
    }
    
    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getCuit() {
        return cuit;
    }

    public void setCuit(String cuit) {
        this.cuit = cuit;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getMail() {
        return mail;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public boolean isActivo() {
        return activo;
    }

    public void setActivo(boolean activo) {
        this.activo = activo;
    }
    
    
}
