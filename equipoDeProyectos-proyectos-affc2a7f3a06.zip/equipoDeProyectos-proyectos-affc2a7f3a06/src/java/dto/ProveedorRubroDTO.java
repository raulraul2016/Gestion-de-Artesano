/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dto;

/**
 *
 * @author Ariel
 */
public class ProveedorRubroDTO {
    private int idproveedor_rubro;
    private int id_proveedor;
    private int id_rubro;

    public ProveedorRubroDTO() {
    }

    public ProveedorRubroDTO(int id_proveedor, int id_rubro) {
        this.id_proveedor = id_proveedor;
        this.id_rubro = id_rubro;
    }

    public ProveedorRubroDTO(int idproveedor_rubro, int id_proveedor, int id_rubro) {
        this.idproveedor_rubro = idproveedor_rubro;
        this.id_proveedor = id_proveedor;
        this.id_rubro = id_rubro;
    }

    public int getIdproveedor_rubro() {
        return idproveedor_rubro;
    }

    public void setIdproveedor_rubro(int idproveedor_rubro) {
        this.idproveedor_rubro = idproveedor_rubro;
    }

    public int getId_proveedor() {
        return id_proveedor;
    }

    public void setId_proveedor(int id_proveedor) {
        this.id_proveedor = id_proveedor;
    }

    public int getId_rubro() {
        return id_rubro;
    }

    public void setId_rubro(int id_rubro) {
        this.id_rubro = id_rubro;
    }
    
    
    
}
