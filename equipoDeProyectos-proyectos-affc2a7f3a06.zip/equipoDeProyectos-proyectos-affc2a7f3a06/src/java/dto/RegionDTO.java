/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dto;

/**
 *
 * @author Ariel
 */
public class RegionDTO {
    private int id_regiones;
    private String nombre;

    public RegionDTO() {
    }

    public RegionDTO(String nombre) {
        this.nombre = nombre;
    }

    public RegionDTO(int id_regiones, String nombre) {
        this.id_regiones = id_regiones;
        this.nombre = nombre;
    }

    public int getId_regiones() {
        return id_regiones;
    }

    public void setId_regiones(int id_regiones) {
        this.id_regiones = id_regiones;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    
}
