/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dto;

import java.util.Date;

/**
 *
 * @author Ariel
 */
public class RemitoDTO {
    private Long id_remito;
    private int id_proveedor;
    private Long id_orden_compra_asociada;
    private int id_usuario;
    private String nro_remito;
    private Date fecha_ingreso;

    public RemitoDTO(Long id_remito, int id_proveedor, Long id_orden_compra_asociada, int id_usuario, String nro_remito, Date fecha_ingreso) {
        this.id_remito = id_remito;
        this.id_proveedor = id_proveedor;
        this.id_orden_compra_asociada = id_orden_compra_asociada;
        this.id_usuario = id_usuario;
        this.nro_remito = nro_remito;
        this.fecha_ingreso = fecha_ingreso;
    }

    public RemitoDTO(int id_proveedor, Long id_orden_compra_asociada, int id_usuario, String nro_remito, Date fecha_ingreso) {
        this.id_proveedor = id_proveedor;
        this.id_orden_compra_asociada = id_orden_compra_asociada;
        this.id_usuario = id_usuario;
        this.nro_remito = nro_remito;
        this.fecha_ingreso = fecha_ingreso;
    }

    public RemitoDTO() {
    }

    public Long getId_remito() {
        return id_remito;
    }

    public void setId_remito(Long id_remito) {
        this.id_remito = id_remito;
    }

    public int getId_proveedor() {
        return id_proveedor;
    }

    public void setId_proveedor(int id_proveedor) {
        this.id_proveedor = id_proveedor;
    }

    public Long getId_orden_compra_asociada() {
        return id_orden_compra_asociada;
    }

    public void setId_orden_compra_asociada(Long id_orden_compra_asociada) {
        this.id_orden_compra_asociada = id_orden_compra_asociada;
    }

    public int getId_usuario() {
        return id_usuario;
    }

    public void setId_usuario(int id_usuario) {
        this.id_usuario = id_usuario;
    }

    public String getNro_remito() {
        return nro_remito;
    }

    public void setNro_remito(String nro_remito) {
        this.nro_remito = nro_remito;
    }

    public Date getFecha_ingreso() {
        return fecha_ingreso;
    }

    public void setFecha_ingreso(Date fecha_ingreso) {
        this.fecha_ingreso = fecha_ingreso;
    }
    
    
}
