/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dto;

/**
 *
 * @author Ariel
 */
public class RemitoDetalleDTO {
    private Long id_detalle_remito;
    private Long id_remito;
    private Long id_articulo;
    private int cantidad;
    private Double precio;

    public RemitoDetalleDTO() {
    }

    public RemitoDetalleDTO(Long id_detalle_remito, Long id_remito, Long id_articulo, int cantidad, Double precio) {
        this.id_detalle_remito = id_detalle_remito;
        this.id_remito = id_remito;
        this.id_articulo = id_articulo;
        this.cantidad = cantidad;
        this.precio = precio;
    }

    public RemitoDetalleDTO(Long id_remito, Long id_articulo, int cantidad, Double precio) {
        this.id_remito = id_remito;
        this.id_articulo = id_articulo;
        this.cantidad = cantidad;
        this.precio = precio;
    }

    public Long getId_detalle_remito() {
        return id_detalle_remito;
    }

    public void setId_detalle_remito(Long id_detalle_remito) {
        this.id_detalle_remito = id_detalle_remito;
    }

    public Long getId_remito() {
        return id_remito;
    }

    public void setId_remito(Long id_remito) {
        this.id_remito = id_remito;
    }

    public Long getId_articulo() {
        return id_articulo;
    }

    public void setId_articulo(Long id_articulo) {
        this.id_articulo = id_articulo;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public Double getPrecio() {
        return precio;
    }

    public void setPrecio(Double precio) {
        this.precio = precio;
    }
    
    
}
