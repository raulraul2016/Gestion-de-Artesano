/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dto;

/**
 *
 * @author yesi
 */
public class RubroDTO {
    
    private int id_rubro;
    private String nombre;

    public RubroDTO() {
    }

    public RubroDTO(String nombre) {
        this.nombre = nombre;
    }

    public RubroDTO(int id_rubro, String nombre) {
        this.id_rubro = id_rubro;
        this.nombre = nombre;
    }

    public int getId_rubro() {
        return id_rubro;
    }

    public void setId_rubro(int id_rubro) {
        this.id_rubro = id_rubro;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    
    
}
