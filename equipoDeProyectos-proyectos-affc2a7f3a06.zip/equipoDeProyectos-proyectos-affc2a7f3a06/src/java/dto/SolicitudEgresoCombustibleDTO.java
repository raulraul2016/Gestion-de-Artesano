/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dto;

import java.util.Date;

/**
 *
 * @author Ariel
 */
public class SolicitudEgresoCombustibleDTO {
    
    private Long idsolicitud_egreso_combustible;
    private int id_usuario;
    private int id_area_origen;
    private int estado;
    private String expendedor;
    private Date fecha;
    private String chofer;
    private String destino;
    private String motivo;
    private int km_salida;
    private int km_llegada;

    public SolicitudEgresoCombustibleDTO() {
    }

    public SolicitudEgresoCombustibleDTO(Long idsolicitud_egreso_combustible, int id_usuario, int id_area_origen, int estado, String expendedor, Date fecha, String chofer, String destino, String motivo, int km_salida, int km_llegada) {
        this.idsolicitud_egreso_combustible = idsolicitud_egreso_combustible;
        this.id_usuario = id_usuario;
        this.id_area_origen = id_area_origen;
        this.estado = estado;
        this.expendedor = expendedor;
        this.fecha = fecha;
        this.chofer = chofer;
        this.destino = destino;
        this.motivo = motivo;
        this.km_salida = km_salida;
        this.km_llegada = km_llegada;
    }

    

    public Long getIdsolicitud_egreso_combustible() {
        return idsolicitud_egreso_combustible;
    }

    public void setIdsolicitud_egreso_combustible(Long idsolicitud_egreso_combustible) {
        this.idsolicitud_egreso_combustible = idsolicitud_egreso_combustible;
    }

    public int getId_usuario() {
        return id_usuario;
    }

    public void setId_usuario(int id_usuario) {
        this.id_usuario = id_usuario;
    }

    public int getId_area_origen() {
        return id_area_origen;
    }

    public void setId_area_origen(int id_area_origen) {
        this.id_area_origen = id_area_origen;
    }

    public int getEstado() {
        return estado;
    }

    public void setEstado(int estado) {
        this.estado = estado;
    }

    public String getExpendedor() {
        return expendedor;
    }

    public void setExpendedor(String expendedor) {
        this.expendedor = expendedor;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public String getChofer() {
        return chofer;
    }

    public void setChofer(String chofer) {
        this.chofer = chofer;
    }

    public String getDestino() {
        return destino;
    }

    public void setDestino(String destino) {
        this.destino = destino;
    }

    public String getMotivo() {
        return motivo;
    }

    public void setMotivo(String motivo) {
        this.motivo = motivo;
    }

    public int getKm_salida() {
        return km_salida;
    }

    public void setKm_salida(int km_salida) {
        this.km_salida = km_salida;
    }

    public int getKm_llegada() {
        return km_llegada;
    }

    public void setKm_llegada(int km_llegada) {
        this.km_llegada = km_llegada;
    }
   
}
