/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dto;

import java.util.Date;

/**
 *
 * @author Ariel
 */
public class SolicitudEgresoDTO {
    private Long id_solicitud_egreso;
    private int id_usuario;
    private int estado;
    private int id_area_origen;
    private Long id_centro_costo_destino;
    private Long id_item_centro_costo_destino;
    private Date fecha_creacion;
    private Date fecha_modificacion;
    private Date fecha_anulacion;
    private String retira;

    public SolicitudEgresoDTO() {
    }

    public SolicitudEgresoDTO(Long id_solicitud_egreso, int id_usuario, int estado, int id_area_origen, Long id_centro_costo_destino, Long id_item_centro_costo_destino, Date fecha_creacion, Date fecha_modificacion, Date fecha_anulacion, String retira) {
        this.id_solicitud_egreso = id_solicitud_egreso;
        this.id_usuario = id_usuario;
        this.estado = estado;
        this.id_area_origen = id_area_origen;
        this.id_centro_costo_destino = id_centro_costo_destino;
        this.id_item_centro_costo_destino = id_item_centro_costo_destino;
        this.fecha_creacion = fecha_creacion;
        this.fecha_modificacion = fecha_modificacion;
        this.fecha_anulacion = fecha_anulacion;
        this.retira = retira;
    }

    public SolicitudEgresoDTO(int id_usuario, int estado, int id_area_origen, Long id_centro_costo_destino, Long id_item_centro_costo_destino, Date fecha_creacion, Date fecha_modificacion, Date fecha_anulacion, String retira) {
        this.id_usuario = id_usuario;
        this.estado = estado;
        this.id_area_origen = id_area_origen;
        this.id_centro_costo_destino = id_centro_costo_destino;
        this.id_item_centro_costo_destino = id_item_centro_costo_destino;
        this.fecha_creacion = fecha_creacion;
        this.fecha_modificacion = fecha_modificacion;
        this.fecha_anulacion = fecha_anulacion;
        this.retira = retira;
    }


    public Long getId_solicitud_egreso() {
        return id_solicitud_egreso;
    }

    public void setId_solicitud_egreso(Long id_solicitud_egreso) {
        this.id_solicitud_egreso = id_solicitud_egreso;
    }

    public int getId_usuario() {
        return id_usuario;
    }

    public void setId_usuario(int id_usuario) {
        this.id_usuario = id_usuario;
    }

    public int getEstado() {
        return estado;
    }

    public void setEstado(int estado) {
        this.estado = estado;
    }

    public int getId_area_origen() {
        return id_area_origen;
    }

    public void setId_area_origen(int id_area_origen) {
        this.id_area_origen = id_area_origen;
    }

    public Long getId_centro_costo_destino() {
        return id_centro_costo_destino;
    }

    public void setId_centro_costo_destino(Long id_centro_costo_destino) {
        this.id_centro_costo_destino = id_centro_costo_destino;
    }

    public Long getId_item_centro_costo_destino() {
        return id_item_centro_costo_destino;
    }

    public void setId_item_centro_costo_destino(Long id_item_centro_costo_destino) {
        this.id_item_centro_costo_destino = id_item_centro_costo_destino;
    }

    public Date getFecha_creacion() {
        return fecha_creacion;
    }

    public void setFecha_creacion(Date fecha_creacion) {
        this.fecha_creacion = fecha_creacion;
    }

    public Date getFecha_modificacion() {
        return fecha_modificacion;
    }

    public void setFecha_modificacion(Date fecha_modificacion) {
        this.fecha_modificacion = fecha_modificacion;
    }

    public Date getFecha_anulacion() {
        return fecha_anulacion;
    }

    public void setFecha_anulacion(Date fecha_anulacion) {
        this.fecha_anulacion = fecha_anulacion;
    }

    public String getRetira() {
        return retira;
    }

    public void setRetira(String retira) {
        this.retira = retira;
    }
    
}
