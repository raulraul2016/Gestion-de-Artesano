/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dto;

/**
 *
 * @author Ariel
 */
public class SolicitudEgresoDetalleDTO {
    private Long id_detalle_solicitud_egreso;
    private Long id_solicitud_egreso;
    private Long id_articulo;
    private int cantidad_pedida;
    private int cantidad_aprobada;

    public SolicitudEgresoDetalleDTO() {
    }

    public SolicitudEgresoDetalleDTO(Long id_solicitud_egreso_detalle, Long id_solicitud_egreso, Long id_articulo, int cantidad_pedida, int cantidad_aprobada) {
        this.id_detalle_solicitud_egreso = id_solicitud_egreso_detalle;
        this.id_solicitud_egreso = id_solicitud_egreso;
        this.id_articulo = id_articulo;
        this.cantidad_pedida = cantidad_pedida;
        this.cantidad_aprobada = cantidad_aprobada;
    }

    public SolicitudEgresoDetalleDTO(Long id_solicitud_egreso, Long id_articulo, int cantidad_pedida, int cantidad_aprobada) {
        this.id_solicitud_egreso = id_solicitud_egreso;
        this.id_articulo = id_articulo;
        this.cantidad_pedida = cantidad_pedida;
        this.cantidad_aprobada = cantidad_aprobada;
    }

    public Long getId_detalle_solicitud_egreso() {
        return id_detalle_solicitud_egreso;
    }

    public void setId_detalle_solicitud_egreso(Long id_detalle_solicitud_egreso) {
        this.id_detalle_solicitud_egreso = id_detalle_solicitud_egreso;
    }

    public Long getId_solicitud_egreso() {
        return id_solicitud_egreso;
    }

    public void setId_solicitud_egreso(Long id_solicitud_egreso) {
        this.id_solicitud_egreso = id_solicitud_egreso;
    }

    public Long getId_articulo() {
        return id_articulo;
    }

    public void setId_articulo(Long id_articulo) {
        this.id_articulo = id_articulo;
    }

    public int getCantidad_pedida() {
        return cantidad_pedida;
    }

    public void setCantidad_pedida(int cantidad_pedida) {
        this.cantidad_pedida = cantidad_pedida;
    }

    public int getCantidad_aprobada() {
        return cantidad_aprobada;
    }

    public void setCantidad_aprobada(int cantidad_aprobada) {
        this.cantidad_aprobada = cantidad_aprobada;
    }
    
}
