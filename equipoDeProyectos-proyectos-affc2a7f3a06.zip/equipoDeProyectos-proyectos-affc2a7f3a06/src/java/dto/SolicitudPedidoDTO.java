/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dto;

import java.util.Date;

/**
 *
 * @author Ariel
 */
public class SolicitudPedidoDTO {
    private Long id_solicitud;
    private int id_usuario;
    private int id_prioridad;
    private int estado;
    private int origen;
    private int proveedor;
    private Date fecha_creacion;
    private Date fecha_modificacion;
    private Date fecha_anulacion;

    public SolicitudPedidoDTO() {
    }

    public SolicitudPedidoDTO(Long id_solicitud, int id_usuario, int id_prioridad, int estado, int origen, int proveedor, Date fecha_creacion, Date fecha_modificacion, Date fecha_anulacion) {
        this.id_solicitud = id_solicitud;
        this.id_usuario = id_usuario;
        this.id_prioridad = id_prioridad;
        this.estado = estado;
        this.origen = origen;
        this.proveedor = proveedor;
        this.fecha_creacion = fecha_creacion;
        this.fecha_modificacion = fecha_modificacion;
        this.fecha_anulacion = fecha_anulacion;
    }

    public SolicitudPedidoDTO(int id_usuario, int id_prioridad, int estado, int origen, int proveedor, Date fecha_creacion, Date fecha_modificacion, Date fecha_anulacion) {
        this.id_usuario = id_usuario;
        this.id_prioridad = id_prioridad;
        this.estado = estado;
        this.origen = origen;
        this.proveedor = proveedor;
        this.fecha_creacion = fecha_creacion;
        this.fecha_modificacion = fecha_modificacion;
        this.fecha_anulacion = fecha_anulacion;
    }

    
 
    public Long getId_solicitud() {
        return id_solicitud;
    }

    public void setId_solicitud(Long id_solicitud) {
        this.id_solicitud = id_solicitud;
    }

    public int getId_usuario() {
        return id_usuario;
    }

    public void setId_usuario(int id_usuario) {
        this.id_usuario = id_usuario;
    }

    public int getId_prioridad() {
        return id_prioridad;
    }

    public void setId_prioridad(int id_prioridad) {
        this.id_prioridad = id_prioridad;
    }

    public int getEstado() {
        return estado;
    }

    public void setEstado(int estado) {
        this.estado = estado;
    }

    public int getOrigen() {
        return origen;
    }

    public void setOrigen(int origen) {
        this.origen = origen;
    }

    public int getProveedor() {
        return proveedor;
    }

    public void setProveedor(int proveedor) {
        this.proveedor = proveedor;
    }

      
    public Date getFecha_creacion() {
        return fecha_creacion;
    }

    public void setFecha_creacion(Date fecha_creacion) {
        this.fecha_creacion = fecha_creacion;
    }

    public Date getFecha_modificacion() {
        return fecha_modificacion;
    }

    public void setFecha_modificacion(Date fecha_modificacion) {
        this.fecha_modificacion = fecha_modificacion;
    }

    public Date getFecha_anulacion() {
        return fecha_anulacion;
    }

    public void setFecha_anulacion(Date fecha_anulacion) {
        this.fecha_anulacion = fecha_anulacion;
    }
    
    
}
