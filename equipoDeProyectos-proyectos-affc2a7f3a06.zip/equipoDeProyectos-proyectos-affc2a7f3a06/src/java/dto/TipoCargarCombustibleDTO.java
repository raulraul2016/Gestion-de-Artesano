/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dto;

/**
 *
 * @author Ariel
 */
public class TipoCargarCombustibleDTO {
    
    private int idtipo_carga_combustible;
    private String nombre;

    public TipoCargarCombustibleDTO() {
    }

    public TipoCargarCombustibleDTO(int idtipo_carga_combustible, String nombre) {
        this.idtipo_carga_combustible = idtipo_carga_combustible;
        this.nombre = nombre;
    }

    public TipoCargarCombustibleDTO(String nombre) {
        this.nombre = nombre;
    }

    public int getIdtipo_carga_combustible() {
        return idtipo_carga_combustible;
    }

    public void setIdtipo_carga_combustible(int idtipo_carga_combustible) {
        this.idtipo_carga_combustible = idtipo_carga_combustible;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    
    
}
