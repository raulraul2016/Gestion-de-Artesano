/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dto;

/**
 *
 * @author Ariel
 */
public class TipoMovimientoDTO {
    private int idtipo_movimiento;
    private String nombre;

    public TipoMovimientoDTO() {
    }

    public TipoMovimientoDTO(int idtipo_movimiento, String nombre) {
        this.idtipo_movimiento = idtipo_movimiento;
        this.nombre = nombre;
    }

    public int getIdtipo_movimiento() {
        return idtipo_movimiento;
    }

    public void setIdtipo_movimiento(int idtipo_movimiento) {
        this.idtipo_movimiento = idtipo_movimiento;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
}
