/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlet;

import dao.ArticuloDAO;
import dao.CentroCostoDAO;
import dao.CentroCostoItemDAO;
import dao.FormaCargaCombustibleDAO;
import dao.MedidaDAO;
import dto.ArticuloDTO;
import dto.CentroCostoDTO;
import dto.CentroCostoItemDTO;
import dto.FormaCargaCombustibleDTO;
import dto.MedidaDTO;
import dto.SolicitudEgresoCombustibleDTO;
import dto.SolicitudEgresoCombustibleDetalleDTO;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Ariel
 */
public class AgregarDetalleEgresoCombustible extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        CentroCostoDAO costoDAO=new CentroCostoDAO();
        ArrayList<CentroCostoDTO> centroCostoDTOs=(ArrayList<CentroCostoDTO>) costoDAO.extraerTodos();
        CentroCostoItemDAO itemDAO=new CentroCostoItemDAO();
        ArrayList<CentroCostoItemDTO> itemDTOs=(ArrayList<CentroCostoItemDTO>) itemDAO.extraerTodos();
        ArrayList<FormaCargaCombustibleDTO> listaFormas= new ArrayList<FormaCargaCombustibleDTO>();
        FormaCargaCombustibleDAO prdao=new FormaCargaCombustibleDAO();
        ArticuloDAO adao = new ArticuloDAO();
        ArticuloDTO artaux;
        ArrayList<ArticuloDTO> listaarticulos = (ArrayList<ArticuloDTO>) adao.extraerTodosStock();
        MedidaDAO mdao = new MedidaDAO();
        String usado = "no usado";
        Boolean cantexce=false;
        ArrayList<MedidaDTO> listamedidas = (ArrayList<MedidaDTO>) mdao.extraerTodos();
        SolicitudEgresoCombustibleDTO spdto = (SolicitudEgresoCombustibleDTO) request.getSession().getAttribute("solicitud_egreso_combustible");
        ArrayList<SolicitudEgresoCombustibleDetalleDTO> list = (ArrayList<SolicitudEgresoCombustibleDetalleDTO>) request.getSession().getAttribute("listadetalleegresocombustible");
        if (spdto == null) {
            spdto = new SolicitudEgresoCombustibleDTO();
            spdto.setId_usuario(Integer.parseInt(request.getSession().getAttribute("id").toString()));
            spdto.setEstado(1);
            spdto.setId_area_origen(Integer.parseInt(request.getSession().getAttribute("area").toString()));
            spdto.setChofer(request.getParameter("chofer"));
            spdto.setDestino(request.getParameter("movilidad"));
            spdto.setExpendedor(request.getParameter("proveedor"));
            spdto.setMotivo(request.getParameter("motivo"));
            if(!request.getParameter("km_llegada").equals("")){
            spdto.setKm_llegada(Integer.parseInt(request.getParameter("km_llegada")));}
            if(!request.getParameter("km_llegada").equals("")){
            spdto.setKm_salida(Integer.parseInt(request.getParameter("km_salida")));}
            String formass=request.getParameter("tipoCarga");
            String[] formasString= formass.split(",");
            Integer[] formas= new Integer[formasString.length];
            for(int i=0;i<formasString.length;i++){
                formas[i]=Integer.valueOf(formasString[i]);}
            for(int i=0;i<formas.length;i++){
                FormaCargaCombustibleDTO prdto=new FormaCargaCombustibleDTO();
                prdto.setIdTipoCarga(formas[i]);
                    listaFormas.add(prdto);
            }
            request.getSession().setAttribute("listaFormas", listaFormas);
            request.getSession().setAttribute("solicitud_egreso_combustible", spdto);
            
            SolicitudEgresoCombustibleDetalleDTO spddto = new SolicitudEgresoCombustibleDetalleDTO();

            spddto.setId_articulo(Long.valueOf(request.getParameter("articulo")));
            artaux = (ArticuloDTO) adao.extraer(Long.valueOf(request.getParameter("articulo")));
            spddto.setCantidad_pedida(Integer.parseInt(request.getParameter("cantidad")));
            if (spddto.getId_articulo() != 0) {
                if (list == null) {
                    list = new ArrayList<SolicitudEgresoCombustibleDetalleDTO>();
                    if (spddto.getCantidad_pedida() > artaux.getStock_actual()) {
                        cantexce=true;
                    } else {
                        list.add(spddto);
                        request.getSession().setAttribute("listadetalleegresocombustible", list);
                    }
                } else {
                    for (int i = 0; i < list.size(); i++) {
                        if (list.get(i).getId_articulo().equals(spddto.getId_articulo())) {
                            i = list.size();
                            usado = "usado";
                        }
                    }
                    if (usado.equals("no usado")) {
                        if (spddto.getCantidad_pedida() > artaux.getStock_actual()) {
                        cantexce=true;
                    } else {
                        list.add(spddto);
                        request.getSession().setAttribute("listadetalleegresocombustible", list);
                    }
                    }
                }
            } else {
                out.println("<script type=\"text/javascript\">");
                out.println("alert('Debe seleccionar articulo');");
                out.println("</script>");
            }
        } else if (request.getParameter("articulo").equals("0")) {
            out.println("<script type=\"text/javascript\">");
            out.println("alert('No eligio el articulo para agregar al pedido pedido');");
            out.println("</script>");
        } else {
            SolicitudEgresoCombustibleDetalleDTO spddto = new SolicitudEgresoCombustibleDetalleDTO();
            spddto.setId_articulo(Long.valueOf(request.getParameter("articulo")));
            artaux = (ArticuloDTO) adao.extraer(Long.valueOf(request.getParameter("articulo")));
            spddto.setCantidad_pedida(Integer.parseInt(request.getParameter("cantidad")));
            if (spddto.getId_articulo() != 0) {
                if (list == null) {
                    list = new ArrayList<SolicitudEgresoCombustibleDetalleDTO>();
                    list.add(spddto);
                    request.getSession().setAttribute("listadetalleegresocombustible", list);
                } else {
                    for (int i = 0; i < list.size(); i++) {
                        if (list.get(i).getId_articulo().equals(spddto.getId_articulo())) {
                            i = list.size();
                            usado = "usado";
                        }
                    }
                    if (usado.equals("no usado")) {
                        if (spddto.getCantidad_pedida() > artaux.getStock_actual()) {
                        cantexce=true;
                    } else {
                        list.add(spddto);
                        request.getSession().setAttribute("listadetalleegresocombustible", list);
                    }
                    }
                }
            } else {
                out.println("<script type=\"text/javascript\">");
                out.println("alert('Debe seleccionar articulo');");
                out.println("</script>");
            }
        }
        if(list!=null){
        out.println("<form id ='detallepedido'>"
                + "<table border = '1'> "
                + "<thead>"
                + "<tr>"
                + "<th id='columdepartamentolista' >Nombre</th>"
                + " <th id='columdepartamentolista'>Cantidad</th>"
                + "<th id='columregiondepartamentolista'>Uni.Medida</th>"
                + "<th colspan='2'>Accion</th>"
                + "</tr>"
                + "</thead>"
                + "<tbody id='tbodyegreso'>");
            for (int h = 0; h < list.size(); h++) {
                String nombre="";
                String medida="";
                out.println("<tr>");
                for (int k = 0; k < listaarticulos.size(); k++) {
                    if (listaarticulos.get(k).getId_articulo().equals(list.get(h).getId_articulo())) {
                        nombre=listaarticulos.get(k).getNombre();
                    }
                }
                out.println("<td>" +nombre+"</td>");
                out.println("<td>"+ list.get(h).getCantidad_pedida() + "</td>");
                for (int k = 0; k < listaarticulos.size(); k++) {
                    if (listaarticulos.get(k).getId_articulo().equals(list.get(h).getId_articulo())) {
                        for (int f = 0; f < listamedidas.size(); f++) {
                            if (listamedidas.get(f).getId_medida() == listaarticulos.get(k).getUnidad_medida()) {
                                 out.println("<td>" +listamedidas.get(f).getNombre()+"</td>");
                            }
                        }
                    }
                } 
                        out.println("<td><button type ='button' class='option' onclick ='eliminarDeEgreso("+h+")'>Eliminar</button></td>"
                                + "</tr>");
            }
        out.println("</tbody>"
                + "</table>"
                + "</form>");  
                }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
