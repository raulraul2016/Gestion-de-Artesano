/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlet;

import dao.OrdenCompraDAO;
import dao.OrdenCompraDetalleDAO;
import dto.OrdenCompraDetalleDTO;
import dto.RemitoDTO;
import dto.RemitoDetalleDTO;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Ariel
 */
public class AgregarDetalleRemito extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        RemitoDTO spdto= (RemitoDTO) request.getSession().getAttribute("remito");
        if(spdto==null){
        if(request.getParameter("orden_compra").equals("0")){
            out.println("<script type=\"text/javascript\">");  
            out.println("alert('No eligio oreden de compra asociada al remito');"); 
            out.println("location.href='ingresoremito.jsp?menu=1'"); 
            out.println("</script>");
        }else if(request.getParameter("proveedor").equals("0")&&request.getParameter("proveedor")!=null){
            out.println("<script type=\"text/javascript\">");  
            out.println("alert('No eligio proveddor del remito');"); 
            out.println("location.href='ingresoremito.jsp?menu=1'"); 
            out.println("</script>");
        }else if(request.getParameter("articulo").equals("0")){
            out.println("<script type=\"text/javascript\">");  
            out.println("alert('No eligio el articulo para agregar al remito');"); 
            out.println("location.href='ingresoremito.jsp?menu=1'"); 
            out.println("</script>");
        }else{
            spdto=new RemitoDTO();
            spdto.setId_usuario(Integer.parseInt(request.getSession().getAttribute("id").toString()));
            spdto.setId_orden_compra_asociada(Long.parseLong(request.getParameter("orden_compra")));
            spdto.setId_proveedor(Integer.parseInt(request.getParameter("proveedor")));
            OrdenCompraDAO ocdao=new OrdenCompraDAO();
            if(!ocdao.verificarexistencia(spdto.getId_proveedor())){
               out.println("<script type=\"text/javascript\">");  
                out.println("alert('El proveedor elegido no coincide con el de la orden de compra, verifique  la orden de compra');"); 
                out.println("location.href='ingresoremito.jsp?menu=1'"); 
                out.println("</script>"); 
            }
            OrdenCompraDetalleDAO ocddao=new OrdenCompraDetalleDAO();
            ArrayList<OrdenCompraDetalleDTO> detallescompra=(ArrayList<OrdenCompraDetalleDTO>) ocddao.extraerTodosF(spdto.getId_orden_compra_asociada());
            spdto.setNro_remito(request.getParameter("nro_remito"));
            
            //spdao.crear(spdto);
            //spdto.setId_solicitud(spdao.lastIdPedido(spdto.getId_usuario()));
            request.getSession().setAttribute("remito", spdto);
            RemitoDetalleDTO spddto= new RemitoDetalleDTO();
            ArrayList<RemitoDetalleDTO> list= (ArrayList<RemitoDetalleDTO>) request.getSession().getAttribute("listadetalleremito");
            //spddto.setId_solicitud(spdto.getId_solicitud());
            spddto.setId_articulo(Long.valueOf(request.getParameter("articulo")));
            spddto.setCantidad(Integer.parseInt(request.getParameter("cantidad")));
            if(!request.getParameter("precio").isEmpty()){
            spddto.setPrecio(Double.parseDouble(request.getParameter("precio")));}
            if(spddto.getId_articulo()!=0){
                if(list==null){
                    int cantidad=0;
                    boolean existe=false;
                    list= new ArrayList<RemitoDetalleDTO>();
                    for(int i=0;i<detallescompra.size();i++){
                        if(spddto.getId_articulo().equals(detallescompra.get(i).getId_articulo())){
                            existe=true;
                            cantidad=detallescompra.get(i).getCantidad()-detallescompra.get(i).getCantidad_recibida();
                        }
                    }
                    if(existe){
                    if(spddto.getCantidad()<=cantidad){
                    list.add(spddto);
                    request.getSession().setAttribute("listadetalleremito", list);
                    response.sendRedirect("ingresoremito.jsp");
                    }else{
                        out.println("<script type=\"text/javascript\">");  
                        out.println("alert('El art�culo excede la cantidad que indica la orden de compra, verifique la orden de compra');"); 
                        out.println("location.href='ingresoremito.jsp'"); 
                        out.println("</script>");
                    }
                    }else{
                        out.println("<script type=\"text/javascript\">");  
                        out.println("alert('El art�culo no se encuentra en la orden de compra indicada, verifique la orden de compra');"); 
                        out.println("location.href='ingresoremito.jsp'"); 
                        out.println("</script>");
                    }
                }else{
                    boolean usado=false;
                    boolean existe=false;
                    int cantidad=0;
                    for(int i=0;i<list.size();i++){
                        if(list.get(i).getId_articulo().equals(spddto.getId_articulo())){
                            usado=true;
                            i=list.size();
                        }
                    }
                    if(!usado){
                    for(int i=0;i<detallescompra.size();i++){
                        if(spddto.getId_articulo().equals(detallescompra.get(i).getId_articulo())){
                            cantidad=detallescompra.get(i).getCantidad()-detallescompra.get(i).getCantidad_recibida();
                            existe=true;
                        }
                    }
                    if(existe){
                    if(spddto.getCantidad()<=cantidad){
                    list.add(spddto);
                    request.getSession().setAttribute("listadetalleremito", list);
                    response.sendRedirect("ingresoremito.jsp");
                    }else{
                        out.println("<script type=\"text/javascript\">");  
                        out.println("alert('El art�culo excede la cantidad que indica la orden de compra, verifique la orden de compra');"); 
                        out.println("location.href='ingresoremito.jsp'"); 
                        out.println("</script>");
                    }
                    }else{
                        out.println("<script type=\"text/javascript\">");  
                        out.println("alert('El art�culo no se encuentra en la orden de compra indicada, verifique la orden de compra');"); 
                        out.println("location.href='ingresoremito.jsp'"); 
                        out.println("</script>");
                    }
                    }else{
                        response.sendRedirect("ingresoremito.jsp");
                    }
                }
            }else{
            out.println("<script type=\"text/javascript\">");  
            out.println("alert('Debe seleccionar articulo');"); 
            out.println("location.href='ingresoremito.jsp'"); 
            out.println("</script>");
            }}}else{
            if(request.getParameter("articulo").equals("0")){
            out.println("<script type=\"text/javascript\">");  
            out.println("alert('No eligio el articulo para agregar al remito');"); 
            out.println("location.href='ingresoremito.jsp'"); 
            out.println("</script>");
        }else{
        RemitoDetalleDTO spddto= new RemitoDetalleDTO();
        ArrayList<RemitoDetalleDTO> list= (ArrayList<RemitoDetalleDTO>) request.getSession().getAttribute("listadetalleremito");
        //spddto.setId_solicitud(spdto.getId_solicitud());
        OrdenCompraDetalleDAO ocddao=new OrdenCompraDetalleDAO();
        ArrayList<OrdenCompraDetalleDTO> detallescompra=(ArrayList<OrdenCompraDetalleDTO>) ocddao.extraerTodosF(spdto.getId_orden_compra_asociada());
        spddto.setId_articulo(Long.valueOf(request.getParameter("articulo")));
        spddto.setCantidad(Integer.parseInt(request.getParameter("cantidad")));
        if(!request.getParameter("precio").isEmpty()){
        spddto.setPrecio(Double.parseDouble(request.getParameter("precio")));}
        if(spddto.getId_articulo()!=0){
            if(list==null){
                boolean existe=false;
                int cantidad=0;
                list= new ArrayList<RemitoDetalleDTO>();
                for(int i=0;i<detallescompra.size();i++){
                        if(spddto.getId_articulo().equals(detallescompra.get(i).getId_articulo())){
                            cantidad=detallescompra.get(i).getCantidad()-detallescompra.get(i).getCantidad_recibida();
                            existe=true;
                        }
                    }
                    if(existe){
                    if(spddto.getCantidad()<=cantidad){
                    list.add(spddto);
                    request.getSession().setAttribute("listadetalleremito", list);
                    response.sendRedirect("ingresoremito.jsp");
                    }else{
                        out.println("<script type=\"text/javascript\">");  
                        out.println("alert('El art�culo excede la cantidad que indica la orden de compra, verifique la orden de compra');"); 
                        out.println("location.href='ingresoremito.jsp'"); 
                        out.println("</script>");
                    }
                    }else{
                        out.println("<script type=\"text/javascript\">");  
                        out.println("alert('El art�culo no se encuentra en la orden de compra indicada, verifique la orden de compra');"); 
                        out.println("location.href='ingresoremito.jsp'"); 
                        out.println("</script>");
                    }
            }else{
                boolean usado=false;
                boolean existe=false;
                int cantidad=0;
                    for(int i=0;i<list.size();i++){
                        if(list.get(i).getId_articulo().equals(spddto.getId_articulo())){
                            usado=true;
                            i=list.size();
                        }
                    }
                    if(!usado){
                    for(int i=0;i<detallescompra.size();i++){
                        if(spddto.getId_articulo().equals(detallescompra.get(i).getId_articulo())){
                            cantidad=detallescompra.get(i).getCantidad()-detallescompra.get(i).getCantidad_recibida();
                            existe=true;
                        }
                    }
                    if(existe){
                    if(spddto.getCantidad()<=cantidad){
                    list.add(spddto);
                    request.getSession().setAttribute("listadetalleremito", list);
                    response.sendRedirect("ingresoremito.jsp");
                    }else{
                        out.println("<script type=\"text/javascript\">");  
                        out.println("alert('El art�culo excede la cantidad que indica la orden de compra, verifique la orden de compra');"); 
                        out.println("location.href='ingresoremito.jsp'"); 
                        out.println("</script>");
                    }
                    }else{
                        out.println("<script type=\"text/javascript\">");  
                        out.println("alert('El art�culo no se encuentra en la orden de compra indicada, verifique la orden de compra');"); 
                        out.println("location.href='ingresoremito.jsp'"); 
                        out.println("</script>");
                    }
                    }else{
                        response.sendRedirect("ingresoremito.jsp");
                    }
            }
        }else{
            out.println("<script type=\"text/javascript\">");  
            out.println("alert('Debe seleccionar articulo');"); 
            out.println("location.href='ingresoremito.jsp'"); 
            out.println("</script>");
        }
            }}
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
