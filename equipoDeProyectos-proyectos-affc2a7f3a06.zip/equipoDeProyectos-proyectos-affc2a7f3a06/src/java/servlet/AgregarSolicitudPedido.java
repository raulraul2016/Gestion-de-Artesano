/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlet;

import dao.SolicitudPedidoDAO;
import dao.SolicitudPedidoDetalleDAO;
import dto.SolicitudPedidoDTO;
import dto.SolicitudPedidoDetalleDTO;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Ariel
 */
public class AgregarSolicitudPedido extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        SolicitudPedidoDetalleDAO spddao= new SolicitudPedidoDetalleDAO();
        SolicitudPedidoDAO spdao=new SolicitudPedidoDAO();
        SolicitudPedidoDTO spdto= (SolicitudPedidoDTO) request.getSession().getAttribute("solicitud_pedido");
        ArrayList<SolicitudPedidoDetalleDTO> list= (ArrayList<SolicitudPedidoDetalleDTO>) request.getSession().getAttribute("listadetallepedido");
        if(spdto!=null){
            if(spdao.crear(spdto)){
            spdto.setId_solicitud(spdao.lastIdPedido(spdto.getId_usuario()));
            if(list!=null){
                for(int i=0; i<list.size();i++){
                    list.get(i).setId_solicitud(spdto.getId_solicitud());
                    if(!spddao.crear(list.get(i))){
                        out.println("<script type=\"text/javascript\">");  
                        out.println("alert('Error al insertar articulo en el pedido');"); 
                        out.println("location.href='solicitararticulos.jsp'"); 
                        out.println("</script>");
                    }
                }
                        
            }else{
                        out.println("<script type=\"text/javascript\">");  
                        out.println("alert('No hay articulos en el pedido');"); 
                        out.println("location.href='solicitararticulos.jsp'"); 
                        out.println("</script>");
            }
            }else{
                        out.println("<script type=\"text/javascript\">");  
                        out.println("alert('No se pudo crear el pedido, intente nuevamente');"); 
                        out.println("location.href='solicitararticulos.jsp'"); 
                        out.println("</script>");
            }
                        request.getSession().setAttribute("solicitud_pedido", null);
                        request.getSession().setAttribute("listadetallepedido", null);
                        out.println("<script type=\"text/javascript\">");  
                        out.println("location.href='solicitararticulos.jsp'");  
                        out.println("alert('El pedido se envio correctamente');");
                        out.println("</script>");
        }else{
                        out.println("<script type=\"text/javascript\">");  
                        out.println("alert('No se ha localizado el pedido!');"); 
                        out.println("location.href='solicitararticulos.jsp'"); 
                        out.println("</script>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
