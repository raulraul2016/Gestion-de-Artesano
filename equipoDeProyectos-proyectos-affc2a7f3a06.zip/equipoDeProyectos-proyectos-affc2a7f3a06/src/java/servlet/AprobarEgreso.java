/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlet;

import dao.SolicitudEgresoDAO;
import dao.SolicitudEgresoDetalleDAO;
import dto.SolicitudEgresoDTO;
import dto.SolicitudEgresoDetalleDTO;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Ariel
 */
public class AprobarEgreso extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        SolicitudEgresoDAO spdao=new SolicitudEgresoDAO();
        SolicitudEgresoDetalleDAO spddao=new SolicitudEgresoDetalleDAO();
        SolicitudEgresoDTO spdto= (SolicitudEgresoDTO) spdao.extraer(request.getParameter("id_pedido"));
        if(spdto!=null){
            ArrayList<SolicitudEgresoDetalleDTO> detalle= (ArrayList<SolicitudEgresoDetalleDTO>) spddao.extraerTodosF(spdto.getId_solicitud_egreso());
            if(detalle.size()>0){
                for(int i=0;i<detalle.size();i++){
                    if(detalle.get(i).getCantidad_aprobada()==0){
                        spddao.borrar(detalle.get(i).getId_detalle_solicitud_egreso());
                    }
                }
                spdto.setEstado(3);
                if(!spdao.actualizar(spdto)){
                    out.println("<script type=\"text/javascript\">");  
                    out.println("alert('No se pudo cambiar el estado del pedido');"); 
                    out.println("location.href='egresospendientes.jsp'"); 
                    out.println("</script>");
                }else{
                    out.println("<script type=\"text/javascript\">");  
                    out.println("alert('El pedido se aprobo correctamente');"); 
                    out.println("location.href='egresospendientes.jsp'"); 
                    out.println("</script>");
                }
            }else{
            out.println("<script type=\"text/javascript\">");  
            out.println("alert('No hay articulos en el pedido');"); 
            out.println("location.href='egresospendientes.jsp'"); 
            out.println("</script>");
            }
        }else{
            out.println("<script type=\"text/javascript\">");  
            out.println("alert('No se pudo localizar el pedido');"); 
            out.println("location.href='egresospendientes.jsp'"); 
            out.println("</script>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
