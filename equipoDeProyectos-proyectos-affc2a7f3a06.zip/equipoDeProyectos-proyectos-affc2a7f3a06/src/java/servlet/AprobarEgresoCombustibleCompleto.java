/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlet;

import dao.ArticuloDAO;
import dao.MovimientoArticuloDAO;
import dao.MovimientoArticuloDetalleDAO;
import dao.SolicitudEgresoCombustibleDAO;
import dao.SolicitudEgresoCombustibleDetalleDAO;
import dto.MovimientoArticuloDTO;
import dto.MovimientoArticuloDetalleDTO;
import dto.SolicitudEgresoCombustibleDTO;
import dto.SolicitudEgresoCombustibleDetalleDTO;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Ariel
 */
public class AprobarEgresoCombustibleCompleto extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        ArticuloDAO adao=new ArticuloDAO();
        MovimientoArticuloDAO madao=new MovimientoArticuloDAO();
        MovimientoArticuloDetalleDAO maddao=new MovimientoArticuloDetalleDAO();
        SolicitudEgresoCombustibleDAO spdao=new SolicitudEgresoCombustibleDAO();
        SolicitudEgresoCombustibleDetalleDAO spddao=new SolicitudEgresoCombustibleDetalleDAO();
        SolicitudEgresoCombustibleDTO spdto= (SolicitudEgresoCombustibleDTO) spdao.extraer(request.getParameter("id_pedido"));
        if(spdto!=null){
            ArrayList<SolicitudEgresoCombustibleDetalleDTO> detallesolicitud= (ArrayList<SolicitudEgresoCombustibleDetalleDTO>) spddao.extraerTodosF(spdto.getIdsolicitud_egreso_combustible());
            if(detallesolicitud!=null){
                for(int i=0; i<detallesolicitud.size();i++){
                    detallesolicitud.get(i).setCantidad_aprobada(detallesolicitud.get(i).getCantidad_pedida());
                }
                if(!spddao.actualizarDetalles(detallesolicitud)){
                        out.println("<script type=\"text/javascript\">");  
                        out.println("alert('Error al insertar articulos en el pedido, intente nuevamente');"); 
                        out.println("location.href='egresoscombustiblependientes.jsp'"); 
                        out.println("</script>");
                }else{
                    spdto.setEstado(3);
                    if(!spdao.actualizar(spdto)){
                        out.println("<script type=\"text/javascript\">");  
                        out.println("alert('Error al actualizar pedido');"); 
                        out.println("location.href='egresoscombustiblependientes.jsp'"); 
                        out.println("</script>");
                    }else{
                        MovimientoArticuloDTO madto=new MovimientoArticuloDTO();
                        madto.setId_usuario(spdto.getId_usuario());
                        madto.setTipo_movimiento(2);
                        madto.setNro_documento("Egreso Combustible N�: "+spdto.getIdsolicitud_egreso_combustible().toString());
                        if (madao.crear(madto)) {
                            madto.setIdmovimientos_articulos(madao.lastIdPedido(madto.getId_usuario()));
                            for (int i = 0; i < detallesolicitud.size(); i++) {
                                MovimientoArticuloDetalleDTO maddto = new MovimientoArticuloDetalleDTO();
                                maddto.setId_movimiento_articulo(madto.getIdmovimientos_articulos());
                                maddto.setId_articulo(detallesolicitud.get(i).getId_articulo());
                                maddto.setCantidad(detallesolicitud.get(i).getCantidad_aprobada());
                                maddto.setPrecio(0.0);
                                adao.actualizarEgresoStock(detallesolicitud.get(i).getId_articulo(), detallesolicitud.get(i).getCantidad_aprobada());
                                maddao.crear(maddto);
                            }
                           out.println("<script type=\"text/javascript\">");  
                        out.println("alert('El pedido se aprobo correctamente');"); 
                        out.println("var win = window.open('imprimir_pedido_egreso_combustible?id_egreso_combustible="+spdto.getIdsolicitud_egreso_combustible()+"', 'blank');");
                        out.println("location.href='egresoscombustiblependientes.jsp'"); 
                        out.println("</script>"); 
                        }
                    }
                }
            }else{
            out.println("<script type=\"text/javascript\">");  
            out.println("alert('Error al obtener los articulos del pedido articulo en el pedido');"); 
            out.println("location.href='egresoscombustiblependientes.jsp'"); 
            out.println("</script>");
            }
        }else{
            out.println("<script type=\"text/javascript\">");  
            out.println("alert('Error al obtener el pedido');"); 
            out.println("location.href='egresoscombustiblependientes.jsp'"); 
            out.println("</script>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
