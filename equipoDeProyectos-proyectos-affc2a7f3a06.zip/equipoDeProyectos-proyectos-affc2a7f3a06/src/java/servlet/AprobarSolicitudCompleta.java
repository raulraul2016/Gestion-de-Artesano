/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlet;

import dao.SolicitudPedidoDAO;
import dao.SolicitudPedidoDetalleDAO;
import dto.SolicitudPedidoDTO;
import dto.SolicitudPedidoDetalleDTO;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Ariel
 */
@WebServlet(name = "AprobarSolicitudCompleta", urlPatterns = {"/aprobar_solicitud"})
public class AprobarSolicitudCompleta extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        SolicitudPedidoDAO spdao=new SolicitudPedidoDAO();
        SolicitudPedidoDetalleDAO spddao=new SolicitudPedidoDetalleDAO();
        SolicitudPedidoDTO spdto= (SolicitudPedidoDTO) spdao.extraer(request.getParameter("id_solicitud"));
        if(spdto!=null){
            ArrayList<SolicitudPedidoDetalleDTO> detallesolicitud= (ArrayList<SolicitudPedidoDetalleDTO>) spddao.extraerTodosF(spdto.getId_solicitud());
            if(detallesolicitud!=null){
                for(int i=0; i<detallesolicitud.size();i++){
                    detallesolicitud.get(i).setCantidad_aprobada(detallesolicitud.get(i).getCantidad_pedida());
                }
                if(!spddao.actualizarDetalles(detallesolicitud)){
                        out.println("<script type=\"text/javascript\">");  
                        out.println("alert('Error al insertar articulos en el pedido, intente nuevamente');"); 
                        out.println("location.href='solicitudespendientes.jsp'"); 
                        out.println("</script>");
                }else{
                    spdto.setEstado(3);
                    if(!spdao.actualizar(spdto)){
                        out.println("<script type=\"text/javascript\">");  
                        out.println("alert('Error al actualizar pedido');"); 
                        out.println("location.href='solicitudespendientes.jsp'"); 
                        out.println("</script>");
                    }else{
                        out.println("<script type=\"text/javascript\">");  
                        out.println("alert('El pedido se aprobo correctamente');"); 
                        out.println("location.href='solicitudespendientes.jsp'"); 
                        out.println("</script>");
                    }
                }
            }else{
            out.println("<script type=\"text/javascript\">");  
            out.println("alert('Error al obtener los articulos del pedido articulo en el pedido');"); 
            out.println("location.href='solicitudespendientes.jsp'"); 
            out.println("</script>");
            }
        }else{
            out.println("<script type=\"text/javascript\">");  
            out.println("alert('Error al obtener el pedido');"); 
            out.println("location.href='solicitudespendientes.jsp'"); 
            out.println("</script>");
        }
        
        
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
