/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlet;

import Reportes.EgresoCombustible;
import dao.EstadoDAO;
import dto.EstadoDTO;
import dto.SolicitudEgresoCombustibleDTO;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.JasperRunManager;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.engine.util.JRLoader;
import util.Filtro;

/**
 *
 * @author Ariel
 */
public class ImprimirEgresoCombustibleFiltrado extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException{
        response.setContentType("text/html;charset=UTF-8");
        ArrayList<SolicitudEgresoCombustibleDTO> listaegresos;
        Filtro filtro;
                
        if(request.getSession().getAttribute("misegresoscombustiblesfiltrado")!=null&&request.getSession().getAttribute("misegresoscombustiblesfiltro")!=null){
            filtro=(Filtro)request.getSession().getAttribute("misegresoscombustiblesfiltro");
            listaegresos= (ArrayList<SolicitudEgresoCombustibleDTO>) request.getSession().getAttribute("misegresoscombustiblesfiltrado");
        }else{
            filtro=(Filtro)request.getSession().getAttribute("egresoscombustiblesfiltro");
            listaegresos= (ArrayList<SolicitudEgresoCombustibleDTO>) request.getSession().getAttribute("listaegresoscombustibleparaimprimir");
        }
        String estado="";
        String destino="";
        if(filtro.columa.get("destino")!=null){
            destino=filtro.columa.get("destino");
        }
        EstadoDAO edao=new EstadoDAO();
        ArrayList<EstadoDTO> estados= (ArrayList<EstadoDTO>) edao.extraerTodos();
        ArrayList<EgresoCombustible> lista= new ArrayList<EgresoCombustible>();
        for(int i=0;i<listaegresos.size();i++){
            EgresoCombustible egreso=new EgresoCombustible();
                        egreso.setNro(listaegresos.get(i).getIdsolicitud_egreso_combustible());
                        if(listaegresos.get(i).getFecha()!=null){
                        egreso.setFecha(util.Util.getFechaMod(listaegresos.get(i).getFecha()));
                        }else{
                            egreso.setFecha("");
                        }
            for(int h=0;h<estados.size();h++){
                if(estados.get(h).getIdestados()==listaegresos.get(i).getEstado()){
                    egreso.setEstado(estados.get(h).getNombre());
                }
                if(filtro.columa.get("estado")!=null){
                    if(estados.get(h).getIdestados()==Integer.parseInt(filtro.columa.get("estado"))){
                    estado=estados.get(h).getNombre();
                }
                }
            }
            egreso.setDestino(listaegresos.get(i).getDestino());
            egreso.setMotivo(listaegresos.get(i).getMotivo());
            lista.add(egreso);
        }
        
        try {
            JasperReport reporte= (JasperReport) JRLoader.loadObject(getClass().getResource("/Reportes/egresosCombustibleFiltrado.jasper"));
            
            Map parametros= new HashMap <Object,Object>();
            parametros.put("estado",estado);
            if(!filtro.condicionFecha.isEmpty()){
                if(filtro.condicionFecha.equals(">")){
                parametros.put("desde",filtro.fechas.get(0));
                parametros.put("hasta","Hoy");
                }else if(filtro.condicionFecha.equals("<")){
                    parametros.put("desde","Inicio");
                    parametros.put("hasta",filtro.fechas.get(0));
                }else if(filtro.condicionFecha.equals("BETWEEN")){
                    parametros.put("desde",filtro.fechas.get(0));
                    parametros.put("hasta",filtro.fechas.get(1));
                }
            }else{
            parametros.put("desde","");
            parametros.put("hasta","");
            }
            parametros.put("destino",destino);
            parametros.put("CONTEXT",this.getServletContext().getRealPath("/"));
            byte[] bytes= JasperRunManager.runReportToPdf(reporte, parametros,new JRBeanCollectionDataSource(lista));
            response.setContentType("application/pdf");
            response.setContentLength(bytes.length);
            ServletOutputStream outputStream=response.getOutputStream();
            outputStream.write(bytes,0,bytes.length);
            outputStream.flush();
            outputStream.close();
//JasperViewer.viewReport(jasperPrint,true);
            
// TODO add your handling code here:
        } catch (JRException ex) {
            Logger.getLogger(ImprimirOrdenCompra.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
