/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlet;


import Reportes.MiEgreso;
import dao.AreaDAO;
import dao.CentroCostoDAO;
import dao.CentroCostoItemDAO;
import dao.EstadoDAO;
import dao.LocalidadDAO;
import dto.AreaDTO;
import dto.CentroCostoDTO;
import dto.CentroCostoItemDTO;
import dto.EstadoDTO;
import dto.LocalidadDTO;
import dto.SolicitudEgresoDTO;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.JasperRunManager;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.engine.util.JRLoader;

/**
 *
 * @author Ariel
 */
public class ImprimirMisegresosFiltrado extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int opcion=Integer.parseInt(request.getParameter("filtro"));
        ArrayList<SolicitudEgresoDTO> listaegresos= (ArrayList<SolicitudEgresoDTO>) request.getSession().getAttribute("listamisegresosparaimprimir");
        EstadoDAO edao=new EstadoDAO();
        ArrayList<EstadoDTO> estados= (ArrayList<EstadoDTO>) edao.extraerTodos();
        AreaDAO adao=new AreaDAO();
        ArrayList<AreaDTO> areas= (ArrayList<AreaDTO>) adao.extraerTodos();
        LocalidadDAO ldao=new LocalidadDAO();
        ArrayList<LocalidadDTO> localidades= (ArrayList<LocalidadDTO>) ldao.extraerTodos();
        CentroCostoDAO ccdao=new CentroCostoDAO();
        ArrayList<CentroCostoDTO> centroscosto= (ArrayList<CentroCostoDTO>) ccdao.extraerTodos();
        CentroCostoItemDAO ccidao=new CentroCostoItemDAO();
        ArrayList<CentroCostoItemDTO> centroscostoitem= (ArrayList<CentroCostoItemDTO>) ccidao.extraerTodos();
        
        ArrayList<MiEgreso> lista= new ArrayList<MiEgreso>();
        
        for(int i=0;i<listaegresos.size();i++){
            MiEgreso egreso=new MiEgreso();
                        egreso.setNro(listaegresos.get(i).getId_solicitud_egreso());
                        if(listaegresos.get(i).getFecha_creacion()!=null){
                        egreso.setFecha_creacion(util.Util.getFechaMod(listaegresos.get(i).getFecha_creacion()));
                        }else{
                            egreso.setFecha_creacion("");
                        }
                        if(listaegresos.get(i).getFecha_modificacion()!=null){
                        egreso.setFecha_modificacion(util.Util.getFechaMod(listaegresos.get(i).getFecha_modificacion()));
                        }else{
                        egreso.setFecha_modificacion("");
                        }
                        if(listaegresos.get(i).getFecha_anulacion()!=null){
                        egreso.setFecha_anulacion(util.Util.getFechaMod(listaegresos.get(i).getFecha_anulacion()));
                        }else{
                        egreso.setFecha_anulacion("");
                        }
                        
            for(int h=0;h<localidades.size();h++){
                for (int j = 0; j < centroscosto.size(); j++) {
                    if (listaegresos.get(i).getId_centro_costo_destino()!=0) {
                    if (centroscosto.get(j).getId_centros_costo().equals(listaegresos.get(i).getId_centro_costo_destino())) {
                        if (localidades.get(h).getId_localidades() == centroscosto.get(j).getId_localidad()) {
                            egreso.setLocalidad(localidades.get(h).getNombre());
                        }
                    }
                    }else{
                        egreso.setLocalidad("");
                    }
                }
            }
            for(int h=0;h<centroscosto.size();h++){
                if(centroscosto.get(h).getId_centros_costo().equals(listaegresos.get(i).getId_centro_costo_destino())){
                    egreso.setCentroCosto(centroscosto.get(h).getNombre());}
                else if(listaegresos.get(i).getId_centro_costo_destino()==0){
                    egreso.setCentroCosto("");
                }
            }
            for(int h=0;h<centroscostoitem.size();h++){
                if(centroscostoitem.get(h).getIditem_centro_costo().equals(listaegresos.get(i).getId_item_centro_costo_destino())){
                    egreso.setCentroCostoItem(centroscostoitem.get(h).getNombre());
                }else if(listaegresos.get(i).getId_centro_costo_destino()==0){
                    egreso.setCentroCostoItem("");
                }
            }
            for(int h=0;h<estados.size();h++){
                if(estados.get(h).getIdestados()==listaegresos.get(i).getEstado()){
                    egreso.setEstado(estados.get(h).getNombre());
                }
            }
            lista.add(egreso);
        }
        String estado="";
        String localidad="";
        String centroCosto="";
        String centroCostoItem="";
        String area="";
        for(int i=0; i<areas.size();i++){
            if(areas.get(i).getId()==Integer.parseInt(request.getSession().getAttribute("area").toString())){
            area=areas.get(i).getNombre_area();}
        }
        if(lista.size()!=0){
        switch(opcion){
            case 0:{
                estado="Todos";
                centroCosto="Todos";
                localidad="Todos";
                centroCostoItem="Todos";
                break;
            }
            case 1:{
                estado=lista.get(0).getEstado();
                centroCosto="Todos";
                localidad="Todos";
                centroCostoItem="Todos";
                break;
            }
            case 2:{
                estado="Todos";
                centroCosto="Todos";
                localidad=lista.get(0).getLocalidad();
                centroCostoItem="Todos";
                break;
            }
            case 3:{
                estado="Todos";
                centroCosto=lista.get(0).getCentroCosto();
                localidad="Todos";
                centroCostoItem=lista.get(0).getCentroCostoItem();
                break;
            }
        }
        }
        
        try {
            JasperReport reporte= (JasperReport) JRLoader.loadObject(getClass().getResource("/Reportes/misEgresosFiltrado.jasper"));
            
            Map parametros= new HashMap <Object,Object>();
            parametros.put("estado",estado);
            parametros.put("localidad",localidad);
            parametros.put("centroCosto",centroCosto);
            parametros.put("centroCostoItem",centroCostoItem);
            parametros.put("area",area);
            parametros.put("CONTEXT",this.getServletContext().getRealPath("/"));
            byte[] bytes= JasperRunManager.runReportToPdf(reporte, parametros,new JRBeanCollectionDataSource(lista));
            response.setContentType("application/pdf");
            response.setContentLength(bytes.length);
            ServletOutputStream outputStream=response.getOutputStream();
            outputStream.write(bytes,0,bytes.length);
            outputStream.flush();
            outputStream.close();
//JasperViewer.viewReport(jasperPrint,true);
            
// TODO add your handling code here:
        } catch (JRException ex) {
            Logger.getLogger(ImprimirOrdenCompra.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
