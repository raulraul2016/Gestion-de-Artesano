/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlet;

import Reportes.OrdenCompraDetalle;
import dao.ArticuloDAO;
import dao.OrdenCompraDAO;
import dao.OrdenCompraDetalleDAO;
import dao.ProveedorDAO;
import dto.ArticuloDTO;
import dto.OrdenCompraDTO;
import dto.OrdenCompraDetalleDTO;
import dto.ProveedorDTO;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.JasperRunManager;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.engine.util.JRLoader;



/**
 *
 * @author Ariel
 */
public class ImprimirOrdenCompra extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException{
        
        OrdenCompraDAO compraDAO=new OrdenCompraDAO();
        OrdenCompraDTO compraDTO= (OrdenCompraDTO) compraDAO.extraer (request.getParameter("id_compra"));
        OrdenCompraDetalleDAO detalleDAO=new OrdenCompraDetalleDAO();
        ArrayList<OrdenCompraDetalleDTO> listadetalles= (ArrayList<OrdenCompraDetalleDTO>)detalleDAO.extraerTodosF(compraDTO.getId_orden_compra());
        ProveedorDAO pdao=new ProveedorDAO();
        ArticuloDAO adao=new ArticuloDAO();
        ArticuloDTO adto=new ArticuloDTO();
        ArrayList<ProveedorDTO> proveedores= (ArrayList<ProveedorDTO>) pdao.extraerTodos();
        ArrayList<OrdenCompraDetalle> lista= new ArrayList<OrdenCompraDetalle>();
        
        for(int i=0;i<listadetalles.size();i++){
            adto= adao.extraer(listadetalles.get(i).getId_articulo());
            OrdenCompraDetalle detalle=new OrdenCompraDetalle(i+1, adto.getNombre(), listadetalles.get(i).getCantidad());
            lista.add(detalle);
        }
        try {
            JasperReport reporte= (JasperReport) JRLoader.loadObject(getClass().getResource("/Reportes/ordenCompra.jasper"));
            String proveedor="";
            Map parametros= new HashMap <Object,Object>();
            parametros.put("nro_compra",compraDTO.getId_orden_compra());
            parametros.put("CONTEXT",this.getServletContext().getRealPath("/"));
            for(int i=0;i<proveedores.size();i++){
                if(proveedores.get(i).getId_proveedor()==compraDTO.getId_proveedor()){
                    proveedor=proveedores.get(i).getNombre_denominacion();
                    
                }
            }
            parametros.put("proveedor",proveedor);
            String fecha=util.Util.getFechaMod(compraDTO.getFecha_creacion());
            parametros.put("fecha_creacion",fecha);
            byte[] bytes= JasperRunManager.runReportToPdf(reporte, parametros,new JRBeanCollectionDataSource(lista));
            response.setContentType("application/pdf");
            response.setContentLength(bytes.length);
            ServletOutputStream outputStream=response.getOutputStream();
            outputStream.write(bytes,0,bytes.length);
            outputStream.flush();
            outputStream.close();
        } catch (JRException ex) {
            Logger.getLogger(ImprimirOrdenCompra.class.getName()).log(Level.SEVERE, null, ex);
        }   
    }
    
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
