/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlet;

import Reportes.OrdenCompra;
import dao.ProveedorDAO;
import dao.UsuarioDAO;
import dto.OrdenCompraDTO;
import dto.ProveedorDTO;
import dto.UsuarioDTO;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.JasperRunManager;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.engine.util.JRLoader;

/**
 *
 * @author Ariel
 */
public class ImprimirOrdenCompraFiltrado extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int opcion=Integer.parseInt(request.getParameter("opcion"));
        ArrayList<OrdenCompraDTO> listaordenes= (ArrayList<OrdenCompraDTO>) request.getSession().getAttribute("listaordenescompraparaimprimir");
        ProveedorDAO pdao=new ProveedorDAO();
        ArrayList<ProveedorDTO> proveedores= (ArrayList<ProveedorDTO>) pdao.extraerTodos();
        UsuarioDAO udao=new UsuarioDAO();
        ArrayList<UsuarioDTO> usuarios=(ArrayList<UsuarioDTO>)udao.extraerTodos();
        ArrayList<OrdenCompra> lista= new ArrayList<OrdenCompra>();
        
        for(int i=0;i<listaordenes.size();i++){
            OrdenCompra compra=new OrdenCompra();
                        compra.setNroOrden(listaordenes.get(i).getId_orden_compra());
                        compra.setDetalle(listaordenes.get(i).getDetalle());
                        compra.setFecha(util.Util.getFechaMod(listaordenes.get(i).getFecha_creacion()));
            for(int h=0;h<proveedores.size();h++){
                if(proveedores.get(h).getId_proveedor()==listaordenes.get(i).getId_proveedor()){
                    compra.setProveedor(proveedores.get(h).getNombre_denominacion());
                }
            }
            for(int h=0;h<usuarios.size();h++){
                if(usuarios.get(h).getIdusuarios()==listaordenes.get(i).getId_usuario()){
                    compra.setCreador(usuarios.get(h).getApellido()+" "+usuarios.get(h).getNombre());
                }
            }
            lista.add(compra);
        }
        String proveedor="";
        String usuario="";
        if(lista.size()!=0){
        switch(opcion){
            case 1:{
                usuario= lista.get(0).getCreador();
                proveedor="Todos";
                break;
            }
            case 2:{
                usuario= "Todos";
                proveedor=lista.get(0).getProveedor();
                break;
            }
            case 3:{
                usuario= "Todos";
                proveedor= "Todos";
                break;
            }
        }
        }
        
        try {
            JasperReport reporte= (JasperReport) JRLoader.loadObject(getClass().getResource("/Reportes/ordenCompraFiltrado.jasper"));
            
            Map parametros= new HashMap <Object,Object>();
            parametros.put("proveedor",proveedor);
            parametros.put("usuario",usuario);
            parametros.put("CONTEXT",this.getServletContext().getRealPath("/"));
            byte[] bytes= JasperRunManager.runReportToPdf(reporte, parametros,new JRBeanCollectionDataSource(lista));
            response.setContentType("application/pdf");
            response.setContentLength(bytes.length);
            ServletOutputStream outputStream=response.getOutputStream();
            outputStream.write(bytes,0,bytes.length);
            outputStream.flush();
            outputStream.close();
//JasperViewer.viewReport(jasperPrint,true);
            
// TODO add your handling code here:
        } catch (JRException ex) {
            Logger.getLogger(ImprimirOrdenCompra.class.getName()).log(Level.SEVERE, null, ex);
        } 
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
