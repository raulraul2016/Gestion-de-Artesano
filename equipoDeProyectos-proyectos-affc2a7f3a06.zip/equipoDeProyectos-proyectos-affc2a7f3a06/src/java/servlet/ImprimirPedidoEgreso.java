/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlet;

import Reportes.OrdenCompraDetalle;
import dao.AreaDAO;
import dao.ArticuloDAO;
import dao.CentroCostoDAO;
import dao.CentroCostoItemDAO;
import dao.EstadoDAO;
import dao.SolicitudEgresoDAO;
import dao.SolicitudEgresoDetalleDAO;
import dto.AreaDTO;
import dto.ArticuloDTO;
import dto.CentroCostoDTO;
import dto.CentroCostoItemDTO;
import dto.EstadoDTO;
import dto.SolicitudEgresoDTO;
import dto.SolicitudEgresoDetalleDTO;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.JasperRunManager;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.engine.util.JRLoader;

/**
 *
 * @author Ariel
 */
public class ImprimirPedidoEgreso extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        SolicitudEgresoDAO sedao=new SolicitudEgresoDAO();
        SolicitudEgresoDTO sedto=sedao.extraer(request.getParameter("id_egreso"));
        AreaDAO adao=new AreaDAO();
        ArrayList<AreaDTO> areas= (ArrayList<AreaDTO>) adao.extraerTodos();
        EstadoDAO edao=new EstadoDAO();
        ArrayList<EstadoDTO> estados= (ArrayList<EstadoDTO>) edao.extraerTodos();
        CentroCostoDAO ccdao=new CentroCostoDAO();
        ArrayList<CentroCostoDTO> centroscosto= (ArrayList<CentroCostoDTO>) ccdao.extraerTodos();
        CentroCostoItemDAO ccidao=new CentroCostoItemDAO();
        ArrayList<CentroCostoItemDTO> itemscentrocosto= (ArrayList<CentroCostoItemDTO>) ccidao.extraerTodos();
        SolicitudEgresoDetalleDAO detalleDAO=new SolicitudEgresoDetalleDAO();
        ArrayList<SolicitudEgresoDetalleDTO> detalleDTO= (ArrayList<SolicitudEgresoDetalleDTO>) detalleDAO.extraerTodosF(sedto.getId_solicitud_egreso());
        ArrayList<OrdenCompraDetalle> list=new ArrayList<OrdenCompraDetalle>();
        ArticuloDTO articulo=new ArticuloDTO();
        ArticuloDAO articuloDAO=new ArticuloDAO();
        for(int i=0;i<detalleDTO.size();i++){
            
            articulo=articuloDAO.extraer(detalleDTO.get(i).getId_articulo());
            OrdenCompraDetalle aux=new OrdenCompraDetalle(i+1, articulo.getNombre(), detalleDTO.get(i).getCantidad_aprobada());
            list.add(aux);
        }
        
        try {
            JasperReport reporte= (JasperReport) JRLoader.loadObject(getClass().getResource("/Reportes/pedidoEgreso.jasper"));
            String area="";
            String estado="";
            String centro_costo="";
            String centro_costo_item="";
            Map parametros= new HashMap <Object,Object>();
            parametros.put("nro_pedido",sedto.getId_solicitud_egreso());
            for(int i=0;i<areas.size();i++){
                if(areas.get(i).getId()==sedto.getId_area_origen()){
                    area=areas.get(i).getNombre_area();
                }
            }
            for(int i=0;i<centroscosto.size();i++){
                if(centroscosto.get(i).getId_centros_costo().equals(sedto.getId_centro_costo_destino())){
                    centro_costo=centroscosto.get(i).getNombre();
                }
            }
            for(int i=0;i<itemscentrocosto.size();i++){
                if(itemscentrocosto.get(i).getIditem_centro_costo().equals(sedto.getId_item_centro_costo_destino())){
                    centro_costo_item=itemscentrocosto.get(i).getNombre();
                }
            }
            for(int i=0;i<estados.size();i++){
                if(estados.get(i).getIdestados()==sedto.getEstado()){
                    estado=estados.get(i).getNombre();
                }
            }
            parametros.put("estado",estado);
            parametros.put("area_origen",area);
            parametros.put("centro_costo",centro_costo);
            parametros.put("centro_costo_item",centro_costo_item);
            if(sedto.getRetira()!=null){
            parametros.put("retira", sedto.getRetira());
            }else{
                parametros.put("retira", "");
            }
            String fecha=util.Util.getFechaMod(sedto.getFecha_creacion());
            parametros.put("fecha",fecha);
            parametros.put("CONTEXT",this.getServletContext().getRealPath("/"));
            byte[] bytes= JasperRunManager.runReportToPdf(reporte, parametros,new JRBeanCollectionDataSource(list));
            response.setContentType("application/pdf");
            response.setContentLength(bytes.length);
            ServletOutputStream outputStream=response.getOutputStream();
            outputStream.write(bytes,0,bytes.length);
            outputStream.flush();
            outputStream.close();
            
// TODO add your handling code here:
        } catch (JRException ex) {
            Logger.getLogger(ImprimirOrdenCompra.class.getName()).log(Level.SEVERE, null, ex);
        }  
        
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
