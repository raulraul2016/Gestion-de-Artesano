/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlet;

import Reportes.PedidoEgresoCombustible;
import dao.AreaDAO;
import dao.ArticuloDAO;
import dao.EstadoDAO;
import dao.FormaCargaCombustibleDAO;
import dao.SolicitudEgresoCombustibleDAO;
import dao.SolicitudEgresoCombustibleDetalleDAO;
import dao.TipoCargarCombustibleDAO;
import dao.UsuarioDAO;
import dto.AreaDTO;
import dto.ArticuloDTO;
import dto.EstadoDTO;
import dto.FormaCargaCombustibleDTO;
import dto.SolicitudEgresoCombustibleDTO;
import dto.SolicitudEgresoCombustibleDetalleDTO;
import dto.TipoCargarCombustibleDTO;
import dto.UsuarioDTO;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.JasperRunManager;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.engine.util.JRLoader;

/**
 *
 * @author Ariel
 */
public class ImprimirPedidoEgresoCombustible extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        SolicitudEgresoCombustibleDAO sedao=new SolicitudEgresoCombustibleDAO();
        SolicitudEgresoCombustibleDTO sedto=sedao.extraer(request.getParameter("id_egreso_combustible"));
        SolicitudEgresoCombustibleDetalleDAO secdao=new SolicitudEgresoCombustibleDetalleDAO();
        ArrayList<SolicitudEgresoCombustibleDetalleDTO> detalles=(ArrayList<SolicitudEgresoCombustibleDetalleDTO>)secdao.extraerTodosF(sedto.getIdsolicitud_egreso_combustible());
        ArticuloDAO articuloDAO=new ArticuloDAO();
        ArrayList<ArticuloDTO> articulos=(ArrayList<ArticuloDTO>) articuloDAO.extraerTodosCombustible();
        UsuarioDAO usuarioDAO=new UsuarioDAO();
        ArrayList<UsuarioDTO> usuarios=(ArrayList<UsuarioDTO>) usuarioDAO.extraerTodos();
        AreaDAO areaDAO=new AreaDAO();
        ArrayList<AreaDTO> areas=(ArrayList<AreaDTO>) areaDAO.extraerTodos();
        EstadoDAO estadoDAO=new EstadoDAO();
        ArrayList<EstadoDTO> estados=(ArrayList<EstadoDTO>) estadoDAO.extraerTodos();
        TipoCargarCombustibleDAO tipoDAO=new TipoCargarCombustibleDAO();
        ArrayList<TipoCargarCombustibleDTO> tipos=(ArrayList<TipoCargarCombustibleDTO>) tipoDAO.extraerTodos();
        FormaCargaCombustibleDAO formaDAO=new FormaCargaCombustibleDAO();
        ArrayList<FormaCargaCombustibleDTO> formas=(ArrayList<FormaCargaCombustibleDTO>) formaDAO.extraerTodosPedido(sedto.getIdsolicitud_egreso_combustible());
        ArrayList<PedidoEgresoCombustible> combustibles=new ArrayList<PedidoEgresoCombustible>();
        
        
            String articulo = "";
            String area = "";
            String estado = "";
            String usuario = "";
            String formaCarga = "";
            for(int h=0;h<detalles.size();h++){
            for (int i = 0; i < articulos.size(); i++) {
                if (detalles.get(h).getId_articulo().equals(articulos.get(i).getId_articulo())) {
                    articulo = articulos.get(i).getNombre();
                    PedidoEgresoCombustible detalle=new PedidoEgresoCombustible(h+1,articulo, detalles.get(h).getCantidad_aprobada());
                    combustibles.add(detalle);
                }
            }
            }
            
            
            for (int i = 0; i < areas.size(); i++) {
                if (sedto.getId_area_origen() == (areas.get(i).getId())) {
                    area = areas.get(i).getNombre_area();
                }
            }
            for (int i = 0; i < estados.size(); i++) {
                if (sedto.getEstado() == (estados.get(i).getIdestados())) {
                    estado = estados.get(i).getNombre();
                }
            }
            for (int i = 0; i < usuarios.size(); i++) {
                if (sedto.getId_usuario() == (usuarios.get(i).getIdusuarios())) {
                    usuario = usuarios.get(i).getApellido() + " " + usuarios.get(i).getNombre();
                }
            }
            for (int h = 0; h < formas.size(); h++) {
                for (int i = 0; i < tipos.size(); i++) {
                    if (tipos.get(i).getIdtipo_carga_combustible() == formas.get(h).getIdTipoCarga()) {
                        if(formaCarga.equals("")){
                            formaCarga=formaCarga+tipos.get(i).getNombre();
                        }else{
                        formaCarga =formaCarga+" - "+tipos.get(i).getNombre();}
                    }
                }
            }
            JasperReport reporte;
        try {
            reporte = (JasperReport) JRLoader.loadObject(getClass().getResource("/Reportes/pedidoEgresoCombustible.jasper"));
        
            
            Map parametros= new HashMap <Object,Object>();
            
            parametros.put("nro_pedido",sedto.getIdsolicitud_egreso_combustible());
            parametros.put("estado",estado);
            parametros.put("area_origen",area);
            parametros.put("usuario",usuario);
            parametros.put("combustible",articulo);
            parametros.put("expendedor",sedto.getExpendedor());
            parametros.put("chofer",sedto.getChofer());
            parametros.put("destino",sedto.getDestino());
            parametros.put("motivo",sedto.getMotivo());
            parametros.put("kmSalida",sedto.getKm_salida());
            parametros.put("kmLlegada",sedto.getKm_llegada());
            parametros.put("formaCarga",formaCarga);            
            String fecha=util.Util.getFechaMod(sedto.getFecha());
            parametros.put("fecha",fecha);
            parametros.put("CONTEXT",this.getServletContext().getRealPath("/"));
            byte[] bytes= JasperRunManager.runReportToPdf(reporte, parametros,new JRBeanCollectionDataSource(combustibles));
            response.setContentType("application/pdf");
            response.setContentLength(bytes.length);
            ServletOutputStream outputStream=response.getOutputStream();
            outputStream.write(bytes,0,bytes.length);
            outputStream.flush();
            outputStream.close();
            } catch (JRException ex) {
            Logger.getLogger(ImprimirPedidoEgresoCombustible.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
            processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
            processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
