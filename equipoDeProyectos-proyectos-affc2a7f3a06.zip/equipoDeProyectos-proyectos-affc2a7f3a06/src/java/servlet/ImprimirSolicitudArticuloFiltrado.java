/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlet;

import Reportes.SolicitudPedido;
import dao.AreaDAO;
import dao.EstadoDAO;
import dao.PrioridadDAO;
import dao.ProveedorDAO;
import dto.AreaDTO;
import dto.EstadoDTO;
import dto.PrioridadDTO;
import dto.ProveedorDTO;
import dto.SolicitudPedidoDTO;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.JasperRunManager;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.engine.util.JRLoader;

/**
 *
 * @author Ariel
 */
public class ImprimirSolicitudArticuloFiltrado extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int opcion=Integer.parseInt(request.getParameter("filtro"));
        ArrayList<SolicitudPedidoDTO> listaordenes= (ArrayList<SolicitudPedidoDTO>) request.getSession().getAttribute("listasolicitudarticulosparaimprimir");
        ProveedorDAO pdao=new ProveedorDAO();
        ArrayList<ProveedorDTO> proveedores= (ArrayList<ProveedorDTO>) pdao.extraerTodos();
        PrioridadDAO prdao=new PrioridadDAO();
        ArrayList<PrioridadDTO> prioridades= (ArrayList<PrioridadDTO>) prdao.extraerTodos();
        EstadoDAO edao=new EstadoDAO();
        ArrayList<EstadoDTO> estados= (ArrayList<EstadoDTO>) edao.extraerTodos();
        AreaDAO adao=new AreaDAO();
        ArrayList<AreaDTO> areas= (ArrayList<AreaDTO>) adao.extraerTodos();
        ArrayList<SolicitudPedido> lista= new ArrayList<SolicitudPedido>();
        
        for(int i=0;i<listaordenes.size();i++){
            SolicitudPedido solicitud=new SolicitudPedido();
                        solicitud.setNro(listaordenes.get(i).getId_solicitud());
                        if(listaordenes.get(i).getFecha_creacion()!=null){
                        solicitud.setFecha_creacion(util.Util.getFechaMod(listaordenes.get(i).getFecha_creacion()));
                        }else{
                            solicitud.setFecha_creacion("");
                        }
                        if(listaordenes.get(i).getFecha_modificacion()!=null){
                        solicitud.setFecha_modificacion(util.Util.getFechaMod(listaordenes.get(i).getFecha_modificacion()));
                        }else{
                        solicitud.setFecha_modificacion("");
                        }
                        if(listaordenes.get(i).getFecha_anulacion()!=null){
                        solicitud.setFecha_anulacion(util.Util.getFechaMod(listaordenes.get(i).getFecha_anulacion()));
                        }else{
                        solicitud.setFecha_anulacion("");
                        }
                        
            for(int h=0;h<proveedores.size();h++){
                if(proveedores.get(h).getId_proveedor()==listaordenes.get(i).getProveedor()){
                    solicitud.setProveedor(proveedores.get(h).getNombre_denominacion());
                }
            }
            for(int h=0;h<prioridades.size();h++){
                if(prioridades.get(h).getIdprioridades()==listaordenes.get(i).getId_prioridad()){
                    solicitud.setPrioridad(prioridades.get(h).getNombre());
                }
            }
            for(int h=0;h<estados.size();h++){
                if(estados.get(h).getIdestados()==listaordenes.get(i).getEstado()){
                    solicitud.setEstado(estados.get(h).getNombre());
                }
            }
            lista.add(solicitud);
        }
        String proveedor="";
        String prioridad="";
        String estado="";
        String area="";
        for(int i=0; i<areas.size();i++){
            if(areas.get(i).getId()==Integer.parseInt(request.getSession().getAttribute("area").toString())){
            area=areas.get(i).getNombre_area();}
        }
        if(lista.size()!=0){
        switch(opcion){
            case 0:{
                prioridad="Todos";
                proveedor="Todos";
                estado="Todos";
                break;
            }
            case 1:{
                prioridad= lista.get(0).getPrioridad();
                proveedor="Todos";
                estado="Todos";
                break;
            }
            case 2:{
                prioridad="Todos";
                proveedor="Todos";
                estado=lista.get(0).getEstado();
                break;
            }
            case 3:{
                prioridad="Todos" ;
                proveedor=lista.get(0).getProveedor();
                estado="Todos";
                break;
            }
        }
        }
        
        try {
            JasperReport reporte= (JasperReport) JRLoader.loadObject(getClass().getResource("/Reportes/solicitudPedidoFiltrado.jasper"));
            
            Map parametros= new HashMap <Object,Object>();
            parametros.put("proveedor",proveedor);
            parametros.put("prioridad",prioridad);
            parametros.put("estado",estado);
            parametros.put("area",area);
            parametros.put("CONTEXT",this.getServletContext().getRealPath("/"));
            byte[] bytes= JasperRunManager.runReportToPdf(reporte, parametros,new JRBeanCollectionDataSource(lista));
            response.setContentType("application/pdf");
            response.setContentLength(bytes.length);
            ServletOutputStream outputStream=response.getOutputStream();
            outputStream.write(bytes,0,bytes.length);
            outputStream.flush();
            outputStream.close();
//JasperViewer.viewReport(jasperPrint,true);
            
// TODO add your handling code here:
        } catch (JRException ex) {
            Logger.getLogger(ImprimirOrdenCompra.class.getName()).log(Level.SEVERE, null, ex);
        } 
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
