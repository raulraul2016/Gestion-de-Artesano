/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlet;

import dao.OrdenCompraDAO;
import dao.OrdenCompraDetalleDAO;
import dto.OrdenCompraDTO;
import dto.OrdenCompraDetalleDTO;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Ariel
 */
public class NuevaCompra extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        OrdenCompraDTO ocdto=new OrdenCompraDTO();
        ocdto.setId_usuario(Integer.valueOf(request.getSession().getAttribute("id").toString()));
        ocdto.setId_proveedor(Integer.valueOf(request.getParameter("id_proveedor")));
        ocdto.setDetalle("Pedidos utilizados: ");
        OrdenCompraDAO ocdao=new OrdenCompraDAO();
        OrdenCompraDetalleDAO ocddao=new OrdenCompraDetalleDAO();
        if(ocdao.crear(ocdto)){
            ocdto.setId_orden_compra(ocdao.lastIdPedido(ocdto.getId_usuario()));
            ArrayList<OrdenCompraDetalleDTO> lista= (ArrayList<OrdenCompraDetalleDTO>) request.getSession().getAttribute("listacompra");
            if(lista!=null){
                ArrayList<OrdenCompraDetalleDTO> listaNormalizada= (ArrayList<OrdenCompraDetalleDTO>)normalizarListaArticulos(lista);
                ArrayList<Long> pedidosusadosaux=(ArrayList<Long>) normalizarListaPedidosUsados(lista);
                for(int i=0;i<pedidosusadosaux.size();i++){
                    ocdto.setDetalle(ocdto.getDetalle()+" '"+pedidosusadosaux.get(i).toString()+"' ");
                }
                for(int i=0;i<listaNormalizada.size();i++){
                    listaNormalizada.get(i).setId_orden_compra(ocdto.getId_orden_compra());
                    ocdao.actualizar(ocdto);
                }
                if(ocddao.insertarDetalles(listaNormalizada, pedidosusadosaux)){
                    request.getSession().setAttribute("detalles_compra",listaNormalizada);
                    request.getSession().setAttribute("orden_compra",ocdto);
                    out.println("<script type=\"text/javascript\">");  
                    out.println("var a=confirm('Se realizo correctamente la creaci�n de la orden de compra Nro:"+ ocdto.getId_orden_compra()+", desea imprimir la orden de compra?');"); 
                    out.println("if(a){location.href='imprimir_orden_compra?id_compra="+ocdto.getId_orden_compra()+"'}"); 
                    out.println("</script>"); 
                }else{
                out.println("<script type=\"text/javascript\">");  
                out.println("alert('No se pudo insertar la lista de articulos, se debe eliminar la orden de compra Nro:"+ ocdto.getId_orden_compra()+", comuniquese con el administrador');"); 
                out.println("location.href='nuevacompra.jsp?menu=1'"); 
                out.println("</script>");
                }
            }else{
            out.println("<script type=\"text/javascript\">");  
            out.println("alert('No se pudo leer la lista de articulos, intente nuevamente');"); 
            out.println("location.href='nuevacompra.jsp?menu=1'"); 
            out.println("</script>");
            }
        }else{
            out.println("<script type=\"text/javascript\">");  
            out.println("alert('No se pudo crear la orden de compra, intente nuevamente');"); 
            out.println("location.href='nuevacompra.jsp?menu=1'"); 
            out.println("</script>");
        }
        
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

    private List<OrdenCompraDetalleDTO> normalizarListaArticulos (ArrayList<OrdenCompraDetalleDTO> lista){
        
        ArrayList<OrdenCompraDetalleDTO> listaaux= new ArrayList<OrdenCompraDetalleDTO>();
        for(int i=0;i<lista.size();i++){
            boolean suma=false;
            if(listaaux.size()==0){
                listaaux.add(lista.get(i));
            }else{
                for(int h=0;h<listaaux.size();h++){
                    if(lista.get(i).getId_articulo().equals(listaaux.get(h).getId_articulo())){
                        listaaux.get(h).setCantidad(listaaux.get(h).getCantidad()+lista.get(i).getCantidad());
                        h=listaaux.size();
                        suma=true;
                    }
                }
                if(!suma){
                    listaaux.add(lista.get(i));
                }
            }
        }
        return listaaux;
    }
    private List<Long> normalizarListaPedidosUsados (ArrayList<OrdenCompraDetalleDTO> lista){
        
        ArrayList<Long> listaaux= new ArrayList<Long>();
        for(int i=0;i<lista.size();i++){
            boolean suma=false;
            if(listaaux.size()==0){
                listaaux.add(lista.get(i).getIdpedidoorigen());
            }else{
                for(int h=0;h<listaaux.size();h++){
                    if(lista.get(i).getIdpedidoorigen().equals(listaaux.get(h))){
                        h=listaaux.size();
                        suma=true;
                    }
                }
                if(!suma){
                    listaaux.add(lista.get(i).getIdpedidoorigen());
                }
            }
        }
        return listaaux;
    }
}
