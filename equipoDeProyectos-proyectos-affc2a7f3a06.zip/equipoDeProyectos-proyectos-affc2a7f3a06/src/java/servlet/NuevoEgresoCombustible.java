/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlet;

import conexion.Conexion;
import dao.FormaCargaCombustibleDAO;
import dao.SolicitudEgresoCombustibleDAO;
import dao.SolicitudEgresoCombustibleDetalleDAO;
import dto.FormaCargaCombustibleDTO;
import dto.SolicitudEgresoCombustibleDTO;
import dto.SolicitudEgresoCombustibleDetalleDTO;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Ariel
 */
public class NuevoEgresoCombustible extends HttpServlet {
    private static final Conexion CON = Conexion.saberEstado();
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            response.setContentType("text/html;charset=UTF-8");
            PrintWriter out = response.getWriter();
            
            SolicitudEgresoCombustibleDAO dAO=new SolicitudEgresoCombustibleDAO();
            FormaCargaCombustibleDAO cargaCombustibleDAO=new FormaCargaCombustibleDAO();
            SolicitudEgresoCombustibleDetalleDAO combustibleDetalleDAO=new SolicitudEgresoCombustibleDetalleDAO();
            SolicitudEgresoCombustibleDTO pedido=(SolicitudEgresoCombustibleDTO) request.getSession().getAttribute("solicitud_egreso_combustible");
            ArrayList<SolicitudEgresoCombustibleDetalleDTO> list=(ArrayList<SolicitudEgresoCombustibleDetalleDTO>) request.getSession().getAttribute("listadetalleegresocombustible");
            ArrayList<FormaCargaCombustibleDTO> listFormas=(ArrayList<FormaCargaCombustibleDTO>) request.getSession().getAttribute("listaFormas");
            if(pedido!=null){
                
                if(dAO.crear(pedido)){
                    CON.getCnn().setAutoCommit(false);
                    pedido.setIdsolicitud_egreso_combustible(dAO.lastIdPedido(pedido.getId_usuario()));
                    if (listFormas != null) {
                        for (int i = 0; i < listFormas.size(); i++) {
                            listFormas.get(i).setIdSolicitudEgresoCombustible(pedido.getIdsolicitud_egreso_combustible());
                        }
                        if (cargaCombustibleDAO.insertarDetalles2(listFormas, CON.getCnn())) {
                            if(list!=null){
                                for (int i = 0; i < list.size(); i++) {
                                    list.get(i).setId_solicitud_egreso_combustible(pedido.getIdsolicitud_egreso_combustible());
                                }
                                if(combustibleDetalleDAO.insertarDetalles2(list, CON.getCnn())){
                                    CON.getCnn().commit();
                                    out.println("<script type=\"text/javascript\">");
                                    out.println("alert('El pedido N� "+pedido.getIdsolicitud_egreso_combustible()+"se creo');");
                                    out.println("location.href='solicitaregresocombustible.jsp?menu=1'");
                                    out.println("</script>");
                                }else{
                                    out.println("<script type=\"text/javascript\">");
                                    out.println("alert('No se pudo generar la lista de combustibles, intente nuevamente');");
                                    out.println("location.href='solicitaregresocombustible.jsp?menu=1'");
                                    out.println("</script>");
                                }
                            } else {
                                out.println("<script type=\"text/javascript\">");
                                out.println("alert('No se pudo leer la lista de combustibles, intente nuevamente');");
                                out.println("location.href='solicitaregresocombustible.jsp?menu=1'");
                                out.println("</script>");
                            }
                        } else {
                            out.println("<script type=\"text/javascript\">");
                            out.println("alert('No se pudo generar la lista de formas de carga, intente nuevamente');");
                            out.println("location.href='solicitaregresocombustible.jsp?menu=1'");
                            out.println("</script>");
                        }
                    } else {
                        out.println("<script type=\"text/javascript\">");
                        out.println("alert('No se pudo generar la lista de formas de carga, intente nuevamente');");
                        out.println("location.href='solicitaregresocombustible.jsp?menu=1'");
                        out.println("</script>");
                    }
                }else{
                    out.println("<script type=\"text/javascript\">");
                    out.println("alert('No se pudo generar el pedido, intente nuevamente');");
                    out.println("location.href='solicitaregresocombustible.jsp?menu=1'");
                    out.println("</script>");
                }
            }else{
                out.println("<script type=\"text/javascript\">");
                out.println("alert('No se pudo leer el pedido, intente nuevamente');");
                out.println("location.href='solicitaregresocombustible.jsp?menu=1'");
                out.println("</script>");
            }
        } catch (SQLException ex) {
            try {
                CON.getCnn().rollback();
                System.out.println("No se puedo generar los registros");
                Logger.getLogger(NuevoEgresoCombustible.class.getName()).log(Level.SEVERE, null, ex);
            } catch (SQLException ex1) {
                Logger.getLogger(NuevoEgresoCombustible.class.getName()).log(Level.SEVERE, null, ex1);
            }
        }finally{
            CON.cerrarConexion();
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
