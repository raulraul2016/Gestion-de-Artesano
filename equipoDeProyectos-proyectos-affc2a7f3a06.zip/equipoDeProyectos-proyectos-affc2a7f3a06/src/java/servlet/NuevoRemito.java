/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlet;

import dao.ArticuloDAO;
import dao.MovimientoArticuloDAO;
import dao.MovimientoArticuloDetalleDAO;
import dao.OrdenCompraDetalleDAO;
import dao.RemitoDAO;
import dao.RemitoDetalleDAO;
import dto.MovimientoArticuloDTO;
import dto.MovimientoArticuloDetalleDTO;
import dto.OrdenCompraDetalleDTO;
import dto.RemitoDTO;
import dto.RemitoDetalleDTO;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Ariel
 */
public class NuevoRemito extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        MovimientoArticuloDTO madto=new MovimientoArticuloDTO();
        MovimientoArticuloDAO madao=new MovimientoArticuloDAO();
        ArticuloDAO adao=new ArticuloDAO();
        MovimientoArticuloDetalleDTO maddto=new MovimientoArticuloDetalleDTO();
        MovimientoArticuloDetalleDAO maddao=new MovimientoArticuloDetalleDAO();
        OrdenCompraDetalleDAO ocddao=new OrdenCompraDetalleDAO();
        RemitoDetalleDAO spddao= new RemitoDetalleDAO();
        RemitoDAO spdao=new RemitoDAO();
        RemitoDTO spdto= (RemitoDTO) request.getSession().getAttribute("remito");
        ArrayList<OrdenCompraDetalleDTO> compraDetalleDTOs= (ArrayList<OrdenCompraDetalleDTO>) ocddao.extraerTodosF(spdto.getId_orden_compra_asociada());
        ArrayList<RemitoDetalleDTO> list= (ArrayList<RemitoDetalleDTO>) request.getSession().getAttribute("listadetalleremito");
        madto.setId_usuario(Integer.parseInt(request.getSession().getAttribute("id").toString()));
        madto.setTipo_movimiento(1);
        if(spdto!=null){
            if(spdao.crear(spdto)){
            spdto.setId_remito(spdao.lastId(spdto.getId_usuario()));
            madto.setNro_documento("Remido N�: "+spdto.getNro_remito());
            if(madao.crear(madto)){
                madto.setIdmovimientos_articulos(madao.lastIdPedido(madto.getId_usuario()));
                maddto.setId_movimiento_articulo(madto.getIdmovimientos_articulos());
            if(list!=null){
                for(int i=0; i<list.size();i++){
                    list.get(i).setId_remito(spdto.getId_remito());
                    if(!spddao.crear(list.get(i))){
                        out.println("<script type=\"text/javascript\">");  
                        out.println("alert('Error al insertar articulo en el remito');"); 
                        out.println("location.href='ingresoremito.jsp'"); 
                        out.println("</script>");
                    }else{
                        for(int h=0;h<compraDetalleDTOs.size();h++){
                        if(compraDetalleDTOs.get(h).getId_articulo().equals(list.get(i).getId_articulo())){
                            compraDetalleDTOs.get(h).setCantidad_recibida(compraDetalleDTOs.get(h).getCantidad_recibida()+list.get(i).getCantidad());
                            ocddao.actualizar(compraDetalleDTOs.get(h));
                        }
                        }
                        maddto.setId_articulo(list.get(i).getId_articulo());
                        maddto.setCantidad(list.get(i).getCantidad());
                        maddto.setPrecio(list.get(i).getPrecio());
                        maddao.crear(maddto);
                        adao.actualizarIngresoStock(list.get(i).getId_articulo(), list.get(i).getCantidad(), list.get(i).getPrecio());
                    }
                }
                        
            }else{
                        out.println("<script type=\"text/javascript\">");  
                        out.println("alert('No hay articulos en el remito');"); 
                        out.println("location.href='ingresoremito.jsp'"); 
                        out.println("</script>");
            }}else{
                        out.println("<script type=\"text/javascript\">");  
                        out.println("alert('No se pudo crear el movimiento de ingreso');"); 
                        out.println("location.href='ingresoremito.jsp'"); 
                        out.println("</script>");
            }
            }else{
                        out.println("<script type=\"text/javascript\">");  
                        out.println("alert('No se pudo crear el remito, intente nuevamente');"); 
                        out.println("location.href='ingresoremito.jsp'"); 
                        out.println("</script>");
            }
                        request.getSession().setAttribute("remito", null);
                        request.getSession().setAttribute("listadetalleremito", null);
                        out.println("<script type=\"text/javascript\">");  
                        out.println("location.href='ingresoremito.jsp'");  
                        out.println("alert('El remito se creo correctamente');");
                        out.println("</script>");
        }else{
                        out.println("<script type=\"text/javascript\">");  
                        out.println("alert('No se ha localizado el remito!');"); 
                        out.println("location.href='ingresoremito.jsp'"); 
                        out.println("</script>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
