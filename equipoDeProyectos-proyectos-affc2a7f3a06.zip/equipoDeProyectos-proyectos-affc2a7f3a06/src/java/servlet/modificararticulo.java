/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlet;

import dao.ArticuloDAO;
import dto.ArticuloDTO;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author yesi
 */
public class modificararticulo extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        ArticuloDAO adao=new ArticuloDAO();
        ArticuloDTO adto= new ArticuloDTO();
        adto.setId_articulo(Long.valueOf(request.getParameter("id_articulo")));
        adto.setNombre(request.getParameter("nombre_articulo"));
        adto.setRubro(Integer.parseInt(request.getParameter("rubro")));
        adto.setUnidad_medida(Integer.parseInt(request.getParameter("unidad_medida")));
        adto.setStock_min(Integer.parseInt(request.getParameter("stock_min")));
        adto.setStock_max(Integer.parseInt(request.getParameter("stock_max")));
        adto.setStock_actual(Integer.parseInt(request.getParameter("stock_actual")));
        adto.setPrecio(Double.valueOf(request.getParameter("precio")));
        adto.setActivo(Boolean.valueOf(request.getParameter("activo")));
        if(adao.actualizar(adto)){
            out.println("<script type=\"text/javascript\">");  
            out.println("alert('El artiuclo se modifico correctamente');"); 
            out.println("location.href='administracionarticulos.jsp'"); 
            out.println("</script>");
        }else{
            out.println("<script type=\"text/javascript\">");  
            out.println("alert('Hubo un error al modificar el articulo, por intente nuevamente');"); 
            out.println("location.href='administracionarticulos.jsp'"); 
            out.println("</script>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
