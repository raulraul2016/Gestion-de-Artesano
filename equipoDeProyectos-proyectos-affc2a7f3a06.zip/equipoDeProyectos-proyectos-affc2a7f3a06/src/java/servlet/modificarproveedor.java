/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlet;

import dao.ProveedorDAO;
import dao.ProveedorRubroDAO;
import dto.ProveedorDTO;
import dto.ProveedorRubroDTO;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author yesi
 */
public class modificarproveedor extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        ProveedorDAO pdao=new ProveedorDAO();
        ProveedorDTO pdto= new ProveedorDTO();
        ProveedorRubroDAO prdao=new ProveedorRubroDAO();
        ProveedorRubroDTO prdto= new ProveedorRubroDTO();
        pdto.setId_proveedor(Integer.parseInt(request.getParameter("id_proveedor")));
        pdto.setNombre_denominacion(request.getParameter("nombre_denominacion"));
        String[] rubrosString=request.getParameterValues("rubro");
        Integer[] rubros= new Integer[rubrosString.length];
        for(int i=0;i<rubrosString.length;i++){
            rubros[i]=Integer.valueOf(rubrosString[i]);
        }pdto.setDireccion(request.getParameter("direccion"));
        pdto.setCuit(request.getParameter("cuit"));
        pdto.setTelefono(request.getParameter("telefono"));
        pdto.setMail(request.getParameter("mail"));
        pdto.setDescripcion(request.getParameter("descripcion"));
        pdto.setActivo(Boolean.valueOf(request.getParameter("activo")));
        if(pdao.actualizar(pdto)){
            ArrayList<ProveedorRubroDTO> rubrosexistentes= (ArrayList<ProveedorRubroDTO>) prdao.extraerTodosPRO(pdto.getId_proveedor());
            for(int i=0;i<rubrosexistentes.size();i++){
                prdao.borrar(rubrosexistentes.get(i).getIdproveedor_rubro());
            }
            prdto.setId_proveedor(pdto.getId_proveedor());
            for(int i=0;i<rubros.length;i++){
                prdto.setId_rubro(rubros[i]);
                if(prdao.verificarexistencia(prdto)){
                    prdao.crear(prdto);
                }
            }
            out.println("<script type=\"text/javascript\">");  
            out.println("alert('El proveedor se modific� correctamente');"); 
            out.println("location.href='administracionproveedores.jsp'"); 
            out.println("</script>");
        }else{
            out.println("<script type=\"text/javascript\">");  
            out.println("alert('Hubo un error al modificar el proveedor, por intente nuevamente');"); 
            out.println("location.href='administracionproveedores.jsp'"); 
            out.println("</script>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
