/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlet;

import dao.UsuarioDAO;
import dto.UsuarioDTO;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author yesi
 */
public class modificarusuariodao extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        UsuarioDAO udao=new UsuarioDAO();
        UsuarioDTO dTOaux= (UsuarioDTO) Login.session.getAttribute("usuario_modificar");
        UsuarioDTO dTO= new UsuarioDTO();
        dTO.setIdusuarios(dTOaux.getIdusuarios());
        dTO.setUsuario(request.getParameter("usuario"));
        dTO.setContrase�a(request.getParameter("contrasena"));
        dTO.setRol(Integer.parseInt(request.getParameter("rol")));
        dTO.setApellido(request.getParameter("apellido"));
        dTO.setNombre(request.getParameter("nombre"));
        dTO.setDni(Long.valueOf(request.getParameter("dni")));
        dTO.setTelefono(request.getParameter("telefono"));
        dTO.setArea(Integer.parseInt(request.getParameter("area")));
        dTO.setCargo(request.getParameter("cargo"));
        if(request.getParameter("activo").equals("Si")){
            dTO.setActivo(true);
        }else{
            dTO.setActivo(false);
        }
        if(request.getParameter("usuario").length()>0 &&request.getParameter("contrasena").length()>0 &&request.getParameter("rol").length()>0 &&request.getParameter("apellido").length()>0 && request.getParameter("nombre").length()>0 &&request.getParameter("dni").length()>0 && request.getParameter("area").length()>0 &&request.getParameter("cargo").length()>0 ){
        if(udao.actualizarusuario(dTO)){
            out.println("<script type=\"text/javascript\">");  
            out.println("alert('El usuario se actualizo correctamente');"); 
            out.println("location.href='administrar_usuarios.jsp'"); 
            out.println("</script>");
        }else{
            out.println("<script type=\"text/javascript\">");  
            out.println("alert('Ocurrio un error al actualizar por favor intentar nuevamente');"); 
            out.println("location.href='modificar_usuario.jsp'"); 
            out.println("</script>");
        }
            out.println("<script type=\"text/javascript\">");  
            out.println("alert('No se ingresaron todos los datos necesarios');"); 
            out.println("location.href='modificar_usuario.jsp'"); 
            out.println("</script>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
