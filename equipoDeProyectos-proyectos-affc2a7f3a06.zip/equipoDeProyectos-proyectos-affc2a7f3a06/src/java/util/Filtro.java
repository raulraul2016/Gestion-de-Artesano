/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 *clave=apellido, valor=garay condicion= ilike
 * @author Ariel
 * **************IMPLEMENTACION***********
 * Filtro filtro=new Filtro();
        filtro.columa.put("nombre", "leo");
        filtro.columa.put("apellido", "garay");
        filtro.columa.put("dni", "43121");
        filtro.condicion.put("nombre", "ilike");
        filtro.condicion.put("apellido", "ilike");
        filtro.condicion.put("dni", "=");
        filtro.nameFecha="fecha_alta";
        filtro.fechas.add("2016-12-12");
        filtro.fechas.add("2016-12-24");
        filtro.condicionFecha("BETWEEN");
        System.out.println(filtro.where());
 */
public class Filtro {
    
    public HashMap<String, String> columa =new HashMap();//
    public HashMap <String, String> condicion = new HashMap();
    public ArrayList<String> fechas=new ArrayList<String>();
    public String nameFecha;
    private String where;
    public String condicionFecha;
    
    public String where(){
        where="";
        for (Map.Entry <String, String> entry : columa.entrySet()) {
            if(where.equals("")){
                if(condicion.get(entry.getKey()).equals("LIKE")){
                    where=where+" WHERE "+entry.getKey()+" "+condicion.get(entry.getKey())+" '%"+entry.getValue()+"%' ";
                }else{
                    where=where+" WHERE "+entry.getKey()+" "+condicion.get(entry.getKey())+" "+entry.getValue();
                }
            }else{
                if(condicion.get(entry.getKey()).equals("LIKE")){
                    where=where+" AND "+entry.getKey()+" "+condicion.get(entry.getKey())+" '%"+entry.getValue()+"%' ";
                }else{
                    where=where+" AND "+entry.getKey()+" "+condicion.get(entry.getKey())+" "+entry.getValue();
                }
            }
        }
        if (!fechas.isEmpty()) {
            if(!where.equals("")){
            String sql = "";
            nameFecha = " AND " + nameFecha;
            if (fechas.size()>1) {
                for (int i = 0; i < fechas.size(); i++) {
                    if (sql.equals("")) {
                        sql = " '" + sql + fechas.get(i);
                    } else {
                        sql = sql + "' AND '" + fechas.get(i)+"'";
                    }
                }
                nameFecha = nameFecha+" BETWEEN";
                where = where + nameFecha + sql;
            }else{
                nameFecha =nameFecha+" "+condicionFecha;
                where=where+nameFecha+" '"+fechas.get(0)+"'";
            }
            }else{
               String sql = "";
            nameFecha = " WHERE " + nameFecha;
            if (fechas.size()>1) {
                for (int i = 0; i < fechas.size(); i++) {
                    if (sql.equals("")) {
                        sql = " '" + sql + fechas.get(i);
                    } else {
                        sql = sql + "' AND '" + fechas.get(i)+"'";
                    }
                }
                nameFecha = nameFecha+" "+condicionFecha;
                where = where + nameFecha + sql;
            }else{
                nameFecha =nameFecha+" "+condicionFecha;
                where=where+nameFecha+" '"+fechas.get(0)+"'";
            } 
            }
        }
        return where;
    }
}
