/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package util;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 *
 * @author Ariel
 */
public class Util {

    public static String SIS_OP_NUEVO="NUEVO";
    public static String SIS_OP_MODIFICAR="MODIFICAR";
    public static String SIS_OP_ELIMINAR="ELIMINAR";
    
    public static java.sql.Date dateToSqlDate(java.util.Date fecha) {

        java.sql.Date fechaSql;
        if (fecha != null) {
            fechaSql = new java.sql.Date(fecha.getTime());
        } else {
            return null;
        }
        return fechaSql;
    }
    public static String getFechaMod(Date fechaMod){
        SimpleDateFormat sf = new SimpleDateFormat("dd-MM-yyyy");
        return sf.format(fechaMod);
    }
}
