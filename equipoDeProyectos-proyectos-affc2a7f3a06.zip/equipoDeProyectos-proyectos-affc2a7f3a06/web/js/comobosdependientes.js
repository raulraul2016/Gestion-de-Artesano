function nuevoAjax(){ 
    /* Crea el objeto AJAX. Esta funcion es generica para cualquier utilidad de este tipo, por
    lo que se puede copiar tal como esta aqui */
    var xmlhttp=false;
    try{
        // Creacion del objeto AJAX para navegadores no IE
        xmlhttp=new ActiveXObject("Msxml2.XMLHTTP");
    }
    catch(e){
        try{
            // Creacion del objet AJAX para IE
            xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
        }
        catch(E){
            if (!xmlhttp && typeof XMLHttpRequest!='undefined') xmlhttp=new XMLHttpRequest();
        }
    }
    return xmlhttp; 
}
 
function cargaDepartamentos(idSelectOrigen){
    // Obtengo el select que el usuario modifico
    var selectOrigen=document.getElementById(idSelectOrigen);
    // Obtengo la opcion que el usuario selecciono
    var opcionSeleccionada=selectOrigen.options[selectOrigen.selectedIndex].value;
    // Si el usuario eligio la opcion "Elige", no voy al servidor y pongo los selects siguientes en estado "Selecciona estado..."
    if(opcionSeleccionada==0)
    {
        var selectActual=null;
        if(idSelectOrigen == "region")
            selectActual=document.getElementById("departamento");
            selectActual.length=0;
            var nuevaOpcion=document.createElement("option"); 
            nuevaOpcion.value=0; 
            nuevaOpcion.innerHTML="Seleccione Region";
            selectActual.appendChild(nuevaOpcion);  
            selectActual.disabled=true;
    }
    // Compruebo que el select modificado no sea el ultimo de la cadena
    else{
        if(idSelectOrigen == "region")
            var selectDestino=document.getElementById("departamento");
        // Creo el nuevo objeto AJAX y envio al servidor la opcion seleccionada del select origen
            var ajax=nuevoAjax();
            ajax.open("GET", "llena_departamentos.jsp?opcion="+opcionSeleccionada+"&select="+idSelectOrigen, true);
            ajax.onreadystatechange=function() 
        { 
            if (ajax.readyState==1)
            {
                // Mientras carga elimino la opcion "Selecciona Opcion..." y pongo una que dice "Cargando..."
                selectDestino.length=0;
                var nuevaOpcion=document.createElement("option"); 
                nuevaOpcion.value=0; 
                nuevaOpcion.innerHTML="Cargando...";
                selectDestino.appendChild(nuevaOpcion); 
                selectDestino.disabled=true;    
            }
            if (ajax.readyState==4)
            {
                selectDestino.parentNode.innerHTML=ajax.responseText;
            } 
        }
        ajax.send(null);
    }
}

function cargaSubareas(idSelectOrigen){
    document.getElementById("subarea").disabled=false;
    // Obtengo el select que el usuario modifico
    var selectOrigen=document.getElementById(idSelectOrigen);
    // Obtengo la opcion que el usuario selecciono
    var opcionSeleccionada=selectOrigen.options[selectOrigen.selectedIndex].value;
    // Si el usuario eligio la opcion "Elige", no voy al servidor y pongo los selects siguientes en estado "Selecciona estado..."
    if(opcionSeleccionada==0)
    {
        var selectActual=null;
        if(idSelectOrigen == "area")
            selectActual=document.getElementById("subarea");
            selectActual.length=0;
            var nuevaOpcion=document.createElement("option"); 
            nuevaOpcion.value=0; 
            nuevaOpcion.innerHTML="Seleccione Area";
            selectActual.appendChild(nuevaOpcion);  
            selectActual.disabled=true;
    }
    // Compruebo que el select modificado no sea el ultimo de la cadena
    else{
        if(idSelectOrigen == "area")
            var selectDestino=document.getElementById("subarea");
        // Creo el nuevo objeto AJAX y envio al servidor la opcion seleccionada del select origen
            var ajax=nuevoAjax();
            ajax.open("GET", "llena_subareas.jsp?opcion="+opcionSeleccionada+"&select="+idSelectOrigen, true);
            ajax.onreadystatechange=function() 
        { 
            if (ajax.readyState==1)
            {
                // Mientras carga elimino la opcion "Selecciona Opcion..." y pongo una que dice "Cargando..."
                selectDestino.length=0;
                var nuevaOpcion=document.createElement("option"); 
                nuevaOpcion.value=0; 
                nuevaOpcion.innerHTML="Cargando...";
                selectDestino.appendChild(nuevaOpcion); 
                selectDestino.disabled=true;    
            }
            if (ajax.readyState==4)
            {
                selectDestino.parentNode.innerHTML=ajax.responseText;
            } 
        }
        ajax.send(null);
    }
}

function cargaLocalidades(idSelectOrigen){
    document.getElementById("localidad").disabled=false;
    // Obtengo el select que el usuario modifico
    var selectOrigen=document.getElementById(idSelectOrigen);
    // Obtengo la opcion que el usuario selecciono
    var opcionSeleccionada=selectOrigen.options[selectOrigen.selectedIndex].value;
    // Si el usuario eligio la opcion "Elige", no voy al servidor y pongo los selects siguientes en estado "Selecciona estado..."
    if(opcionSeleccionada==0)
    {
        var selectActual=null;
        if(idSelectOrigen == "departamento")
            selectActual=document.getElementById("localidad");
            selectActual.length=0;
            var nuevaOpcion=document.createElement("option"); 
            nuevaOpcion.value=0; 
            nuevaOpcion.innerHTML="Seleccione Departamento";
            selectActual.appendChild(nuevaOpcion);  
            selectActual.disabled=true;
    }
    // Compruebo que el select modificado no sea el ultimo de la cadena
    else{
        if(idSelectOrigen == "departamento")
            var selectDestino=document.getElementById("localidad");
        // Creo el nuevo objeto AJAX y envio al servidor la opcion seleccionada del select origen
            var ajax=nuevoAjax();
            ajax.open("GET", "llena_localidades.jsp?opcion="+opcionSeleccionada+"&select="+idSelectOrigen, true);
            ajax.onreadystatechange=function() 
        { 
            if (ajax.readyState==1)
            {
                // Mientras carga elimino la opcion "Selecciona Opcion..." y pongo una que dice "Cargando..."
                selectDestino.length=0;
                var nuevaOpcion=document.createElement("option"); 
                nuevaOpcion.value=0; 
                nuevaOpcion.innerHTML="Cargando...";
                selectDestino.appendChild(nuevaOpcion); 
                selectDestino.disabled=true;    
            }
            if (ajax.readyState==4)
            {
                selectDestino.parentNode.innerHTML=ajax.responseText;
            } 
        }
        ajax.send(null);
    }
}

function cargaArticulos(idSelectOrigen){
    // Obtengo el select que el usuario modifico
    var selectOrigen=document.getElementById(idSelectOrigen);
    // Obtengo la opcion que el usuario selecciono
    var opcionSeleccionada=selectOrigen.options[selectOrigen.selectedIndex].value;
    // Si el usuario eligio la opcion "Elige", no voy al servidor y pongo los selects siguientes en estado "Selecciona estado..."
    if(opcionSeleccionada===0)
    {
        var selectActual=null;
        if(idSelectOrigen === "proveedor")
            selectActual=document.getElementById("articulo");
            selectActual.length=0;
            var nuevaOpcion=document.createElement("option"); 
            nuevaOpcion.value=0; 
            nuevaOpcion.innerHTML="Seleccione Articulo";
            selectActual.appendChild(nuevaOpcion);  
            selectActual.disabled=true;
    }
    // Compruebo que el select modificado no sea el ultimo de la cadena
    else{
        if(idSelectOrigen === "proveedor")
            var selectDestino=document.getElementById("articulo");
        // Creo el nuevo objeto AJAX y envio al servidor la opcion seleccionada del select origen
            var ajax=nuevoAjax();
            ajax.open("GET", "llena_articulos.jsp?opcion="+opcionSeleccionada+"&select="+idSelectOrigen, true);
            ajax.onreadystatechange=function() 
        { 
            if (ajax.readyState===1)
            {
                // Mientras carga elimino la opcion "Selecciona Opcion..." y pongo una que dice "Cargando..."
                selectDestino.length=0;
                var nuevaOpcion=document.createElement("option"); 
                nuevaOpcion.value=0; 
                nuevaOpcion.innerHTML="Cargando...";
                selectDestino.appendChild(nuevaOpcion); 
                selectDestino.disabled=true;    
            }
            if (ajax.readyState===4)
            {
                selectDestino.parentNode.innerHTML=ajax.responseText;
            } 
        };
        ajax.send(null);
    }
}

function verSolicitud(idSolicitud){
    
        if(idSolicitud != null)
            var divDestino=document.getElementById("detallesolicitudseleccionada");
        // Creo el nuevo objeto AJAX y envio al servidor la opcion seleccionada del select origen
            var ajax=nuevoAjax();
            ajax.open("GET", "ver_solicitud.jsp?id_solicitud="+idSolicitud, true);
            ajax.onreadystatechange=function() 
        { 
            if (ajax.readyState==1)
            {
                // Mientras carga elimino la opcion "Selecciona Opcion..." y pongo una que dice "Cargando..."
                selectDestino.length=0;
                var nuevaOpcion=document.createElement("option"); 
                nuevaOpcion.value=0; 
                nuevaOpcion.innerHTML="Cargando...";
                selectDestino.appendChild(nuevaOpcion); 
                selectDestino.disabled=true;    
            }
            if (ajax.readyState==4)
            {
                divDestino.parentNode.innerHTML=ajax.responseText;
            } 
        }
        ajax.send(null);
    
}
function mostrar_select(id) {
            var elemento=document.getElementById(id).checked;
            if(elemento){
            document.getElementById("localidad").disabled=false;
            document.getElementById("movilidad").disabled=true}
            if(!elemento){
            document.getElementById("localidad").disabled=true;
            document.getElementById("localidad").value=0;
            document.getElementById("centrocosto").disabled=true;
            document.getElementById("centrocostoitem").disabled=true;
            document.getElementById("movilidad").disabled=false;
            document.getElementById("movilidad").value="";
    }
}
function cargaCentroCosto(idSelectOrigen){
    // Obtengo el select que el usuario modifico
    var selectOrigen=document.getElementById(idSelectOrigen);
    // Obtengo la opcion que el usuario selecciono
    var opcionSeleccionada=selectOrigen.options[selectOrigen.selectedIndex].value;
    // Si el usuario eligio la opcion "Elige", no voy al servidor y pongo los selects siguientes en estado "Selecciona estado..."
    if(opcionSeleccionada===0)
    {
        var selectActual=null;
        if(idSelectOrigen === "localidad")
            selectActual=document.getElementById("centrocosto");
            selectActual.length=0;
            var nuevaOpcion=document.createElement("option"); 
            nuevaOpcion.value=0; 
            nuevaOpcion.innerHTML="Seleccione Localidad";
            selectActual.appendChild(nuevaOpcion);  
            selectActual.disabled=true;
    }
    // Compruebo que el select modificado no sea el ultimo de la cadena
    else{
        if(idSelectOrigen === "localidad")
            var selectDestino=document.getElementById("centrocosto");
        // Creo el nuevo objeto AJAX y envio al servidor la opcion seleccionada del select origen
            var ajax=nuevoAjax();
            ajax.open("GET", "llena_centrocosto.jsp?opcion="+opcionSeleccionada+"&select="+idSelectOrigen, true);
            ajax.onreadystatechange=function() 
        { 
            if (ajax.readyState===1)
            {
                // Mientras carga elimino la opcion "Selecciona Opcion..." y pongo una que dice "Cargando..."
                selectDestino.length=0;
                var nuevaOpcion=document.createElement("option"); 
                nuevaOpcion.value=0; 
                nuevaOpcion.innerHTML="Cargando...";
                selectDestino.appendChild(nuevaOpcion); 
                selectDestino.disabled=true;    
            }
            if (ajax.readyState===4)
            {
                selectDestino.parentNode.innerHTML=ajax.responseText;
            } 
        };
        ajax.send(null);
    }
}
function cargaItemCentroCosto(idSelectOrigen){
    // Obtengo el select que el usuario modifico
    var selectOrigen=document.getElementById(idSelectOrigen);
    // Obtengo la opcion que el usuario selecciono
    var opcionSeleccionada=selectOrigen.options[selectOrigen.selectedIndex].value;
    // Si el usuario eligio la opcion "Elige", no voy al servidor y pongo los selects siguientes en estado "Selecciona estado..."
    if(opcionSeleccionada===0)
    {
        var selectActual=null;
        if(idSelectOrigen === "centrocosto")
            selectActual=document.getElementById("centrocostoitem");
            selectActual.length=0;
            var nuevaOpcion=document.createElement("option"); 
            nuevaOpcion.value=0; 
            nuevaOpcion.innerHTML="Seleccione Centro Costo";
            selectActual.appendChild(nuevaOpcion);  
            selectActual.disabled=true;
    }
    // Compruebo que el select modificado no sea el ultimo de la cadena
    else{
        if(idSelectOrigen === "centrocosto")
            var selectDestino=document.getElementById("centrocostoitem");
        // Creo el nuevo objeto AJAX y envio al servidor la opcion seleccionada del select origen
            var ajax=nuevoAjax();
            ajax.open("GET", "llena_centrocostoitem.jsp?opcion="+opcionSeleccionada+"&select="+idSelectOrigen, true);
            ajax.onreadystatechange=function() 
        { 
            if (ajax.readyState===1)
            {
                // Mientras carga elimino la opcion "Selecciona Opcion..." y pongo una que dice "Cargando..."
                selectDestino.length=0;
                var nuevaOpcion=document.createElement("option"); 
                nuevaOpcion.value=0; 
                nuevaOpcion.innerHTML="Cargando...";
                selectDestino.appendChild(nuevaOpcion); 
                selectDestino.disabled=true;    
            }
            if (ajax.readyState===4)
            {
                selectDestino.parentNode.innerHTML=ajax.responseText;
            } 
        };
        ajax.send(null);
    }
}

function cargarFiltro(idSelectOrigen){
    // Obtengo el select que el usuario modifico
    var selectOrigen=document.getElementById(idSelectOrigen);
    document.getElementById("idsolicitud").value="";
    // Obtengo la opcion que el usuario selecciono
    var opcionSeleccionada=selectOrigen.options[selectOrigen.selectedIndex].value;
    // Si el usuario eligio la opcion "Elige", no voy al servidor y pongo los selects siguientes en estado "Selecciona estado..."
    if(opcionSeleccionada===0)
    {
        var selectActual=null;
        if(idSelectOrigen === "filtro")
            selectActual=document.getElementById("opcionflitro");
            selectActual.length=0;
            var nuevaOpcion=document.createElement("option"); 
            nuevaOpcion.value=0; 
            nuevaOpcion.innerHTML="Seleccione Filtro";
            selectActual.appendChild(nuevaOpcion);  
            selectActual.disabled=true;
    }
    // Compruebo que el select modificado no sea el ultimo de la cadena
    else{
        if(idSelectOrigen === "filtro")
            var selectDestino=document.getElementById("opcionfiltro");
        // Creo el nuevo objeto AJAX y envio al servidor la opcion seleccionada del select origen
            var ajax=nuevoAjax();
            ajax.open("GET", "llena_opcion_filtro.jsp?opcion="+opcionSeleccionada+"&select="+idSelectOrigen, true);
            ajax.onreadystatechange=function() 
        { 
            if (ajax.readyState===1)
            {
                // Mientras carga elimino la opcion "Selecciona Opcion..." y pongo una que dice "Cargando..."
                selectDestino.length=0;
                var nuevaOpcion=document.createElement("option"); 
                nuevaOpcion.value=0; 
                nuevaOpcion.innerHTML="Cargando...";
                selectDestino.appendChild(nuevaOpcion); 
                selectDestino.disabled=true;    
            }
            if (ajax.readyState===4)
            {
                selectDestino.parentNode.innerHTML=ajax.responseText;
            } 
        };
        ajax.send(null);
    }
}
function cargarFiltroSolicitudesTodas(idSelectOrigen){
    // Obtengo el select que el usuario modifico
    var selectOrigen=document.getElementById(idSelectOrigen);
    document.getElementById("idsolicitud").value="";
    // Obtengo la opcion que el usuario selecciono
    var opcionSeleccionada=selectOrigen.options[selectOrigen.selectedIndex].value;
    // Si el usuario eligio la opcion "Elige", no voy al servidor y pongo los selects siguientes en estado "Selecciona estado..."
    if(opcionSeleccionada===0)
    {
        var selectActual=null;
        if(idSelectOrigen === "filtro")
            selectActual=document.getElementById("opcionflitro");
            selectActual.length=0;
            var nuevaOpcion=document.createElement("option"); 
            nuevaOpcion.value=0; 
            nuevaOpcion.innerHTML="Seleccione Filtro";
            selectActual.appendChild(nuevaOpcion);  
            selectActual.disabled=true;
    }
    // Compruebo que el select modificado no sea el ultimo de la cadena
    else{
        if(idSelectOrigen === "filtro")
            var selectDestino=document.getElementById("opcionfiltro");
        // Creo el nuevo objeto AJAX y envio al servidor la opcion seleccionada del select origen
            var ajax=nuevoAjax();
            ajax.open("GET", "llena_opcion_filtro_solicitudes_todas.jsp?opcion="+opcionSeleccionada+"&select="+idSelectOrigen, true);
            ajax.onreadystatechange=function() 
        { 
            if (ajax.readyState===1)
            {
                // Mientras carga elimino la opcion "Selecciona Opcion..." y pongo una que dice "Cargando..."
                selectDestino.length=0;
                var nuevaOpcion=document.createElement("option"); 
                nuevaOpcion.value=0; 
                nuevaOpcion.innerHTML="Cargando...";
                selectDestino.appendChild(nuevaOpcion); 
                selectDestino.disabled=true;    
            }
            if (ajax.readyState===4)
            {
                selectDestino.parentNode.innerHTML=ajax.responseText;
            } 
        };
        ajax.send(null);
    }
}
function cargarFiltroSolicitudesPendientes(idSelectOrigen){
    // Obtengo el select que el usuario modifico
    var selectOrigen=document.getElementById(idSelectOrigen);
    document.getElementById("idsolicitud").value="";
    // Obtengo la opcion que el usuario selecciono
    var opcionSeleccionada=selectOrigen.options[selectOrigen.selectedIndex].value;
    // Si el usuario eligio la opcion "Elige", no voy al servidor y pongo los selects siguientes en estado "Selecciona estado..."
    if(opcionSeleccionada===0)
    {
        var selectActual=null;
        if(idSelectOrigen === "filtro")
            selectActual=document.getElementById("opcionflitro");
            selectActual.length=0;
            var nuevaOpcion=document.createElement("option"); 
            nuevaOpcion.value=0; 
            nuevaOpcion.innerHTML="Seleccione Filtro";
            selectActual.appendChild(nuevaOpcion);  
            selectActual.disabled=true;
    }
    // Compruebo que el select modificado no sea el ultimo de la cadena
    else{
        if(idSelectOrigen === "filtro")
            var selectDestino=document.getElementById("opcionfiltro");
        // Creo el nuevo objeto AJAX y envio al servidor la opcion seleccionada del select origen
            var ajax=nuevoAjax();
            ajax.open("GET", "llena_opcion_filtro_solicitudes_pendientes.jsp?opcion="+opcionSeleccionada+"&select="+idSelectOrigen, true);
            ajax.onreadystatechange=function() 
        { 
            if (ajax.readyState===1)
            {
                // Mientras carga elimino la opcion "Selecciona Opcion..." y pongo una que dice "Cargando..."
                selectDestino.length=0;
                var nuevaOpcion=document.createElement("option"); 
                nuevaOpcion.value=0; 
                nuevaOpcion.innerHTML="Cargando...";
                selectDestino.appendChild(nuevaOpcion); 
                selectDestino.disabled=true;    
            }
            if (ajax.readyState===4)
            {
                selectDestino.parentNode.innerHTML=ajax.responseText;
            } 
        };
        ajax.send(null);
    }
}

function cargarFiltroEgreso(idSelectOrigen){
    // Obtengo el select que el usuario modifico
    var selectOrigen=document.getElementById(idSelectOrigen);
    document.getElementById("idpedido").value="";
    // Obtengo la opcion que el usuario selecciono
    var opcionSeleccionada=selectOrigen.options[selectOrigen.selectedIndex].value;
    // Si el usuario eligio la opcion "Elige", no voy al servidor y pongo los selects siguientes en estado "Selecciona estado..."
    if(opcionSeleccionada===0)
    {
        var selectActual=null;
        if(idSelectOrigen === "filtro")
            selectActual=document.getElementById("opcionflitro");
            selectActual.length=0;
            var nuevaOpcion=document.createElement("option"); 
            nuevaOpcion.value=0; 
            nuevaOpcion.innerHTML="Seleccione Filtro";
            selectActual.appendChild(nuevaOpcion);  
            selectActual.disabled=true;
    }
    // Compruebo que el select modificado no sea el ultimo de la cadena
    else{
        if(idSelectOrigen === "filtro")
            var selectDestino=document.getElementById("opcionfiltro");
        // Creo el nuevo objeto AJAX y envio al servidor la opcion seleccionada del select origen
            var ajax=nuevoAjax();
            ajax.open("GET", "llena_opcion_filtro_egreso.jsp?opcion="+opcionSeleccionada+"&select="+idSelectOrigen, true);
            ajax.onreadystatechange=function() 
        { 
            if (ajax.readyState===1)
            {
                // Mientras carga elimino la opcion "Selecciona Opcion..." y pongo una que dice "Cargando..."
                selectDestino.length=0;
                var nuevaOpcion=document.createElement("option"); 
                nuevaOpcion.value=0; 
                nuevaOpcion.innerHTML="Cargando...";
                selectDestino.appendChild(nuevaOpcion); 
                selectDestino.disabled=true;    
            }
            if (ajax.readyState===4)
            {
                selectDestino.parentNode.innerHTML=ajax.responseText;
            } 
        };
        ajax.send(null);
    }
}
function cargarFiltroEgresoTodos(idSelectOrigen){
    // Obtengo el select que el usuario modifico
    var selectOrigen=document.getElementById(idSelectOrigen);
    document.getElementById("idpedido").value="";
    // Obtengo la opcion que el usuario selecciono
    var opcionSeleccionada=selectOrigen.options[selectOrigen.selectedIndex].value;
    // Si el usuario eligio la opcion "Elige", no voy al servidor y pongo los selects siguientes en estado "Selecciona estado..."
    if(opcionSeleccionada===0)
    {
        var selectActual=null;
        if(idSelectOrigen === "filtro")
            selectActual=document.getElementById("opcionflitro");
            selectActual.length=0;
            var nuevaOpcion=document.createElement("option"); 
            nuevaOpcion.value=0; 
            nuevaOpcion.innerHTML="Seleccione Filtro";
            selectActual.appendChild(nuevaOpcion);  
            selectActual.disabled=true;
    }
    // Compruebo que el select modificado no sea el ultimo de la cadena
    else{
        if(idSelectOrigen === "filtro")
            var selectDestino=document.getElementById("opcionfiltro");
        // Creo el nuevo objeto AJAX y envio al servidor la opcion seleccionada del select origen
            var ajax=nuevoAjax();
            ajax.open("GET", "llena_opcion_filtro_egreso_todos.jsp?opcion="+opcionSeleccionada+"&select="+idSelectOrigen, true);
            ajax.onreadystatechange=function() 
        { 
            if (ajax.readyState===1)
            {
                // Mientras carga elimino la opcion "Selecciona Opcion..." y pongo una que dice "Cargando..."
                selectDestino.length=0;
                var nuevaOpcion=document.createElement("option"); 
                nuevaOpcion.value=0; 
                nuevaOpcion.innerHTML="Cargando...";
                selectDestino.appendChild(nuevaOpcion); 
                selectDestino.disabled=true;    
            }
            if (ajax.readyState===4)
            {
                selectDestino.parentNode.innerHTML=ajax.responseText;
            } 
        };
        ajax.send(null);
    }
}
function cargarFiltroEgresoPendiente(idSelectOrigen){
    // Obtengo el select que el usuario modifico
    var selectOrigen=document.getElementById(idSelectOrigen);
    document.getElementById("idpedido").value="";
    // Obtengo la opcion que el usuario selecciono
    var opcionSeleccionada=selectOrigen.options[selectOrigen.selectedIndex].value;
    // Si el usuario eligio la opcion "Elige", no voy al servidor y pongo los selects siguientes en estado "Selecciona estado..."
    if(opcionSeleccionada===0)
    {
        var selectActual=null;
        if(idSelectOrigen === "filtro")
            selectActual=document.getElementById("opcionflitro");
            selectActual.length=0;
            var nuevaOpcion=document.createElement("option"); 
            nuevaOpcion.value=0; 
            nuevaOpcion.innerHTML="Seleccione Filtro";
            selectActual.appendChild(nuevaOpcion);  
            selectActual.disabled=true;
    }
    // Compruebo que el select modificado no sea el ultimo de la cadena
    else{
        if(idSelectOrigen === "filtro")
            var selectDestino=document.getElementById("opcionfiltro");
        // Creo el nuevo objeto AJAX y envio al servidor la opcion seleccionada del select origen
            var ajax=nuevoAjax();
            ajax.open("GET", "llena_opcion_filtro_egreso_pendiente.jsp?opcion="+opcionSeleccionada+"&select="+idSelectOrigen, true);
            ajax.onreadystatechange=function() 
        { 
            if (ajax.readyState===1)
            {
                // Mientras carga elimino la opcion "Selecciona Opcion..." y pongo una que dice "Cargando..."
                selectDestino.length=0;
                var nuevaOpcion=document.createElement("option"); 
                nuevaOpcion.value=0; 
                nuevaOpcion.innerHTML="Cargando...";
                selectDestino.appendChild(nuevaOpcion); 
                selectDestino.disabled=true;    
            }
            if (ajax.readyState===4)
            {
                selectDestino.parentNode.innerHTML=ajax.responseText;
            } 
        };
        ajax.send(null);
    }
}

function cargaFiltroCentroCosto(idSelectOrigen){
    // Obtengo el select que el usuario modifico
    var selectOrigen=document.getElementById(idSelectOrigen);
    document.getElementById("idpedido").value="";
    // Obtengo la opcion que el usuario selecciono
    var opcionSeleccionada=selectOrigen.options[selectOrigen.selectedIndex].value;
    // Si el usuario eligio la opcion "Elige", no voy al servidor y pongo los selects siguientes en estado "Selecciona estado..."
    if(opcionSeleccionada===0)
    {
        var selectActual=null;
        if(idSelectOrigen === "opcionfiltro")
            selectActual=document.getElementById("centrocosto");
            selectActual.length=0;
            var nuevaOpcion=document.createElement("option"); 
            nuevaOpcion.value=0; 
            nuevaOpcion.innerHTML="Seleccione Localidad";
            selectActual.appendChild(nuevaOpcion);  
            selectActual.disabled=true;
    }
    // Compruebo que el select modificado no sea el ultimo de la cadena
    else{
        if(idSelectOrigen === "opcionfiltro")
            var selectDestino=document.getElementById("centrocosto");
        // Creo el nuevo objeto AJAX y envio al servidor la opcion seleccionada del select origen
            var ajax=nuevoAjax();
            ajax.open("GET", "llena_centro_costo.jsp?opcion="+opcionSeleccionada+"&select="+idSelectOrigen, true);
            ajax.onreadystatechange=function() 
        { 
            if (ajax.readyState===1)
            {
                // Mientras carga elimino la opcion "Selecciona Opcion..." y pongo una que dice "Cargando..."
                selectDestino.length=0;
                var nuevaOpcion=document.createElement("option"); 
                nuevaOpcion.value=0; 
                nuevaOpcion.innerHTML="Cargando...";
                selectDestino.appendChild(nuevaOpcion); 
                selectDestino.disabled=true;    
            }
            if (ajax.readyState===4)
            {
                selectDestino.parentNode.innerHTML=ajax.responseText;
            } 
        };
        ajax.send(null);
    }
}
function cargaFiltroItemCentroCosto(idSelectOrigen){
    // Obtengo el select que el usuario modifico
    var selectOrigen=document.getElementById(idSelectOrigen);
    cargaTablaCentroCosto();
    // Obtengo la opcion que el usuario selecciono
    var opcionSeleccionada=selectOrigen.options[selectOrigen.selectedIndex].value;
    // Si el usuario eligio la opcion "Elige", no voy al servidor y pongo los selects siguientes en estado "Selecciona estado..."
    if(opcionSeleccionada===0)
    {
        var selectActual=null;
        if(idSelectOrigen === "centrocosto")
            selectActual=document.getElementById("centrocostoitem");
            selectActual.length=0;
            var nuevaOpcion=document.createElement("option"); 
            nuevaOpcion.value=0; 
            nuevaOpcion.innerHTML="Seleccione Centro Costo";
            selectActual.appendChild(nuevaOpcion);  
            selectActual.disabled=true;
    }
    // Compruebo que el select modificado no sea el ultimo de la cadena
    else{
        if(idSelectOrigen === "centrocosto")
            var selectDestino=document.getElementById("centrocostoitem");
        // Creo el nuevo objeto AJAX y envio al servidor la opcion seleccionada del select origen
            var ajax=nuevoAjax();
            ajax.open("GET", "llena_centro_costo_item.jsp?opcion="+opcionSeleccionada+"&select="+idSelectOrigen, true);
            ajax.onreadystatechange=function() 
        { 
            if (ajax.readyState===1)
            {
                // Mientras carga elimino la opcion "Selecciona Opcion..." y pongo una que dice "Cargando..."
                selectDestino.length=0;
                var nuevaOpcion=document.createElement("option"); 
                nuevaOpcion.value=0; 
                nuevaOpcion.innerHTML="Cargando...";
                selectDestino.appendChild(nuevaOpcion); 
                selectDestino.disabled=true;    
            }
            if (ajax.readyState===4)
            {
                selectDestino.parentNode.innerHTML=ajax.responseText;
            } 
        };
        ajax.send(null);
    }
}