/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
window.addEventListener('load',function (){
    document.getElementById("btningresar").addEventListener("click", function (){
        var usuario= document.getElementById("txtusuario").value;
        var contrase�a= document.getElementById("txtpass").value;
        if(usuario.length>0&&contrase�a.length>0){
            document.getElementById("iniciosesion").submit();
        }else if(usuario.length==0&&contrase�a.length==0){
            alert("Ingrese usuario y contraseña");
        }else if(usuario.length==0){
            alert("Ingrese usuario");
        }else if(contrase�a.length==0){
            alert("Ingrese contraseña");
        }
        
    });
});
